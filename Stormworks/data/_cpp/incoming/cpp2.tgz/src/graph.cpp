#include "graph.h"
#include "py.h"
#include "scan.h"
#include <algorithm>
#include <cmath>

static const double DEG = M_PI / 180.0;    // CPython math.radians: x * (pi / 180)

void graph_add(Graph& g, const std::string& id, const V3& p, std::vector<std::string> links) {
    auto it = g.nodes.find(id);
    if (it == g.nodes.end()) {
        g.order.push_back(id);
        g.nodes.emplace(id, TrackNode{p, std::move(links)});
    } else {
        it->second = TrackNode{p, std::move(links)};
    }
}

namespace smooth {

const double MAX_DEVIATION = 0.30;
const double MAX_TURN_PER_PIECE = 1.0 * DEG;
const double MIN_TURN_TO_SMOOTH = 0.25 * DEG;
const int MAX_PIECES = 24;
const char* NEW_NODE_PREFIX = "train_rt_";
const double MIN_NODE_GAP = 1.5;

static Dir2 norm2(double x, double z) {
    double length = py::hypot(x, z);
    if (length > 1e-9) return {x / length, z / length};
    return {0.0, 0.0};
}
static Dir2 dir(const V3& a, const V3& b) { return norm2(b[0] - a[0], b[2] - a[2]); }
static double angle(const Dir2& u, const Dir2& v) {
    double d = u[0] * v[0] + u[1] * v[1];
    return std::acos(std::max(-1.0, std::min(1.0, d)));
}

// dict.fromkeys(o for o in links if o in nodes and o != k)
static std::vector<std::string> unique_nbrs(const Graph& nodes, const std::string& k) {
    std::vector<std::string> out;
    for (const std::string& o : nodes.at(k).links)
        if (nodes.has(o) && o != k && std::find(out.begin(), out.end(), o) == out.end()) out.push_back(o);
    return out;
}

bool is_junction(const Graph& nodes, const std::string& k) {
    std::vector<std::string> nbrs = unique_nbrs(nodes, k);       // (a set; the order is irrelevant here)
    if (nbrs.size() >= 3) return true;
    if (nbrs.size() == 2) {
        const V3& p = nodes.at(k).pos;
        Dir2 a = dir(p, nodes.at(nbrs[0]).pos), b = dir(p, nodes.at(nbrs[1]).pos);
        return a[0] * b[0] + a[1] * b[1] > 0;
    }
    return false;
}

using Pairs = std::unordered_map<std::string, std::vector<std::pair<std::string, std::optional<std::string>>>>;

static Pairs node_pairs(const Graph& nodes) {
    Pairs result;
    for (const std::string& k : nodes.order) {
        const V3& p = nodes.at(k).pos;
        std::vector<std::string> nbrs = unique_nbrs(nodes, k);
        std::vector<std::pair<std::string, std::optional<std::string>>> pairing;
        for (auto& o : nbrs) pairing.push_back({o, std::nullopt});
        if (nbrs.size() == 2 && !is_junction(nodes, k)) {
            pairing[0].second = nbrs[1];
            pairing[1].second = nbrs[0];
        } else if (nbrs.size() >= 3) {
            bool have = false;
            double best_s = 0;
            size_t bi = 0, bj = 0;
            for (size_t i = 0; i < nbrs.size(); i++)
                for (size_t j = i + 1; j < nbrs.size(); j++) {
                    Dir2 da = dir(p, nodes.at(nbrs[i]).pos);
                    Dir2 db = dir(p, nodes.at(nbrs[j]).pos);
                    double straight = -(da[0] * db[0] + da[1] * db[1]);
                    if (!have || straight > best_s) { have = true; best_s = straight; bi = i; bj = j; }
                }
            pairing[bi].second = nbrs[bj];
            pairing[bj].second = nbrs[bi];
        }
        result[k] = pairing;
    }
    return result;
}

static std::optional<std::string> pair_get(const Pairs& pairs, const std::string& k, const std::string& towards) {
    for (auto& kv : pairs.at(k)) if (kv.first == towards) return kv.second;
    return std::nullopt;
}

static Dir2 node_tangent(const Graph& nodes, const Pairs& pairs, const std::string& k, const std::string& towards,
                         const std::unordered_map<std::string, Dir2>& border_tangents) {
    const V3& p = nodes.at(k).pos;
    Dir2 chord = dir(p, nodes.at(towards).pos);
    std::optional<std::string> other = pair_get(pairs, k, towards);
    Dir2 t;
    auto bt = border_tangents.find(k);
    if (bt != border_tangents.end()) t = bt->second;
    else if (other && is_junction(nodes, *other)) t = dir(nodes.at(*other).pos, p);
    else if (other) t = dir(nodes.at(*other).pos, nodes.at(towards).pos);
    else t = chord;
    if (t[0] * chord[0] + t[1] * chord[1] < 0) t = {-t[0], -t[1]};
    if (t[0] == 0.0 && t[1] == 0.0) t = chord;
    return t;
}

static std::pair<double, double> hermite(const V3& a, const V3& b, const Dir2& ta, const Dir2& tb, double scale, double f) {
    double f3 = std::pow(f, 3.0), f2 = std::pow(f, 2.0);
    double h00 = 2 * f3 - 3 * f2 + 1;
    double h10 = f3 - 2 * f2 + f;
    double h01 = -2 * f3 + 3 * f2;
    double h11 = f3 - f2;
    double x = h00 * a[0] + h10 * ta[0] * scale + h01 * b[0] + h11 * tb[0] * scale;
    double z = h00 * a[2] + h10 * ta[1] * scale + h01 * b[2] + h11 * tb[1] * scale;
    return {x, z};
}

static double max_deviation(const V3& a, const V3& b, const Dir2& ta, const Dir2& tb, double scale) {
    Dir2 chord = dir(a, b);
    Dir2 normal = {-chord[1], chord[0]};
    double worst = 0.0;
    for (int i = 1; i < 16; i++) {
        auto xz = hermite(a, b, ta, tb, scale, (double)i / 16.0);
        worst = std::max(worst, std::fabs((xz.first - a[0]) * normal[0] + (xz.second - a[2]) * normal[1]));
    }
    return worst;
}

struct CellKey {
    long long x, z;
    bool operator==(const CellKey& o) const { return x == o.x && z == o.z; }
};
struct CellHash { size_t operator()(const CellKey& c) const { return (size_t)(c.x * 1000003LL) ^ (size_t)c.z; } };
static CellKey cell_of(double x, double z) {
    return {(long long)std::floor(x / MIN_NODE_GAP), (long long)std::floor(z / MIN_NODE_GAP)};
}

static void fair_graph(Graph& nodes, std::unordered_map<std::string, double>& node_y,
                       const std::unordered_set<std::string>& fixed, std::vector<std::string>& inserted, long long& counter);

void smooth_graph(Graph& nodes, std::unordered_map<std::string, double>& node_y,
                  const std::unordered_map<std::string, Dir2>& border_tangents,
                  const std::unordered_set<std::string>& skip, std::vector<std::string>& inserted) {
    Pairs pairs = node_pairs(nodes);
    std::unordered_map<CellKey, std::vector<std::tuple<std::string, double, double>>, CellHash> grid;
    auto reg = [&](const std::string& k, double x, double z) { grid[cell_of(x, z)].emplace_back(k, x, z); };
    auto clear_of_others = [&](double x, double z, const std::string& a, const std::string& b) {
        CellKey c = cell_of(x, z);
        for (long long ix = c.x - 1; ix <= c.x + 1; ix++)
            for (long long iz = c.z - 1; iz <= c.z + 1; iz++) {
                auto it = grid.find({ix, iz});
                if (it == grid.end()) continue;
                for (auto& e : it->second) {
                    const std::string& k = std::get<0>(e);
                    if (k != a && k != b && py::hypot(std::get<1>(e) - x, std::get<2>(e) - z) < MIN_NODE_GAP) return false;
                }
            }
        return true;
    };
    for (const std::string& k : nodes.order) reg(k, nodes.at(k).pos[0], nodes.at(k).pos[2]);
    Graph new_nodes = nodes;            // links copied
    std::unordered_map<std::string, double> new_y = node_y;
    long long counter = 0;
    std::set<std::pair<std::string, std::string>> done;
    for (const std::string& a : nodes.order) {
        const TrackNode& na = nodes.at(a);
        const V3& pa = na.pos;
        for (const std::string& b : na.links) {
            if (!nodes.has(b) || b == a) continue;
            auto key = a < b ? std::make_pair(a, b) : std::make_pair(b, a);
            if (done.count(key)) continue;
            done.insert(key);
            if (skip.count(a) || skip.count(b)) continue;
            if (is_junction(nodes, a) || is_junction(nodes, b)) continue;
            const V3& pb = nodes.at(b).pos;
            double length = py::hypot(pb[0] - pa[0], pb[2] - pa[2]);
            if (length < 1.0) continue;
            Dir2 ta = node_tangent(nodes, pairs, a, b, border_tangents);
            Dir2 tb_out = node_tangent(nodes, pairs, b, a, border_tangents);
            Dir2 tb = {-tb_out[0], -tb_out[1]};
            Dir2 chord = dir(pa, pb);
            double turn = angle(ta, chord) + angle(tb, chord);
            if (turn < MIN_TURN_TO_SMOOTH) continue;
            double scale = length;
            double deviation = max_deviation(pa, pb, ta, tb, scale);
            if (deviation > MAX_DEVIATION) scale *= MAX_DEVIATION / deviation;
            long long pieces = std::min<long long>(MAX_PIECES, std::max<long long>(2, (long long)std::ceil(turn / MAX_TURN_PER_PIECE)));
            pieces = std::min<long long>(pieces, (long long)py::floordiv(length, MIN_NODE_GAP));
            if (pieces < 2) continue;
            std::vector<std::string> chain{a};
            for (long long i = 1; i < pieces; i++) {
                double f = (double)i / (double)pieces;
                auto xz = hermite(pa, pb, ta, tb, scale, f);
                double y = pa[1] + (pb[1] - pa[1]) * f;
                if (!clear_of_others(xz.first, xz.second, a, b)) continue;
                counter++;
                std::string nid = NEW_NODE_PREFIX + std::to_string(counter);
                graph_add(new_nodes, nid, {xz.first, y, xz.second}, {});
                new_y[nid] = node_y.at(a) + (node_y.at(b) - node_y.at(a)) * f;
                inserted.push_back(nid);
                chain.push_back(nid);
            }
            chain.push_back(b);
            if (chain.size() == 2) continue;
            for (size_t i = 1; i + 1 < chain.size(); i++) {
                const V3& q = new_nodes.at(chain[i]).pos;
                reg(chain[i], q[0], q[2]);
            }
            for (std::string& o : new_nodes.nodes.at(a).links) if (o == b) o = chain[1];
            for (std::string& o : new_nodes.nodes.at(b).links) if (o == a) o = chain[chain.size() - 2];
            for (size_t i = 1; i + 1 < chain.size(); i++) {
                auto& l = new_nodes.nodes.at(chain[i]).links;
                l.push_back(chain[i - 1]);
                l.push_back(chain[i + 1]);
            }
        }
    }
    std::unordered_set<std::string> fixed(skip.begin(), skip.end());
    for (auto& kv : border_tangents) fixed.insert(kv.first);
    for (const std::string& k : nodes.order) {
        if (is_junction(nodes, k)) {
            fixed.insert(k);
            for (const std::string& o : nodes.at(k).links) if (nodes.has(o)) fixed.insert(o);
        }
    }
    fair_graph(new_nodes, new_y, fixed, inserted, counter);
    nodes = std::move(new_nodes);
    node_y = std::move(new_y);
}

// ---------------------------------------------------------------- fairing
static const double FAIR_SPACING = 3.0;
static const double FAIR_MAX_SHIFT = 0.25;
static const double FAIR_MAX_RISE = 0.15;
static const int FAIR_ITERATIONS = 400;
static const double FAIR_RATE = 0.1;
static const double FAIR_MAX_TURN = 0.75 * DEG;
static const double FAIR_MIN_PIECE = 0.8;

static std::vector<std::vector<std::string>> fair_runs(const Graph& nodes, const std::unordered_set<std::string>& fixed) {
    auto nbrs = [&](const std::string& k) {
        std::vector<std::string> out;
        std::vector<std::string> seen;                 // dict.fromkeys first, then the filter
        for (const std::string& o : nodes.at(k).links)
            if (std::find(seen.begin(), seen.end(), o) == seen.end()) seen.push_back(o);
        for (const std::string& o : seen) if (nodes.has(o) && o != k) out.push_back(o);
        return out;
    };
    auto plain = [&](const std::string& k) { return !fixed.count(k) && nbrs(k).size() == 2; };
    std::vector<std::vector<std::string>> runs;
    std::set<std::pair<std::string, std::string>> seen;
    for (const std::string& a : nodes.order) {
        if (plain(a)) continue;
        for (const std::string& b : nbrs(a)) {
            if (seen.count({a, b})) continue;
            std::vector<std::string> run{a, b};
            seen.insert({a, b});
            while (plain(run.back())) {
                std::vector<std::string> nxt;
                for (const std::string& o : nbrs(run.back())) if (o != run[run.size() - 2]) nxt.push_back(o);
                if (nxt.empty() || std::find(run.begin(), run.end(), nxt[0]) != run.end()) break;
                run.push_back(nxt[0]);
            }
            seen.insert({run.back(), run[run.size() - 2]});
            if (run.size() >= 3) runs.push_back(run);
        }
    }
    return runs;
}

// numpy.interp (division slopes; x below/above the range -> end values)
static double np_interp(double x, const std::vector<double>& xp, const std::vector<double>& fp) {
    size_t n = xp.size();
    if (std::isnan(x)) return x;
    if (x > xp[n - 1]) return fp[n - 1];
    if (x < xp[0]) return fp[0];
    size_t j = std::upper_bound(xp.begin(), xp.end(), x) - xp.begin() - 1;    // xp[j] <= x < xp[j+1]
    if (j == n - 1) return fp[j];
    if (xp[j] == x) return fp[j];
    double slope = (fp[j + 1] - fp[j]) / (xp[j + 1] - xp[j]);
    double r = slope * (x - xp[j]) + fp[j];
    if (std::isnan(r)) {
        r = slope * (x - xp[j + 1]) + fp[j + 1];
        if (std::isnan(r) && fp[j] == fp[j + 1]) r = fp[j];
    }
    return r;
}

static void fair_graph(Graph& nodes, std::unordered_map<std::string, double>& node_y,
                       const std::unordered_set<std::string>& fixed, std::vector<std::string>& inserted, long long& counter) {
    std::unordered_map<CellKey, std::unordered_set<std::string>, CellHash> grid;
    for (const std::string& k : nodes.order) grid[cell_of(nodes.at(k).pos[0], nodes.at(k).pos[2])].insert(k);
    auto clear = [&](double x, double z, std::initializer_list<const std::string*> own) {
        CellKey c = cell_of(x, z);
        for (long long ix = c.x - 1; ix <= c.x + 1; ix++)
            for (long long iz = c.z - 1; iz <= c.z + 1; iz++) {
                auto it = grid.find({ix, iz});
                if (it == grid.end()) continue;
                for (const std::string& k : it->second) {
                    bool mine = false;
                    for (const std::string* o : own) if (*o == k) { mine = true; break; }
                    if (mine) continue;
                    const V3& q = nodes.at(k).pos;
                    if (py::hypot(q[0] - x, q[2] - z) < MIN_NODE_GAP) return false;
                }
            }
        return true;
    };
    auto move = [&](const std::string& k, double x, double y, double z) {
        TrackNode& n = nodes.nodes.at(k);
        grid[cell_of(n.pos[0], n.pos[2])].erase(k);
        n.pos = {x, y, z};
        grid[cell_of(x, z)].insert(k);
    };
    for (const std::vector<std::string>& run : fair_runs(nodes, fixed)) {
        size_t n = run.size();
        std::vector<std::array<double, 3>> pts(n);
        std::vector<double> lift(n);
        for (size_t i = 0; i < n; i++) {
            pts[i] = nodes.at(run[i]).pos;
            lift[i] = node_y.at(run[i]) - nodes.at(run[i]).pos[1];
        }
        std::vector<double> s(n);
        s[0] = 0.0;
        for (size_t i = 0; i + 1 < n; i++) s[i + 1] = s[i] + std::hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][2] - pts[i][2]);
        double total = s[n - 1];
        long long m = (long long)std::ceil(total / FAIR_SPACING);
        if (m < 6) continue;
        std::vector<double> u(m + 1);
        double step = total / (double)m;
        for (long long i = 0; i <= m; i++) u[i] = (double)i * step + 0.0;
        u[m] = total;
        std::vector<std::array<double, 3>> dense0(m + 1), dense;
        for (int c = 0; c < 3; c++) {
            std::vector<double> fp(n);
            for (size_t i = 0; i < n; i++) fp[i] = pts[i][c];
            // many queries: numpy precomputes slopes with the same division
            for (long long i = 0; i <= m; i++) dense0[i][c] = np_interp(u[i], s, fp);
        }
        dense = dense0;
        size_t L = (size_t)m + 1;
        std::vector<std::array<double, 3>> d(L - 4);
        for (int it = 0; it < FAIR_ITERATIONS; it++) {
            for (size_t i = 0; i + 4 < L; i++)
                for (int c = 0; c < 3; c++)
                    d[i][c] = dense[i][c] - 4.0 * dense[i + 1][c] + 6.0 * dense[i + 2][c] - 4.0 * dense[i + 3][c] + dense[i + 4][c];
            for (size_t i = 0; i + 4 < L; i++)
                for (int c = 0; c < 3; c++) dense[i + 2][c] = dense[i + 2][c] - FAIR_RATE * d[i][c];
            for (size_t i = 2; i + 2 < L; i++) {
                double sx = dense[i][0] - dense0[i][0], sy = dense[i][1] - dense0[i][1], sz = dense[i][2] - dense0[i][2];
                double horizontal = std::hypot(sx, sz);
                double scale = std::min(1.0, FAIR_MAX_SHIFT / std::max(horizontal, 1e-9));
                sx *= scale;
                sz *= scale;
                sy = std::min(std::max(sy, -FAIR_MAX_RISE), FAIR_MAX_RISE);
                dense[i][0] = dense0[i][0] + sx;
                dense[i][1] = dense0[i][1] + sy;
                dense[i][2] = dense0[i][2] + sz;
            }
        }
        std::vector<double> col[3];
        for (int c = 0; c < 3; c++) { col[c].resize(L); for (size_t i = 0; i < L; i++) col[c][i] = dense[i][c]; }
        auto at = [&](double sv) {
            return std::array<double, 3>{np_interp(sv, u, col[0]), np_interp(sv, u, col[1]), np_interp(sv, u, col[2])};
        };
        for (size_t i = 1; i + 1 < n; i++) {
            const std::string& k = run[i];
            auto p = at(s[i]);
            if (clear(p[0], p[2], {&run[i - 1], &k, &run[i + 1]})) {
                move(k, p[0], p[1], p[2]);
                node_y[k] = p[1] + lift[i];
            }
        }
        for (size_t i = 0; i + 1 < n; i++) {
            const std::string& a = run[i];
            const std::string& b = run[i + 1];
            double length = s[i + 1] - s[i];
            if (length < 2 * FAIR_MIN_PIECE) continue;
            double e = 0.25;
            auto p0 = at(std::max(0.0, s[i] - e)), p1 = at(s[i] + e);
            auto q0 = at(s[i + 1] - e), q1 = at(std::min(total, s[i + 1] + e));
            double h0 = std::atan2(p1[2] - p0[2], p1[0] - p0[0]);
            double h1 = std::atan2(q1[2] - q0[2], q1[0] - q0[0]);
            double turn = std::fabs(py::mod(h1 - h0 + M_PI, 2 * M_PI) - M_PI);
            long long pieces = std::min<long long>(std::min<long long>((long long)std::ceil(turn / FAIR_MAX_TURN),
                                                                       (long long)py::floordiv(length, FAIR_MIN_PIECE)),
                                                   MAX_PIECES);
            if (pieces < 2) continue;
            std::vector<std::string> chain{a};
            for (long long j = 1; j < pieces; j++) {
                double sv = s[i] + length * (double)j / (double)pieces;
                auto p = at(sv);
                if (!clear(p[0], p[2], {&a, &b})) continue;
                counter++;
                std::string nid = NEW_NODE_PREFIX + std::to_string(counter);
                graph_add(nodes, nid, {p[0], p[1], p[2]}, {});
                grid[cell_of(p[0], p[2])].insert(nid);
                double f = (sv - s[i]) / length;
                node_y[nid] = p[1] + lift[i] + (lift[i + 1] - lift[i]) * f;
                inserted.push_back(nid);
                chain.push_back(nid);
            }
            chain.push_back(b);
            if (chain.size() == 2) continue;
            for (std::string& o : nodes.nodes.at(a).links) if (o == b) o = chain[1];
            for (std::string& o : nodes.nodes.at(b).links) if (o == a) o = chain[chain.size() - 2];
            for (size_t j = 1; j + 1 < chain.size(); j++) {
                auto& l = nodes.nodes.at(chain[j]).links;
                l.push_back(chain[j - 1]);
                l.push_back(chain[j + 1]);
            }
        }
    }
}

}  // namespace smooth

// ---------------------------------------------------------------- build_world helpers
static const double MODULAR_HEIGHT = 16.0;
static const double MODULAR_TRACK_OFFSET = 2.175;
static const double MODULAR_CORNER[2] = {498.5, 501.5};
static const double BORDER_STEP = 0.10;
static const double BORDER_SLIDE_MAX = 3.0;

bool modular_joint(const V3& p, V3& pos, Dir2& d) {
    double x = p[0], y = p[1], z = p[2];
    if (std::fabs(y - MODULAR_HEIGHT) > 0.08) return false;
    double ax = std::fabs(x), az = std::fabs(z);
    double sx = std::copysign(1.0, x), sz = std::copysign(1.0, z);
    if (std::fabs(ax - 500.0) < 0.05 && 2.1 < az && az < 2.25) {
        pos = {sx * 500.0, MODULAR_HEIGHT, sz * MODULAR_TRACK_OFFSET};
        d = {sx, 0.0};
        return true;
    }
    if (std::fabs(az - 500.0) < 0.05 && 2.1 < ax && ax < 2.25) {
        pos = {sx * MODULAR_TRACK_OFFSET, MODULAR_HEIGHT, sz * 500.0};
        d = {0.0, sz};
        return true;
    }
    for (int o = 0; o < 2; o++) {
        double cx = o == 0 ? MODULAR_CORNER[0] : MODULAR_CORNER[1];
        double cz = o == 0 ? MODULAR_CORNER[1] : MODULAR_CORNER[0];
        if (std::fabs(ax - cx) < 0.15 && std::fabs(az - cz) < 0.15) {
            double h = std::sqrt(0.5);
            pos = {sx * cx, MODULAR_HEIGHT, sz * cz};
            d = {sx * h, sz * h};
            return true;
        }
    }
    return false;
}

bool border_normal(const V3& p, V3& n) {
    double half = rails_c::TILE_HALF_SIZE - 0.5;
    if (std::fabs(p[0]) >= half - 2.0 && std::fabs(p[2]) >= half - 2.0) {
        double h = std::sqrt(0.5);
        n = {std::copysign(h, p[0]), 0.0, std::copysign(h, p[2])};
        return true;
    }
    if (std::fabs(p[0]) >= half) { n = {std::copysign(1.0, p[0]), 0.0, 0.0}; return true; }
    if (std::fabs(p[2]) >= half) { n = {0.0, 0.0, std::copysign(1.0, p[2])}; return true; }
    return false;
}

static bool in_links(const Graph& g, const std::string& k, const std::string& o) {
    const auto& l = g.at(k).links;
    return std::find(l.begin(), l.end(), o) != l.end();
}

Prepared prepare_graph(const std::string& rom, const std::string& tile, const Value& scan) {
    Prepared P;
    Graph& nodes = P.nodes;
    nodes = read_tracks(tile_xml_path(rom, tile));
    for (const std::string& k : nodes.order) P.node_y[k] = nodes.at(k).pos[1] + rails_c::GRAPH_RAISE;
    Value stray_all = scan.get("stray", Value::dict());
    Value stray_list = stray_all.get(tile, Value::list());
    for (const Value& v : stray_list.lst()) P.stray.insert(v.str());

    auto set_tangent = [&](const std::string& k, const Dir2& t) {
        if (!P.border_tangents.count(k)) P.tangent_order.push_back(k);
        P.border_tangents[k] = t;
    };
    std::vector<std::string> order0 = nodes.order;
    for (const std::string& k : order0) {
        if (P.stray.count(k)) continue;
        const TrackNode& n = nodes.at(k);
        int deg = 0;
        for (const std::string& o : n.links) if (nodes.has(o) && o != k) deg++;
        if (deg != 1) continue;
        V3 pos;
        Dir2 d;
        if (modular_joint(n.pos, pos, d)) {
            nodes.nodes.at(k).pos = pos;
            P.node_y[k] = pos[1] + rails_c::GRAPH_RAISE;
            set_tangent(k, d);
        }
    }

    struct Plan { V3 q; double y; bool has_t; Dir2 t; };
    std::vector<std::string> planned_order;
    std::unordered_map<std::string, Plan> planned;
    Value partners_all = scan.get("partners", Value::dict());
    Value partners = partners_all.get(tile, Value::dict());
    for (const auto& kv : partners.dct().items) {
        const std::string& k = kv.first;
        const List& e = kv.second.lst();
        double py_ = e[2].num(), dx = e[3].num(), dz = e[4].num(), px = e[5].num(), pz = e[6].num();
        bool has_inner = e.size() > 7;
        if (P.border_tangents.count(k)) continue;
        const TrackNode& n = nodes.at(k);
        const V3& p = n.pos;
        std::vector<std::string> inner;
        for (const std::string& o : n.links) if (nodes.has(o) && o != k) inner.push_back(o);
        if (inner.size() != 1) continue;
        const V3 q0 = nodes.at(inner[0]).pos;
        bool x_edge = std::fabs(std::fabs(p[0]) - 500.0) <= std::fabs(std::fabs(p[2]) - 500.0);
        Dir2 own_dir = {p[0] - q0[0], p[2] - q0[2]};
        Dir2 partner_dir = {-dx, -dz};
        auto slide = [&](double x, double z, const Dir2& d) {
            double across, along, d_across, d_along;
            if (x_edge) { across = x; along = z; d_across = d[0]; d_along = d[1]; }
            else { across = z; along = x; d_across = d[1]; d_along = d[0]; }
            double length = py::hypot(d[0], d[1]);
            if (length < 1e-9 || std::fabs(d_across) / length < 0.3) return along;
            double u = (std::copysign(500.0, across) - across) / d_across;
            if (std::fabs(u) * length > BORDER_SLIDE_MAX) return along;
            return along + d_along * u;
        };
        double along = (slide(p[0], p[2], own_dir) + slide(px, pz, partner_dir)) / 2;
        V3 q;
        if (x_edge) q = {std::copysign(500.0, p[0]), p[1], along};
        else q = {along, p[1], std::copysign(500.0, p[2])};
        double ox = q[0] - q0[0], oz = q[2] - q0[2];
        double olen = py::hypot(ox, oz);
        double tx = ox / olen + dx, tz = oz / olen + dz;
        double tlen = py::hypot(tx, tz);
        double y = (p[1] + py_) / 2;
        if (std::fabs(p[1] - py_) > BORDER_STEP && has_inner) {
            double own_len = py::hypot(p[0] - q0[0], p[2] - q0[2]);
            double qy = e[7].num(), qlen = e[8].num();
            if (own_len > 1.0 && qlen > 1.0) y = q0[1] + (qy - q0[1]) * own_len / (own_len + qlen);
        }
        q = {q[0], y, q[2]};
        Plan pl{q, y + rails_c::GRAPH_RAISE, tlen > 1e-6, {0, 0}};
        if (pl.has_t) pl.t = {tx / tlen, tz / tlen};
        if (!planned.count(k)) planned_order.push_back(k);
        planned[k] = pl;
    }

    auto placed = [&](const std::string& k) -> V3 {
        auto it = planned.find(k);
        return it != planned.end() ? it->second.q : nodes.at(k).pos;
    };
    std::unordered_set<std::string> keep;
    for (const std::string& k : planned_order) {
        V3 q = placed(k);
        for (const std::string& o : nodes.order) {
            if (o == k || in_links(nodes, k, o) || in_links(nodes, o, k)) continue;
            V3 r = placed(o);
            if (std::fabs(r[0] - q[0]) > 2 || std::fabs(r[2] - q[2]) > 2) continue;
            double gap = py::hypot(r[0] - q[0], r[2] - q[2]);
            const V3& nk = nodes.at(k).pos;
            const V3& no = nodes.at(o).pos;
            double before = py::hypot(no[0] - nk[0], no[2] - nk[2]);
            if (gap < smooth::MIN_NODE_GAP && before > gap + 0.05) {
                double moved_k = py::hypot(q[0] - nk[0], q[2] - nk[2]);
                double moved_o = py::hypot(r[0] - no[0], r[2] - no[2]);
                keep.insert(moved_k >= moved_o ? k : o);
            }
        }
    }
    for (const std::string& k : keep) if (planned.at(k).has_t) P.kept.insert(k);
    for (const std::string& k : planned_order) {
        const Plan& pl = planned.at(k);
        if (keep.count(k)) {
            if (pl.has_t) set_tangent(k, pl.t);
            continue;
        }
        nodes.nodes.at(k).pos = pl.q;
        P.node_y[k] = pl.y;
        if (pl.has_t) set_tangent(k, pl.t);
    }
    smooth::smooth_graph(nodes, P.node_y, P.border_tangents, P.stray, P.inserted);
    return P;
}
