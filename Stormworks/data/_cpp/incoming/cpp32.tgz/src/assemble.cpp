// build_world.py step "assemble": unique track meshes, ballast copies, tile XMLs, mod.xml;
// smooth.train_tracks_xml
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <cstdio>
#include <iostream>
#include <map>
#include <set>
#include <unordered_map>
#include "catenary_geom.h"
#include "graph.h"
#include "network.h"
#include "scan.h"
#include "tiles.h"

static const char* MESH_DIR = "meshes/real_track";
static const char* BALLAST_DIR = "meshes/real_track/ballast";
static const char* MOD_NAME = "Stormworks Railway Overhaul (SRO)";
static const char* MOD_VERSION = "1.1.3";
static const char* PLUS_NAME = "SRO Catenary+ (Sawyer)";
static const char* PLUS_VERSION = "1.2.3";
static const char* MOD_AUTHOR = "quadub";
static const char* MOD_XML =
    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
    "<mod name=\"{name}\" author=\"{author}\" "
    "desc=\"v{version}. 3D rails and concrete sleepers on every railway tile of the vanilla map, "
    "smoothed curves, dark grey ballast, kilometre and picket posts on Sawyer and Meier. "
    "Track graph raised by {raise_cm} cm so trains run on the rail heads.\"/>\n";
static const char* PLUS_XML =
    "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
    "<mod name=\"{name}\" author=\"{author}\" "
    "desc=\"v{version}. Stormworks Railway Overhaul with a Soviet / Russian style 25 kV overhead line "
    "(visual) on every track of the Sawyer mainland, after the Soviet standard drawings: concrete poles with "
    "earthed cantilevers and glass insulator strings, direct and reverse registration arms, zigzagged "
    "contact wire on droppers and spring stays, anchor sections with overlaps on traverses, tension "
    "weights, middle anchors, DPR line on the field side, portals with lattice girders, console posts "
    "and working ladders, wires through truss bridges. Includes the whole base SRO "
    "(3D rails and sleepers on every railway tile, smoothed curves, kilometre posts, track graph "
    "raised by {raise_cm} cm): use it instead of SRO, not together with it.\"/>\n";

static std::string replace_all(std::string s, const std::string& from, const std::string& to) {
    if (from.empty()) return s;
    std::string out;
    size_t i = 0;
    while (true) {
        size_t j = s.find(from, i);
        if (j == std::string::npos) { out.append(s, i, std::string::npos); break; }
        out.append(s, i, j - i);
        out += to;
        i = j + from.size();
    }
    return out;
}
static std::string replace_first(const std::string& s, const std::string& from, const std::string& to) {
    size_t j = s.find(from);
    if (j == std::string::npos) return s;
    return s.substr(0, j) + to + s.substr(j + from.size());
}
static std::string rstrip(const std::string& s) {
    size_t e = s.size();
    while (e > 0 && (is_space(s[e - 1]) || s[e - 1] == '\x1c' || s[e - 1] == '\x1d' || s[e - 1] == '\x1e' || s[e - 1] == '\x1f')) e--;
    return s.substr(0, e);
}
static bool word_char(char c) { return is_word(c) || (unsigned char)c >= 0x80; }
static std::string f6(double x) { return py::fmt_f(x, 6); }

// r'\b(3[012])="([^"]*)"' matches: (start, end, key, value)
struct AttrHit { size_t start, end; std::string key, value; };
static std::vector<AttrHit> find_3x(const std::string& s, const std::string* only_key) {
    std::vector<AttrHit> out;
    size_t i = 0;
    while (i + 4 < s.size() + 1) {
        if (i + 4 > s.size()) break;
        bool boundary = i == 0 || !word_char(s[i - 1]);
        if (boundary && s[i] == '3' && i + 1 < s.size() && (s[i + 1] == '0' || s[i + 1] == '1' || s[i + 1] == '2') && i + 3 < s.size() &&
            s[i + 2] == '=' && s[i + 3] == '"') {
            std::string key = s.substr(i, 2);
            if (!only_key || key == *only_key) {
                size_t q = s.find('"', i + 4);
                if (q != std::string::npos) {
                    out.push_back({i, q + 1, key, s.substr(i + 4, q - i - 4)});
                    i = q + 1;
                    continue;
                }
            }
        }
        i++;
    }
    return out;
}

std::string train_tracks_xml(const std::string& original_text, const Value& graph, const Value& new_y, const std::string& newline, double raise_kept) {
    size_t b0 = original_text.find("<train_tracks>");
    if (b0 == std::string::npos) throw std::runtime_error("no <train_tracks>");
    size_t b1 = original_text.find("</train_tracks>", b0 + 14);
    if (b1 == std::string::npos) throw std::runtime_error("no </train_tracks>");
    b1 += 15;
    std::string block = original_text.substr(b0, b1 - b0);
    std::vector<std::string> attrs_order;
    std::unordered_map<std::string, std::string> original_attrs, element_attrs;
    std::vector<std::string> kept_blocks;
    // re.finditer(r'<track id="([^"]+)"([^>]*)>(\s*<transform([^/]*)/>.*?)</track>', block, re.S)
    static const std::string pre = "<track id=\"";
    size_t i = 0;
    while ((i = block.find(pre, i)) != std::string::npos) {
        size_t start = i;
        bool ok = false;
        size_t id0 = i + pre.size();
        size_t q = block.find('"', id0);
        if (q != std::string::npos && q > id0) {
            size_t gt = block.find('>', q + 1);
            if (gt != std::string::npos) {
                size_t body0 = gt + 1, p = body0;
                while (p < block.size() && is_space(block[p])) p++;
                if (block.compare(p, 10, "<transform") == 0) {
                    size_t t0 = p + 10;
                    size_t slash = block.find('/', t0);
                    if (slash != std::string::npos && slash + 1 < block.size() && block[slash + 1] == '>') {
                        size_t close = block.find("</track>", slash + 2);
                        if (close != std::string::npos) {
                            ok = true;
                            std::string node_id = block.substr(id0, q - id0);
                            std::string extra = block.substr(q + 1, gt - q - 1);
                            std::string body = block.substr(body0, close - body0);
                            std::string transform = block.substr(t0, slash - t0);
                            if (graph.has(node_id)) {
                                if (!original_attrs.count(node_id)) attrs_order.push_back(node_id);
                                original_attrs[node_id] = transform;
                                element_attrs[node_id] = extra;
                            } else {
                                static const std::string k31 = "31";
                                auto hits = find_3x(transform, &k31);
                                std::string lifted;
                                if (!hits.empty()) {
                                    std::string whole = transform.substr(hits[0].start, hits[0].end - hits[0].start);
                                    lifted = replace_all(transform, whole, "31=\"" + f6(std::strtod(hits[0].value.c_str(), nullptr) + raise_kept) + "\"");
                                } else {
                                    lifted = rstrip(transform) + " 31=\"" + f6(raise_kept) + "\"";
                                }
                                kept_blocks.push_back("\t\t<track id=\"" + node_id + "\"" + extra + ">" + replace_first(body, transform, lifted) + "</track>");
                            }
                            i = close + 8;
                        }
                    }
                }
            }
        }
        if (!ok) i = start + 1;
    }
    std::vector<std::string> order = attrs_order;
    for (const auto& kv : graph.dct().items) if (!original_attrs.count(kv.first)) order.push_back(kv.first);
    std::vector<std::string> lines{"<train_tracks>"};
    for (const std::string& k : order) {
        const Value& g = *graph.dct().find(k);
        double px = g[0].num(), pz = g[2].num();
        const Value& links = g[3];
        std::string attrs;
        double y = new_y.get(k).num();
        auto oa = original_attrs.find(k);
        if (oa != original_attrs.end()) {
            attrs = oa->second;
            std::map<std::string, std::string> old;
            for (auto& h : find_3x(attrs, nullptr)) old[h.key] = h.value;
            std::vector<std::pair<std::string, double>> values{{"31", y}};
            auto oldf = [&](const char* key) { auto it = old.find(key); return it == old.end() ? 0.0 : std::strtod(it->second.c_str(), nullptr); };
            if (std::fabs(oldf("30") - px) > 1e-5) values.push_back({"30", px});
            if (std::fabs(oldf("32") - pz) > 1e-5) values.push_back({"32", pz});
            for (auto& [key, number] : values) {
                std::string text = key + "=\"" + f6(number) + "\"";
                if (old.count(key)) {
                    // re.sub(r'\b%s="[^"]*"' % key, text, attrs)
                    std::string out;
                    size_t last = 0;
                    for (auto& h : find_3x(attrs, &key)) {
                        out.append(attrs, last, h.start - last);
                        out += text;
                        last = h.end;
                    }
                    out.append(attrs, last, std::string::npos);
                    attrs = out;
                } else {
                    attrs = rstrip(attrs) + " " + text;
                }
            }
        } else {
            attrs = " 30=\"" + f6(px) + "\" 31=\"" + f6(y) + "\" 32=\"" + f6(pz) + "\"";
        }
        auto ea = element_attrs.find(k);
        lines.push_back("\t\t<track id=\"" + k + "\"" + (ea == element_attrs.end() ? std::string() : ea->second) + ">");
        lines.push_back("\t\t\t<transform" + attrs + "/>");
        if (links.size()) {
            lines.push_back("\t\t\t<links>");
            for (const Value& o : links.lst()) lines.push_back("\t\t\t\t<link id=\"" + o.str() + "\"/>");
            lines.push_back("\t\t\t</links>");
        } else {
            lines.push_back("\t\t\t<links/>");
        }
        lines.push_back("\t\t</track>");
    }
    for (auto& kb : kept_blocks) lines.push_back(kb);
    lines.push_back("\t</train_tracks>");
    std::string joined;
    for (size_t k = 0; k < lines.size(); k++) { if (k) joined += newline; joined += lines[k]; }
    return original_text.substr(0, b0) + joined + original_text.substr(b1);
}

static std::string ballast_copy_name(const std::string& file_name) {
    return std::string(BALLAST_DIR) + "/" + replace_all(file_name.substr(std::string("meshes/").size()), "/", "__");
}

static std::string append_to_section(const std::string& text, const std::string& section, const std::string& block, const std::string& newline) {
    if (block.empty()) return text;
    std::string closing = "</" + section + ">";
    size_t idx = text.find(closing);
    if (idx != std::string::npos) {
        size_t nl = idx == 0 ? std::string::npos : text.rfind('\n', idx - 1);
        size_t line_start = nl == std::string::npos ? 0 : nl + 1;
        return text.substr(0, line_start) + block + text.substr(line_start);
    }
    std::string empty = "<" + section + "/>";
    if (text.find(empty) == std::string::npos) throw std::runtime_error("no <" + section + "> section");
    return replace_first(text, empty, "<" + section + ">" + newline + block + "\t" + closing);
}

static std::string format_mod(const char* tmpl, const std::string& name, const std::string& author, const std::string& version, long long raise_cm) {
    std::string s = tmpl;
    s = replace_all(s, "{name}", name);
    s = replace_all(s, "{author}", author);
    s = replace_all(s, "{version}", version);
    s = replace_all(s, "{raise_cm}", std::to_string(raise_cm));
    return s;
}

void step_assemble(const std::string& rom, const std::string& work) {
    Value scan = json::load(work + "/scan.json");
    std::string mod = work + "/mod";
    std::string raw_dir = work + "/track_meshes";
    std::string mesh_dir = mod + "/" + MESH_DIR;
    make_dirs(mesh_dir);
    std::vector<std::string> tiles;
    for (const Value& t : scan.get("tiles").lst()) tiles.push_back(t.str());
    // identical track mesh files are stored once (first in tile order), shared by name
    std::unordered_map<std::string, std::string> stored_name;
    // size -> [(stored name, content hash or none)]; like Python's md5 entries, hashed only on a size match
    struct Entry { std::string name; bool hashed = false; uint64_t hash = 0; };
    std::map<uintmax_t, std::vector<Entry>> by_size;
    auto fnv = [](const std::string& d) {
        uint64_t h = 1469598103934665603ULL;
        for (unsigned char c : d) { h ^= c; h *= 1099511628211ULL; }
        return h;
    };
    long long duplicates = 0;
    for (const std::string& tile : tiles) {
        Value state = json::load(work + "/tiles/" + tile + ".json");
        std::vector<std::string> names;
        for (const char* key : {"files", "phys_files"})
            for (const Value& f : state.get(key).lst()) names.push_back(f[1].str());
        for (const std::string& file_name : names) {
            if (stored_name.count(file_name)) continue;
            std::string source = raw_dir + "/" + file_name;
            if (!file_exists(source)) { stored_name[file_name] = file_name; continue; }
            uintmax_t size = std::filesystem::file_size(source);
            auto& same = by_size[size];
            std::string match;
            uint64_t digest = 0;
            bool has_digest = false;
            if (!same.empty()) {
                std::string data = read_file(source);
                digest = fnv(data);
                has_digest = true;
                for (auto& entry : same) {
                    if (!entry.hashed) { entry.hash = fnv(read_file(mesh_dir + "/" + entry.name)); entry.hashed = true; }
                    if (entry.hash == digest && read_file(mesh_dir + "/" + entry.name) == data) { match = entry.name; break; }
                }
            }
            if (!match.empty()) {
                stored_name[file_name] = match;
                duplicates++;
                continue;
            }
            same.push_back({file_name, has_digest, digest});
            stored_name[file_name] = file_name;
            if (std::rename(source.c_str(), (mesh_dir + "/" + file_name).c_str()) != 0)
                throw std::runtime_error("cannot move " + source);
        }
    }
    by_size.clear();
    std::cout << "meshes stored " << stored_name.size() << "  duplicates " << duplicates << std::endl;

    std::string ballast = mod + "/" + BALLAST_DIR;
    make_dirs(ballast);
    Value recolor = scan.get("recolor");
    for (const auto& kv : recolor.dct().items) {
        const std::string& file_name = kv.first;
        std::string target = mod + "/" + ballast_copy_name(file_name);
        if (file_exists(target)) continue;
        std::string data = read_file(rom + "/" + file_name);
        for (const Value& e : kv.second.lst()) {
            size_t at = 14 + 28 * (size_t)e[0].integer() + 12;
            data[at] = (char)e[1].integer();
            data[at + 1] = (char)e[2].integer();
            data[at + 2] = (char)e[3].integer();
        }
        write_file(target, data);
    }

    std::map<std::string, std::vector<LadderElement>> ladders;
    bool plus = file_exists(work + "/catenary.json");
    if (plus) {
        Value plan = json::load(work + "/catenary.json");
        std::set<std::string> tile_set(tiles.begin(), tiles.end());
        for (const LadderElement& l : portal_ladders(plan)) {
            std::string tile = "mega_island_" + std::to_string((long long)std::floor((l.foot[0] + 8500) / 1000)) + "_" +
                               std::to_string((long long)std::floor((l.foot[2] + 12500) / 1000));
            if (tile_set.count(tile)) ladders[tile].push_back(l);
        }
    }

    std::string tiles_out = mod + "/data/tiles";
    make_dirs(tiles_out);
    long long total_ladders = 0, total_entries = 0, total_phys = 0, total_vertices = 0;
    for (const std::string& tile : tiles) {
        Value state = json::load(work + "/tiles/" + tile + ".json");
        total_vertices += state.get("vertices").integer();
        if (file_exists(tiles_out + "/" + tile + ".xml")) continue;
        std::string text = read_file(tile_xml_path(rom, tile));
        std::string newline = text.find("\r\n") != std::string::npos ? "\r\n" : "\n";
        text = train_tracks_xml(text, state.get("graph"), state.get("node_y"), newline, rails_c::GRAPH_RAISE);
        for (const auto& kv : recolor.dct().items)
            text = replace_all(text, "file_name=\"" + kv.first + "\"", "file_name=\"" + ballast_copy_name(kv.first) + "\"");
        std::string entries;
        long long n_entries = 0;
        for (const Value& f : state.get("files").lst()) {
            entries += "\t\t<mesh id=\"real_track_" + f[0].str() + "\" file_name=\"" + MESH_DIR + "/" + stored_name.at(f[1].str()) + "\">" + newline +
                       "\t\t\t<transform/>" + newline + "\t\t</mesh>" + newline;
            n_entries++;
        }
        text = append_to_section(text, "meshes", entries, newline);
        std::string phys_entries;
        long long n_phys = 0;
        for (const Value& f : state.get("phys_files").lst()) {
            phys_entries += "\t\t<physics_mesh id=\"real_track_phys_" + f[0].str() + "\" file_name=\"" + MESH_DIR + "/" + stored_name.at(f[1].str()) +
                            "\">" + newline + "\t\t\t<transform/>" + newline + "\t\t</physics_mesh>" + newline;
            n_phys++;
        }
        text = append_to_section(text, "physics_meshes", phys_entries, newline);
        total_phys += n_phys;
        auto lit = ladders.find(tile);
        if (lit != ladders.end()) {
            double ox, oz;
            mainland_origin(tile, ox, oz);
            std::string le;
            for (size_t i = 0; i < lit->second.size(); i++) {
                const LadderElement& l = lit->second[i];
                le += "\t\t<ladder id=\"real_track_ladder_" + std::to_string(i) + "\" height=\"" + py::fmt_f(l.height, 3) + "\">" + newline +
                      "\t\t\t<transform 00=\"" + f6(l.x_axis[0]) + "\" 02=\"" + f6(l.x_axis[2]) + "\" 20=\"" + f6(l.z_axis[0]) + "\" 22=\"" + f6(l.z_axis[2]) +
                      "\" 30=\"" + f6(l.foot[0] - ox) + "\" 31=\"" + f6(l.foot[1]) + "\" 32=\"" + f6(l.foot[2] - oz) + "\"/>" + newline + "\t\t</ladder>" +
                      newline;
            }
            text = append_to_section(text, "ladders", le, newline);
            total_ladders += (long long)lit->second.size();
        }
        write_file(tiles_out + "/" + tile + ".xml", text);
        total_entries += n_entries;
    }
    long long raise_cm = py::round_int(rails_c::GRAPH_RAISE * 100);
    write_file(mod + "/mod.xml", plus ? format_mod(PLUS_XML, PLUS_NAME, MOD_AUTHOR, PLUS_VERSION, raise_cm)
                                      : format_mod(MOD_XML, MOD_NAME, MOD_AUTHOR, MOD_VERSION, raise_cm));
    std::cout << "tiles " << tiles.size() << "  mesh entries added " << total_entries << "  track vertices " << total_vertices
              << "  physics entries added " << total_phys << "  shared duplicate files " << duplicates << "  ladders " << total_ladders << std::endl;
    std::cout << "done" << std::endl;
}
