#pragma once
#include <string>
void step_tiles(const std::string& rom, const std::string& work, int workers = 2);
void step_assemble(const std::string& rom, const std::string& work);
