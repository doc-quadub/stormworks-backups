// signs.py geometry: kilometre / picket posts, whistle signs; Frame and box helpers shared with
// the overhead line
#pragma once
#include <vector>
#include "geom.h"
#include "value.h"

struct Frame {
    V3 o, t, r;
    Frame(const V3& origin, const D2& tt) : o(origin), t{tt[0], 0.0, tt[1]} {
        D2 rr = vec::right_of(tt);
        r = {rr[0], 0.0, rr[1]};
    }
    V3 at(double along, double side, double up) const {
        return {o[0] + t[0] * along + r[0] * side, o[1] + up, o[2] + t[2] * along + r[2] * side};
    }
};

struct Band { double y0, y1; Color color; };
void sign_box(Builder& builder, const Frame& frame, double half_t, double half_r, double y0, double y1,
              const std::vector<Band>& colors_by_band, const D2& anchor, bool top = true);
void add_box_collision(Builder& builder, const Frame& frame, double half_t, double half_r, double y0, double y1, const D2& anchor);
void add_sign(Builder& builder, const Value& sign);
