#include "geom.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

double CHUNK_SIZE = 125.0;
static const size_t MAX_VERTICES_PER_MESH = 60000;

V3 polygon_normal(const std::vector<V3>& points) {
    double nx = 0.0, ny = 0.0, nz = 0.0;
    size_t n = points.size();
    for (size_t i = 0; i < n; i++) {
        const V3& a = points[i];
        const V3& b = points[(i + 1) % n];
        nx += (a[1] - b[1]) * (a[2] + b[2]);
        ny += (a[2] - b[2]) * (a[0] + b[0]);
        nz += (a[0] - b[0]) * (a[1] + b[1]);
    }
    return vec::norm({nx, ny, nz});
}

void Builder::polygon(std::vector<V3> points, const Color& color, const D2& anchor, const V3& outward) {
    V3 n = polygon_normal(points);
    if (vec::dot(n, outward) < 0) {
        std::reverse(points.begin() + 1, points.end());       // [points[0]] + points[:0:-1]
        n = vec::mul(n, -1.0);
    }
    Poly p;
    p.pts = std::move(points);
    p.n = n;
    p.color = color;
    p.anchor = anchor;
    polys.push_back(std::move(p));
}

std::string fmt_plus(long long v) {
    char buf[32];
    std::snprintf(buf, sizeof buf, "%+lld", v);
    return buf;
}

static Mesh polys_to_mesh(const std::vector<const Poly*>& polys) {
    Mesh mesh;
    std::vector<uint32_t> idx;
    bool first = true;
    double lo[3] = {0, 0, 0}, hi[3] = {0, 0, 0};
    auto push = [&](const V3& p, const V3& n, const Color& c) {
        MeshVertex v;
        v.x = (float)p[0]; v.y = (float)p[1]; v.z = (float)p[2];
        v.r = c[0]; v.g = c[1]; v.b = c[2]; v.a = c[3];
        v.nx = (float)n[0]; v.ny = (float)n[1]; v.nz = (float)n[2];
        mesh.vertices.push_back(v);
        for (int k = 0; k < 3; k++) {
            if (first) { lo[k] = hi[k] = p[k]; }
            else {
                if (p[k] < lo[k]) lo[k] = p[k];       // numpy min / max (no NaN here)
                if (p[k] > hi[k]) hi[k] = p[k];
            }
        }
        first = false;
    };
    for (const Poly* poly : polys) {
        uint32_t base = (uint32_t)mesh.vertices.size();
        if (poly->strip) {
            for (size_t i = 0; i < poly->pts.size(); i++) push(poly->pts[i], poly->normals[i], poly->colors[i]);
            for (const auto& t : poly->tris) { idx.push_back(base + t[0]); idx.push_back(base + t[1]); idx.push_back(base + t[2]); }
            continue;
        }
        for (const V3& p : poly->pts) push(p, poly->n, poly->color);
        uint32_t count = (uint32_t)poly->pts.size();
        for (uint32_t i = 1; i + 1 < count; i++) { idx.push_back(base); idx.push_back(base + i + 1); idx.push_back(base + i); }
    }
    for (uint32_t i : idx) {
        if (i > 65535) throw std::runtime_error("mesh index out of range");
        mesh.indices.push_back((uint16_t)i);
    }
    Submesh sm;
    sm.index_start = 0;
    sm.index_count = (uint32_t)idx.size();
    sm.shader = 0;
    for (int k = 0; k < 3; k++) { sm.bounds_min[k] = (float)lo[k]; sm.bounds_max[k] = (float)hi[k]; }
    mesh.submeshes.push_back(sm);
    return mesh;
}

std::vector<std::pair<std::string, Mesh>> polys_to_meshes(const std::vector<Poly>& polys) {
    std::map<std::pair<long long, long long>, std::vector<const Poly*>> chunks;
    for (const Poly& p : polys)
        chunks[{(long long)std::floor(p.anchor[0] / CHUNK_SIZE), (long long)std::floor(p.anchor[1] / CHUNK_SIZE)}].push_back(&p);
    std::vector<std::pair<std::string, Mesh>> meshes;
    for (auto& [key, list] : chunks) {
        int part = 0;
        std::vector<const Poly*> batch;
        size_t count = 0;
        auto flush = [&]() {
            if (!batch.empty()) {
                meshes.push_back({"c" + fmt_plus(key.first) + "_" + fmt_plus(key.second) + "_" + std::to_string(part), polys_to_mesh(batch)});
                part++;
            }
            batch.clear();
            count = 0;
        };
        for (const Poly* poly : list) {
            if (count + poly->pts.size() > MAX_VERTICES_PER_MESH) flush();
            batch.push_back(poly);
            count += poly->pts.size();
        }
        flush();
    }
    return meshes;
}

std::vector<std::pair<std::string, std::vector<std::array<V3, 3>>>> collision_to_phys_chunks(
    const std::vector<std::pair<std::array<V3, 3>, D2>>& collision) {
    std::map<std::pair<long long, long long>, std::vector<std::array<V3, 3>>> chunks;
    for (const auto& [tri, a] : collision)
        chunks[{(long long)std::floor(a[0] / CHUNK_SIZE), (long long)std::floor(a[1] / CHUNK_SIZE)}].push_back(tri);
    std::vector<std::pair<std::string, std::vector<std::array<V3, 3>>>> out;
    for (auto& [key, tris] : chunks) out.push_back({"c" + fmt_plus(key.first) + "_" + fmt_plus(key.second), tris});
    return out;
}
