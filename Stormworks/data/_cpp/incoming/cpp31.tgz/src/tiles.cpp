// build_world.py step "tiles": geometry, collision and state file of every tile (2 worker threads)
#include <atomic>
#include <cmath>
#include <cstdio>
#include <iostream>
#include <mutex>
#include <thread>
#include "catenary_geom.h"
#include "graph.h"
#include "network.h"
#include "rails_geom.h"
#include "signs_geom.h"
#include "tiles.h"

static const double SHALLOW_CROSSING_COS = 0.7;
static const double PRISM_NEAR = 8.0;
static const double TILES_CHUNK_SIZE = 250.0;

static std::string safe_name(std::string s) {
    for (char& c : s) { if (c == '+') c = 'p'; else if (c == '-') c = 'm'; }
    return s;
}

struct TileJob {
    std::string rom, work;
    Value scan, signs, plan;
    bool has_plan = false;
};

static std::string build_one_tile(const TileJob& job, const std::string& tile) {
    Prepared P = prepare_graph(job.rom, tile, job.scan);
    // drawn = nodes without the stray ones (dict order kept)
    std::vector<std::string> order;
    std::unordered_map<std::string, V3> pos;
    std::unordered_map<std::string, std::vector<std::string>> links;
    for (const std::string& k : P.nodes.order) {
        if (P.stray.count(k)) continue;
        order.push_back(k);
        pos[k] = P.nodes.at(k).pos;
        links[k] = P.nodes.at(k).links;
    }
    std::unordered_map<std::string, BorderCut> border_cuts;
    for (const std::string& k : order) {
        const V3& p = pos[k];
        auto bt = P.border_tangents.find(k);
        if (P.kept.count(k) && bt != P.border_tangents.end()) {
            V3 t3{bt->second[0], 0.0, bt->second[1]};
            border_cuts[k] = BorderCut{t3, true, t3};
            continue;
        }
        V3 n;
        if (!border_normal(p, n)) continue;
        int inner = 0;
        for (const std::string& o : links[k]) if (pos.count(o) && o != k) inner++;
        if (inner != 1) continue;
        if (bt != P.border_tangents.end()) {
            V3 t3{bt->second[0], 0.0, bt->second[1]};
            if (std::fabs(vec::dot(n, t3)) < SHALLOW_CROSSING_COS) border_cuts[k] = BorderCut{t3, true, t3};
            else border_cuts[k] = BorderCut{n, true, t3};
        } else {
            border_cuts[k] = BorderCut{n, false, {}};
        }
    }
    // ballast prism near the scan's prism spots
    std::function<bool(const V3&)> keep;
    bool has_keep = false;
    std::map<std::pair<long long, long long>, std::vector<D2>> cells;
    if (job.scan.has("prism")) {
        Value prism = job.scan.get("prism");
        Value spots = prism.has(tile) ? prism.get(tile) : Value();
        if (spots.truthy()) {
            for (const Value& s : spots.lst()) {
                double x = s[0].num(), z = s[1].num();
                cells[{(long long)py::floordiv(x, PRISM_NEAR), (long long)py::floordiv(z, PRISM_NEAR)}].push_back({x, z});
            }
            keep = [&cells](const V3& p) {
                long long cx = (long long)py::floordiv(p[0], PRISM_NEAR), cz = (long long)py::floordiv(p[2], PRISM_NEAR);
                for (long long ix = cx - 1; ix <= cx + 1; ix++)
                    for (long long iz = cz - 1; iz <= cz + 1; iz++) {
                        auto it = cells.find({ix, iz});
                        if (it == cells.end()) continue;
                        for (const D2& q : it->second)
                            if (py::hypot(q[0] - p[0], q[1] - p[2]) < PRISM_NEAR) return true;
                    }
                return false;
            };
            has_keep = true;
        }
    }
    Builder builder;
    size_t chain_count = 0;
    long long sleeper_count = build_tile_v4(builder, order, pos, links, P.node_y, border_cuts, has_keep ? &keep : nullptr, &chain_count);
    long long posts = 0;
    if (job.signs.has(tile)) {
        for (const Value& sign : job.signs.get(tile).lst()) { add_sign(builder, sign); posts++; }
    }
    double ox, oz;
    if (job.has_plan && mainland_origin(tile, ox, oz)) add_catenary(builder, job.plan, tile, ox, oz);
    std::string out_dir = job.work + "/track_meshes";
    Value files = Value::list(), phys_files = Value::list();
    long long vertices = 0;
    for (auto& [chunk_name, mesh] : polys_to_meshes(builder.polys)) {
        std::string safe = safe_name(chunk_name);
        std::string file_name = tile + "_" + safe + ".mesh";
        write_mesh(out_dir + "/" + file_name, mesh);
        files.append(Value::list({Value(safe), Value(file_name)}));
        vertices += (long long)mesh.vertices.size();
    }
    for (auto& [chunk_name, tris] : collision_to_phys_chunks(builder.collision)) {
        std::string safe = safe_name(chunk_name);
        std::string file_name = tile + "_" + safe + ".phys";
        write_phys(out_dir + "/" + file_name, tris);
        phys_files.append(Value::list({Value(safe), Value(file_name)}));
    }
    Value state = Value::dict();
    Value ny = Value::dict(), graph = Value::dict();
    for (const std::string& k : P.nodes.order) {
        ny[k] = Value(P.node_y.at(k));
        const TrackNode& n = P.nodes.at(k);
        Value ls = Value::list();
        for (const std::string& o : n.links) ls.append(Value(o));
        graph[k] = Value::list({Value(n.pos[0]), Value(n.pos[1]), Value(n.pos[2]), ls});
    }
    state["node_y"] = ny;
    state["files"] = files;
    state["phys_files"] = phys_files;
    state["placements"] = Value::list();
    state["vertices"] = Value(vertices);
    state["collision_triangles"] = Value((long long)builder.collision.size());
    state["graph"] = graph;
    std::string state_path = job.work + "/tiles/" + tile + ".json";
    json::dump(state, state_path + ".tmp");
    std::rename((state_path + ".tmp").c_str(), state_path.c_str());
    char line[512];
    std::snprintf(line, sizeof line, "%-45s chains %3zu  added nodes %4zu  sleepers %6lld  posts %3lld  vertices %8lld  meshes %3zu", tile.c_str(),
                  chain_count, P.inserted.size(), sleeper_count, posts, vertices, files.size());
    return line;
}

void step_tiles(const std::string& rom, const std::string& work, int workers) {
    railsg::RAIL_PIECE_LENGTH = 1e9;
    CHUNK_SIZE = TILES_CHUNK_SIZE;
    make_dirs(work + "/track_meshes");
    make_dirs(work + "/tiles");
    TileJob job;
    job.rom = rom;
    job.work = work;
    job.scan = json::load(work + "/scan.json");
    job.signs = file_exists(work + "/signs.json") ? json::load(work + "/signs.json") : Value::dict();
    if (file_exists(work + "/catenary.json")) { job.plan = json::load(work + "/catenary.json"); job.has_plan = true; }
    std::vector<std::string> pending;
    for (const Value& t : job.scan.get("tiles").lst())
        if (!file_exists(work + "/tiles/" + t.str() + ".json")) pending.push_back(t.str());
    std::atomic<size_t> next{0};
    std::mutex out_mutex;
    std::string error;
    auto worker = [&]() {
        while (true) {
            size_t i = next.fetch_add(1);
            if (i >= pending.size()) return;
            try {
                std::string line = build_one_tile(job, pending[i]);
                std::lock_guard<std::mutex> lock(out_mutex);
                std::cout << line << std::endl;
            } catch (const std::exception& e) {
                std::lock_guard<std::mutex> lock(out_mutex);
                error = pending[i] + ": " + e.what();
                std::cerr << "error " << error << std::endl;
            }
        }
    };
    std::vector<std::thread> threads;
    for (int w = 0; w < std::max(1, workers); w++) threads.emplace_back(worker);
    for (auto& t : threads) t.join();
    if (!error.empty()) throw std::runtime_error(error);
    std::cout << "remaining 0\ndone" << std::endl;
}
