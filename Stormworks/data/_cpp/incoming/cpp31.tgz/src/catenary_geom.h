// catenary.py geometry: add_catenary (poles, consoles, fixators, portals, wires, DPR) and portal_ladders
#pragma once
#include <string>
#include <vector>
#include "geom.h"
#include "value.h"

long long add_catenary(Builder& builder, const Value& plan, const std::string& tile, double ox, double oz);
struct LadderElement { V3 foot, x_axis, z_axis; double height; };
std::vector<LadderElement> portal_ladders(const Value& plan);
