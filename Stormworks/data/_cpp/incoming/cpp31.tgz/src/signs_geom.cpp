// Port of signs.py geometry
#include "signs_geom.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <optional>
#include <set>
#include <string>

using namespace vec;

static const double POST_SIDE = 0.16;
static const double POST_BURIED = 0.40;
static const double KM_POST_HEIGHT = 2.10;
static const double KM_POST_BLACK = 0.25;
static const double KM_PLATE_HEIGHT = 0.27;
static const double KM_PLATE_THICKNESS = 0.03;
static double km_plate_width(int d) { return d == 1 ? 0.30 : d == 2 ? 0.30 : d == 3 ? 0.36 : 0.45; }
struct DigitSpec { double height; double columns[3]; double rows[5]; double gap[5]; };
static const DigitSpec KM_DIGIT = {0.17, {0.020, 0.035, 0.020}, {0.020, 0.055, 0.020, 0.055, 0.020}, {0, 0.0, 0.030, 0.019, 0.024}};
static const double PICKET_BLACK = 0.21;
static const double PICKET_WHITE_BELOW = 0.05;
static const double PICKET_NUMBER_BAND = 0.15;
static const double PICKET_WHITE_ABOVE = 0.05;
static const double PICKET_TOP = 0.50;
static const DigitSpec PICKET_DIGIT = {0.11, {0.015, 0.020, 0.015}, {0.015, 0.0325, 0.015, 0.0325, 0.015}, {0, 0.0, 0.010, 0, 0}};
static const double WHISTLE_POST_HEIGHT = 1.75;
static const double WHISTLE_POST_BLACK = 0.25;
static const double WHISTLE_BAND = 0.10;
static const double WHISTLE_PLATE_WIDTH = 0.35;
static const double WHISTLE_PLATE_HEIGHT = 0.47;
static const double WHISTLE_PLATE_BOTTOM = 0.22;
static const double WHISTLE_ROUND_FROM = 0.295;
static const double WHISTLE_GREEN = 0.17;
static const double WHISTLE_BORDER = 0.012;
static const double L_CENTRE = 0.32, L_HALF_WIDTH = 0.065, L_HALF_HEIGHT = 0.12, L_STROKE = 0.025, L_GAP = 0.05;
static const double WHISTLE_ROW = 0.006;
static const Color COLOR_GREEN = {36, 118, 62, 255};
static const Color COLOR_PLATE_BACK = {112, 112, 110, 255};
static const Color COLOR_BLACK = {28, 28, 28, 255};
static const Color COLOR_POST = {205, 205, 200, 255};
static const Color COLOR_PLATE = {236, 236, 232, 255};
static const Color COLOR_DIGIT = {18, 18, 18, 255};
static const char* DIGITS[10][5] = {
    {"111", "101", "101", "101", "111"}, {"010", "010", "010", "010", "010"}, {"111", "001", "111", "100", "111"},
    {"111", "001", "011", "001", "111"}, {"101", "101", "111", "001", "001"}, {"111", "100", "111", "001", "111"},
    {"111", "100", "111", "101", "111"}, {"111", "001", "001", "001", "001"}, {"111", "101", "111", "101", "111"},
    {"111", "101", "111", "001", "111"}};

// ---------------------------------------------------------------- numbers
struct Owner { int digit = -1, column = -1; };     // digit -1: gap or margin
static void number_layout(const std::string& text, const DigitSpec& spec, double area_width, std::vector<double>& widths, std::vector<Owner>& owner) {
    int count = (int)text.size();
    double gap = spec.gap[count];
    double digit_width = 0.0;
    for (double c : spec.columns) digit_width += c;
    double total = count * digit_width + (count - 1) * gap;
    double margin = (area_width - total) / 2;
    widths.push_back(margin);
    owner.push_back({});
    for (int d = 0; d < count; d++) {
        if (d) { widths.push_back(gap); owner.push_back({}); }
        for (int c = 0; c < 3; c++) { widths.push_back(spec.columns[c]); owner.push_back({d, c}); }
    }
    widths.push_back(margin);
    owner.push_back({});
}

struct Rect { double u0, u1, v0, v1; bool digit; };      // digit: COLOR_DIGIT, else None
static std::vector<Rect> face_rects(const std::string& text, const DigitSpec& spec, double area_width, double area_height, double number_bottom) {
    std::vector<double> widths;
    std::vector<Owner> owner;
    number_layout(text, spec, area_width, widths, owner);
    double rows_sum = 0.0;
    for (double r : spec.rows) rows_sum += r;
    std::vector<double> heights{number_bottom};
    std::vector<int> row_index{-1};
    for (int k = 4; k >= 0; k--) { heights.push_back(spec.rows[k]); row_index.push_back(k); }
    heights.push_back(area_height - number_bottom - rows_sum);
    row_index.push_back(-1);
    std::vector<Rect> rects;
    double v = 0.0;
    for (size_t b = 0; b < heights.size(); b++) {
        double h = heights[b];
        int r = row_index[b];
        if (h > 1e-6) {
            struct Run { double u0, u1; bool digit; };
            std::vector<Run> runs;
            double u = -area_width / 2;
            for (size_t c = 0; c < widths.size(); c++) {
                double w = widths[c];
                const Owner& own = owner[c];
                bool black = r >= 0 && own.digit >= 0 && DIGITS[text[own.digit] - '0'][r][own.column] == '1';
                if (w > 1e-9) {
                    if (!runs.empty() && runs.back().digit == black) runs.back().u1 = u + w;
                    else runs.push_back({u, u + w, black});
                }
                u += w;
            }
            for (auto& rn : runs) rects.push_back({rn.u0, rn.u1, v, v + h, rn.digit});
        }
        v += h;
    }
    return rects;
}

// ---------------------------------------------------------------- boxes
void sign_box(Builder& builder, const Frame& frame, double half_t, double half_r, double y0, double y1,
              const std::vector<Band>& colors_by_band, const D2& anchor, bool top) {
    (void)y0;
    const int sides[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
    for (auto& s : sides) {
        int st = s[0], sr = s[1];
        double ht = half_t, hr = half_r;
        V3 outward{frame.t[0] * st + frame.r[0] * sr, 0.0, frame.t[2] * st + frame.r[2] * sr};
        double a0, a1, b0, b1;
        if (st) { a0 = st * ht; a1 = -hr; b0 = st * ht; b1 = hr; }
        else { a0 = -ht; a1 = sr * hr; b0 = ht; b1 = sr * hr; }
        for (const Band& band : colors_by_band)
            builder.polygon({frame.at(a0, a1, band.y0), frame.at(b0, b1, band.y0), frame.at(b0, b1, band.y1), frame.at(a0, a1, band.y1)},
                            band.color, anchor, outward);
    }
    if (top)
        builder.polygon({frame.at(-half_t, -half_r, y1), frame.at(half_t, -half_r, y1), frame.at(half_t, half_r, y1), frame.at(-half_t, half_r, y1)},
                        colors_by_band.back().color, anchor, {0.0, 1.0, 0.0});
}

void add_box_collision(Builder& builder, const Frame& frame, double half_t, double half_r, double y0, double y1, const D2& anchor) {
    auto corner = [&](int st, int sr, int sy) { return frame.at(st * half_t, sr * half_r, sy < 0 ? y0 : y1); };
    struct Face { int st, sr, sy; int k[4][3]; };
    static const Face faces[6] = {
        {1, 0, 0, {{1, -1, -1}, {1, 1, -1}, {1, 1, 1}, {1, -1, 1}}},
        {-1, 0, 0, {{-1, -1, -1}, {-1, 1, -1}, {-1, 1, 1}, {-1, -1, 1}}},
        {0, 1, 0, {{-1, 1, -1}, {1, 1, -1}, {1, 1, 1}, {-1, 1, 1}}},
        {0, -1, 0, {{-1, -1, -1}, {1, -1, -1}, {1, -1, 1}, {-1, -1, 1}}},
        {0, 0, 1, {{-1, -1, 1}, {1, -1, 1}, {1, 1, 1}, {-1, 1, 1}}},
        {0, 0, -1, {{-1, -1, -1}, {1, -1, -1}, {1, 1, -1}, {-1, 1, -1}}}};
    for (const Face& f : faces) {
        std::vector<V3> quad;
        for (auto& k : f.k) quad.push_back(corner(k[0], k[1], k[2]));
        V3 outward{frame.t[0] * f.st + frame.r[0] * f.sr, (double)f.sy, frame.t[2] * f.st + frame.r[2] * f.sr};
        if (dot(polygon_normal(quad), outward) < 0) quad = {quad[0], quad[3], quad[2], quad[1]};
        builder.collision.push_back({{quad[0], quad[2], quad[1]}, anchor});
        builder.collision.push_back({{quad[0], quad[3], quad[2]}, anchor});
    }
}

static void numbered_face(Builder& builder, const Frame& frame, int facing, double along, double v_base, const std::vector<Rect>& rects,
                          const D2& anchor, const Color& base_color) {
    V3 outward{frame.t[0] * facing, 0.0, frame.t[2] * facing};
    for (const Rect& r : rects) {
        double s0 = -facing * r.u0, s1 = -facing * r.u1;
        builder.polygon({frame.at(along, s0, v_base + r.v0), frame.at(along, s1, v_base + r.v0), frame.at(along, s1, v_base + r.v1),
                         frame.at(along, s0, v_base + r.v1)},
                        r.digit ? COLOR_DIGIT : base_color, anchor, outward);
    }
}

static void add_km_post(Builder& builder, const Frame& frame, long long behind, long long ahead) {
    D2 anchor{frame.o[0], frame.o[2]};
    double half = POST_SIDE / 2;
    sign_box(builder, frame, half, half, -POST_BURIED, KM_POST_HEIGHT,
             {{-POST_BURIED, KM_POST_BLACK, COLOR_BLACK}, {KM_POST_BLACK, KM_POST_HEIGHT, COLOR_POST}}, anchor);
    std::string sb = std::to_string(behind), sa = std::to_string(ahead);
    int digits = (int)std::max(sb.size(), sa.size());
    double width = km_plate_width(std::min(4, digits));
    double half_t = KM_PLATE_THICKNESS / 2;
    double y0 = KM_POST_HEIGHT, y1 = KM_POST_HEIGHT + KM_PLATE_HEIGHT;
    double bottom = (KM_PLATE_HEIGHT - KM_DIGIT.height) / 2;
    std::pair<int, std::string> faces[2] = {{-1, sb}, {1, sa}};
    for (auto& [facing, number] : faces) {
        std::vector<Rect> rects = face_rects(number, KM_DIGIT, width, KM_PLATE_HEIGHT, bottom);
        numbered_face(builder, frame, facing, facing * half_t, y0, rects, anchor, COLOR_PLATE);
    }
    double w = width / 2;
    for (int sr : {-1, 1})
        builder.polygon({frame.at(-half_t, sr * w, y0), frame.at(half_t, sr * w, y0), frame.at(half_t, sr * w, y1), frame.at(-half_t, sr * w, y1)},
                        COLOR_PLATE, anchor, {frame.r[0] * sr, 0.0, frame.r[2] * sr});
    std::pair<double, int> lids[2] = {{y0, -1}, {y1, 1}};
    for (auto& [y, sy] : lids)
        builder.polygon({frame.at(-half_t, -w, y), frame.at(half_t, -w, y), frame.at(half_t, w, y), frame.at(-half_t, w, y)}, COLOR_PLATE,
                        anchor, {0.0, (double)sy, 0.0});
    add_box_collision(builder, frame, half, half, -POST_BURIED, KM_POST_HEIGHT, anchor);
    add_box_collision(builder, frame, half_t, w, y0, y1, anchor);
}

static void add_picket_post(Builder& builder, const Frame& frame, long long behind, long long ahead) {
    D2 anchor{frame.o[0], frame.o[2]};
    double half = POST_SIDE / 2;
    double white_from = PICKET_BLACK;
    double white_to = PICKET_BLACK + PICKET_WHITE_BELOW + PICKET_NUMBER_BAND + PICKET_WHITE_ABOVE;
    for (int sr : {-1, 1}) {
        V3 outward{frame.r[0] * sr, 0.0, frame.r[2] * sr};
        Band bands[2] = {{-POST_BURIED, white_from, COLOR_BLACK}, {white_from, white_to, COLOR_POST}};
        for (const Band& b : bands)
            builder.polygon({frame.at(-half, sr * half, b.y0), frame.at(half, sr * half, b.y0), frame.at(half, sr * half, b.y1),
                             frame.at(-half, sr * half, b.y1)},
                            b.color, anchor, outward);
    }
    double bottom = PICKET_WHITE_BELOW + (PICKET_NUMBER_BAND - PICKET_DIGIT.height) / 2;
    std::pair<int, std::string> faces[2] = {{-1, std::to_string(behind)}, {1, std::to_string(ahead)}};
    for (auto& [facing, number] : faces) {
        V3 outward{frame.t[0] * facing, 0.0, frame.t[2] * facing};
        builder.polygon({frame.at(facing * half, -half, -POST_BURIED), frame.at(facing * half, half, -POST_BURIED),
                         frame.at(facing * half, half, white_from), frame.at(facing * half, -half, white_from)},
                        COLOR_BLACK, anchor, outward);
        std::vector<Rect> rects = face_rects(number, PICKET_DIGIT, POST_SIDE, white_to - white_from, bottom);
        numbered_face(builder, frame, facing, facing * half, white_from, rects, anchor, COLOR_POST);
    }
    V3 apex = frame.at(0.0, 0.0, PICKET_TOP);
    V3 corners[4] = {frame.at(-half, -half, white_to), frame.at(half, -half, white_to), frame.at(half, half, white_to), frame.at(-half, half, white_to)};
    for (int i = 0; i < 4; i++) {
        const V3& a = corners[i];
        const V3& b = corners[(i + 1) % 4];
        V3 mid{(a[0] + b[0]) / 2 - frame.o[0], 0.0, (a[2] + b[2]) / 2 - frame.o[2]};
        builder.polygon({a, b, apex}, COLOR_POST, anchor, {mid[0], 0.05, mid[2]});
    }
    add_box_collision(builder, frame, half, half, -POST_BURIED, PICKET_TOP, anchor);
}

// ---------------------------------------------------------------- whistle sign "C"
static double whistle_half_width(double v) {
    if (v < 0.0 || v > WHISTLE_PLATE_HEIGHT) return 0.0;
    if (v <= WHISTLE_ROUND_FROM)
        return WHISTLE_PLATE_BOTTOM / 2 + (WHISTLE_PLATE_WIDTH - WHISTLE_PLATE_BOTTOM) / 2 * v / WHISTLE_ROUND_FROM;
    double r = WHISTLE_PLATE_WIDTH / 2;
    double dv = v - WHISTLE_ROUND_FROM;
    return std::sqrt(py::pymax(0.0, r * r - dv * dv));
}
static double ellipse(double a, double b, double v) {
    return a * std::sqrt(py::pymax(0.0, 1.0 - py::pow((v - L_CENTRE) / b, 2.0)));
}
static double inner_edge(double v) {
    double border = WHISTLE_BORDER;
    double top = v + border <= WHISTLE_PLATE_HEIGHT ? whistle_half_width(v + border) : 0.0;
    double low = v >= border ? whistle_half_width(v - border) : 0.0;
    return py::pymax(0.0, py::pymin(top, low) - border);
}
// edge functions; each id is one Python function object (identity matters)
enum EdgeId { E_W_NEG, E_W, E_IN_NEG1, E_IN, E_IN_NEG2, E_OC_NEG3, E_IC_NEG3, E_IC, E_OC, E_OC_NEG6, E_OC_NEG7 };
static double edge_value(int id, double v) {
    switch (id) {
        case E_W_NEG: return -whistle_half_width(v);
        case E_W: return whistle_half_width(v);
        case E_IN_NEG1: case E_IN_NEG2: return -inner_edge(v);
        case E_IN: return inner_edge(v);
        case E_OC_NEG3: case E_OC_NEG6: case E_OC_NEG7: return -ellipse(L_HALF_WIDTH, L_HALF_HEIGHT, v);
        case E_IC_NEG3: return -ellipse(L_HALF_WIDTH - L_STROKE, L_HALF_HEIGHT - L_STROKE, v);
        case E_IC: return ellipse(L_HALF_WIDTH - L_STROKE, L_HALF_HEIGHT - L_STROKE, v);
        case E_OC: return ellipse(L_HALF_WIDTH, L_HALF_HEIGHT, v);
    }
    return 0.0;
}
struct Layer { int left, right; int color; double lo, hi; };     // color: 0 black, 1 green, 2 plate, 3 digit
static std::vector<Layer> whistle_layers() {
    double c_lo = L_CENTRE - L_HALF_HEIGHT, c_hi = L_CENTRE + L_HALF_HEIGHT;
    double i_lo = L_CENTRE - L_HALF_HEIGHT + L_STROKE, i_hi = L_CENTRE + L_HALF_HEIGHT - L_STROKE;
    double g_lo = L_CENTRE - L_GAP, g_hi = L_CENTRE + L_GAP;
    return {{E_W_NEG, E_W, 0, 0.0, WHISTLE_PLATE_HEIGHT},  {E_IN_NEG1, E_IN, 1, 0.0, WHISTLE_GREEN},
            {E_IN_NEG2, E_IN, 2, WHISTLE_GREEN, WHISTLE_PLATE_HEIGHT}, {E_OC_NEG3, E_IC_NEG3, 3, i_lo, i_hi},
            {E_IC, E_OC, 3, i_lo, g_lo},                    {E_IC, E_OC, 3, g_hi, i_hi},
            {E_OC_NEG6, E_OC, 3, c_lo, i_lo},               {E_OC_NEG7, E_OC, 3, i_hi, c_hi}};
}
static const Color& layer_color(int c) {
    switch (c) { case 0: return COLOR_BLACK; case 1: return COLOR_GREEN; case 2: return COLOR_PLATE; default: return COLOR_DIGIT; }
}
static std::vector<double> whistle_row_breaks() {
    std::set<double> marks{0.0, WHISTLE_PLATE_HEIGHT, WHISTLE_ROUND_FROM};
    for (const Layer& l : whistle_layers()) { marks.insert(l.lo); marks.insert(l.hi); }
    int k = 1;
    while (k * WHISTLE_ROW < WHISTLE_PLATE_HEIGHT) { marks.insert(k * WHISTLE_ROW); k++; }
    std::vector<double> sorted(marks.begin(), marks.end());
    std::vector<double> out{sorted[0]};
    for (size_t i = 1; i < sorted.size(); i++) if (sorted[i] - out.back() > 1e-4) out.push_back(sorted[i]);
    return out;
}
struct Piece { double a0, b0, a1, b1; int color; };
static std::vector<Piece> whistle_row_pieces(double v0, double v1) {
    double vm = (v0 + v1) / 2;
    std::vector<Layer> layers;
    for (const Layer& l : whistle_layers()) if (l.lo - 1e-9 <= vm && vm <= l.hi + 1e-9) layers.push_back(l);
    std::vector<int> edges;
    for (const Layer& l : layers) { edges.push_back(l.left); edges.push_back(l.right); }
    std::vector<int> cuts = edges;
    std::stable_sort(cuts.begin(), cuts.end(), [&](int x, int y) { return edge_value(x, vm) < edge_value(y, vm); });
    struct P { int fa, fb, color; };
    std::vector<P> pieces;
    for (size_t k = 0; k + 1 < cuts.size(); k++) {
        int fa = cuts[k], fb = cuts[k + 1];
        double a = edge_value(fa, vm), b = edge_value(fb, vm);
        double m = (a + b) / 2;
        int color = -1;
        if (b - a < 1e-6) {
            color = (!pieces.empty() && pieces.back().fb == fa) ? pieces.back().color : -1;
        } else {
            for (const Layer& l : layers)
                if (edge_value(l.left, vm) <= m && m <= edge_value(l.right, vm)) color = l.color;
        }
        if (color < 0) continue;
        if (!pieces.empty() && pieces.back().color == color && pieces.back().fb == fa) pieces.back().fb = fb;
        else pieces.push_back({fa, fb, color});
    }
    std::vector<Piece> out;
    for (const P& p : pieces) out.push_back({edge_value(p.fa, v0), edge_value(p.fb, v0), edge_value(p.fa, v1), edge_value(p.fb, v1), p.color});
    return out;
}

static void add_whistle_sign(Builder& builder, const Frame& frame) {
    D2 anchor{frame.o[0], frame.o[2]};
    double half = POST_SIDE / 2;
    double y0 = WHISTLE_POST_HEIGHT;
    sign_box(builder, frame, half, half, -POST_BURIED, y0 + 0.05,
             {{-POST_BURIED, WHISTLE_POST_BLACK, COLOR_BLACK}, {WHISTLE_POST_BLACK, y0 - WHISTLE_BAND, COLOR_POST},
              {y0 - WHISTLE_BAND, y0 + 0.05, COLOR_BLACK}},
             anchor);
    double half_t = KM_PLATE_THICKNESS / 2;
    V3 face{-frame.t[0], 0.0, -frame.t[2]};
    V3 back{frame.t[0], 0.0, frame.t[2]};
    std::vector<double> breaks = whistle_row_breaks();
    for (size_t r = 0; r + 1 < breaks.size(); r++) {
        double v0 = breaks[r], v1 = breaks[r + 1];
        for (const Piece& pc : whistle_row_pieces(v0, v1)) {
            std::array<std::array<double, 2>, 4> quad = {{{pc.a0, v0}, {pc.b0, v0}, {pc.b1, v1}, {pc.a1, v1}}};
            std::vector<std::array<double, 2>> kept;
            for (int k = 0; k < 4; k++) {
                const auto& p = quad[k];
                const auto& q = quad[(k + 3) % 4];             // quad[k - 1]
                if (py::dist2(p[0], p[1], q[0], q[1]) > 1e-6) kept.push_back(p);
            }
            if (kept.size() >= 3) {
                std::vector<V3> pts;
                for (auto& uv : kept) pts.push_back(frame.at(-half_t, uv[0], y0 + uv[1]));
                builder.polygon(pts, layer_color(pc.color), anchor, face);
            }
        }
    }
    std::vector<std::array<double, 2>> outline{{0.0, whistle_half_width(0.0)}};
    int steps = 12;
    for (int k = 0; k <= steps; k++) {
        double v = WHISTLE_ROUND_FROM + (WHISTLE_PLATE_HEIGHT - WHISTLE_ROUND_FROM) * k / steps;
        outline.push_back({v, whistle_half_width(v)});
    }
    std::vector<std::array<double, 2>> seq;
    for (auto& vh : outline) seq.push_back({vh[1], vh[0]});
    for (size_t k = outline.size(); k-- > 0;) seq.push_back({-outline[k][1], outline[k][0]});
    std::vector<std::array<double, 2>> ring;
    for (auto& uv : seq)
        if (ring.empty() || py::hypot(uv[0] - ring.back()[0], uv[1] - ring.back()[1]) > 1e-6) ring.push_back(uv);
    {
        std::vector<V3> pts;
        for (auto& uv : ring) pts.push_back(frame.at(half_t, uv[0], y0 + uv[1]));
        builder.polygon(pts, COLOR_PLATE_BACK, anchor, back);
    }
    for (size_t k = 0; k < ring.size(); k++) {
        double ua = ring[k][0], va = ring[k][1];
        double ub = ring[(k + 1) % ring.size()][0], vb = ring[(k + 1) % ring.size()][1];
        double nx = vb - va, nv = -(ub - ua);
        V3 outward{frame.r[0] * nx, nv, frame.r[2] * nx};
        builder.polygon({frame.at(-half_t, ua, y0 + va), frame.at(half_t, ua, y0 + va), frame.at(half_t, ub, y0 + vb), frame.at(-half_t, ub, y0 + vb)},
                        COLOR_BLACK, anchor, outward);
    }
    add_box_collision(builder, frame, half, half, -POST_BURIED, y0, anchor);
    add_box_collision(builder, frame, half_t, WHISTLE_PLATE_WIDTH / 2, y0, y0 + WHISTLE_PLATE_HEIGHT, anchor);
}

void add_sign(Builder& builder, const Value& sign) {
    Value pos = sign.get("pos"), dir = sign.get("dir");
    Frame frame({pos[0].num(), pos[1].num(), pos[2].num()}, {dir[0].num(), dir[1].num()});
    const std::string& kind = sign.get("kind").str();
    if (kind == "whistle") add_whistle_sign(builder, frame);
    else if (kind == "km") add_km_post(builder, frame, sign.get("behind").integer(), sign.get("ahead").integer());
    else add_picket_post(builder, frame, sign.get("behind").integer(), sign.get("ahead").integer());
}
