// Port of catenary.py geometry
#include "catenary_geom.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <optional>
#include "catenary_plan.h"
#include "signs_geom.h"

using namespace vec;
using cat::pole_radius_at;
using cat::pole_base_y;
using py::pymax;
using py::pymin;

// ---------------------------------------------------------------- dimensions
static const double CONTACT_WIRE_HEIGHT = 6.50;
static const double SYSTEM_HEIGHT = 1.80;
static const double ZIGZAG_MIN_RADIUS = 3000.0;
static const double MESSENGER_SAG_70M = 1.10;
static const double FEEDER_SAG_70M = 1.40;
static const double DROPPER_SPACING = 9.0;
static const double POLE_HEIGHT = 10.00;
static const double POLE_BURIED = 0.50;
static const double POLE_BASE_BELOW_RAIL = 0.80;
static const double FOUNDATION_SIDE = 0.90;
static const double FOUNDATION_BURIED = 1.20;
static const Color COLOR_FOUNDATION = {128, 126, 120, 255};
static const double POLE_RADIUS_GROUND = 0.225;
static const double POLE_TAPER_FROM = 0.5;
static const int POLE_SIDES = 8;
static const double CANTILEVER_HINGE = CONTACT_WIRE_HEIGHT - 0.25;
static const double CONSOLE_BASE = 2.585;
static const double TIE_HEIGHT = CANTILEVER_HINGE + CONSOLE_BASE;
static const int GARLAND_DISCS = 3;
static const int ANCHOR_DISCS = 4;
static const double DISC_RADIUS = 0.127;
static const double DISC_PITCH = 0.146;
static const double GARLAND_FITTINGS = 0.13;
static const double GARLAND_LENGTH = GARLAND_DISCS * DISC_PITCH + GARLAND_FITTINGS;
static const double CANTILEVER_OVERHANG = 0.18;
static const double FIX_INSULATOR_LENGTH = 0.55;
static const int FIX_INSULATOR_SHEDS = 5;
static const double FIX_SHED_SPACING = 0.85;
static const double DIRECT_ATTACH = 0.40;
static const double DIRECT_MAIN = 0.35;
static const double REVERSE_ATTACH = 0.70;
static const double REVERSE_MAIN_AT_WIRE = 0.45;
static const double MAIN_FIXATOR_BEYOND = 1.10;
static const double STAND_DROP = 0.14;
static const double STEADY_ARM_REACH = 0.95;
static const double STEADY_ARM_BEND = 0.30;
static const double STRING_ALONG = 1.50;
static const double POLE_FLAT_FACTOR = 0.88;
static const double CLAMP_BAND_HEIGHT = 0.10;
static const double SECOND_ARM_ATTACH = CONTACT_WIRE_HEIGHT + 0.95;
static const double TRAVERSE_HALF = 0.60;
static const double TRAVERSE_SIZE[2] = {0.12, 0.10};
static const double SPRING_ALONG = 6.0;
static const double SPRING_DROPPER = 2.0;
static const double SPRING_BELOW = 0.45;
static const double MIDDLE_ANCHOR_ROPE = 18.0;
static const double FEEDER_ARM[2] = {1.65, 3.30};
static const double FEEDER_STRUT_DROP = 0.825;
static const double FEEDER_STRUT_IN = 0.35;
static const double TUBE_RADIUS = 0.030;
static const double ROD_RADIUS = 0.016;
static const Color COLOR_GLASS = {74, 112, 100, 255};
static const double SHED_SPACING_FACTOR = 0.5;
static const double WIRE_RADIUS = 0.025;
static const double DROPPER_RADIUS = 0.010;
static const Color COLOR_CONCRETE = {150, 148, 142, 255};
static const Color COLOR_POLE_BLACK = {30, 30, 30, 255};
static const Color COLOR_POLE_WHITE = {226, 226, 220, 255};
static const double POLE_BLACK_FRACTION = 1.0 / 8.0;
static const double POLE_WHITE_FRACTION = 1.0 / 8.0;
static const double ZEBRA_STRIPE = 0.20;
static const double ZEBRA_FROM = 3.80;
static const Color COLOR_STEEL = {118, 120, 122, 255};
static const Color COLOR_INSULATOR = {112, 58, 36, 255};
static const Color COLOR_MESSENGER = {70, 70, 72, 255};
static const Color COLOR_CONTACT = {96, 74, 58, 255};
static const Color COLOR_FEEDER = {64, 64, 66, 255};
static const double MESSENGER_ANCHOR_HEIGHT = CONTACT_WIRE_HEIGHT + 2.15;
static const double COMPENSATOR_HEIGHT = CONTACT_WIRE_HEIGHT + 0.75;
static const double PULLEY_RADIUS = 0.13;
static const double INNER_PULLEY_OUT = 2.00;
static const double OUTER_PULLEY_OUT = 3.60;
static const double CONTACT_INSULATOR[2] = {3.90, 4.60};
static const double CONTACT_END_OUT = 4.80;
static const double MESSENGER_INSULATOR[2] = {1.20, 1.90};
static const double MESSENGER_END_OUT = 2.10;
static const double LEVER_DROP = 0.70;
static const double WEIGHTS_OUT = 0.60;
static const double WEIGHT_STACK_RADIUS = 0.15, WEIGHT_STACK_DISC = 0.09;
static const int WEIGHT_STACK_DISCS = 7;
static const double WEIGHT_STACK_GAP = 0.04;
static const double WEIGHTS_BOTTOM = 1.00;
static const double GUY_SPLIT = 0.90;
static const double GUY_ROD_LENGTH = 1.60;
static const double GUY_RADIUS = 0.014;
static const double GUY_ROD_RADIUS = 0.030;
static const double GUY_BLOCK[2] = {0.6, 0.35};
static const double PORTAL_BEAM_BOTTOM = 9.60;
static const double PORTAL_PANEL = 0.80;
static const double PORTAL_CHORD_RADIUS = 0.045;
static const double PORTAL_WEB_RADIUS = 0.022;
static const double PORTAL_TWIN_OFFSET = (2 * POLE_RADIUS_GROUND + POLE_RADIUS_GROUND) / 2;
static const double PORTAL_HEAD_HEIGHT = 0.90;
static const double PORTAL_ANGLE_LEG = 0.075;
static const double PORTAL_ANGLE_THICK = 0.010;
static const double PORTAL_HEAD_RINGS[2][2] = {{0.03, 0.09}, {0.17, 0.23}};
static const double PORTAL_HEAD_PLATE = 0.06;
static const double PORTAL_PLATE_MARGIN = 0.03;
static const double PORTAL_DECK = 0.04;
static const double PORTAL_RAILING = 1.10;
static const double PORTAL_RAILING_STEP = 1.50;
static const double PORTAL_LADDER_FROM = 0.30;
static const double PORTAL_LADDER_ELEMENT_BACK = 0.30;
static const double PORTAL_LADDER_OUT = 0.45;
static const double PORTAL_LADDER_WIDTH = 0.42;
static const double PORTAL_LADDER_STEP = 0.30;
static const double PORTAL_LADDER_ABOVE = 1.10;
static const double MAST_SIZE = 0.10;
static const double MAST_BELOW_HINGE = 0.15;
static const double MAST_STRUT_OUT = 0.71;
static const Color COLOR_LATTICE = {104, 106, 108, 255};
static const double BRACKET_BEAM[2] = {0.50, 0.35};
static const double BRACKET_DROP = 1.80;
static const Color COLOR_TRUSS = {45, 34, 32, 255};
static const double TRUSS_CLAMP[3] = {0.50, 0.14, 0.08};
static const double OVERLAP_INSULATOR_AT[2] = {1.6, 2.4};
static const double CAP_MIN_RADIUS = 0.03;

// ---------------------------------------------------------------- Value helpers
static inline bool none_at(const Value& d, const char* k) { const Value* v = d.dct().find(k); return !v || v->is_none(); }
static inline bool truthy_at(const Value& d, const char* k) { const Value* v = d.dct().find(k); return v && v->truthy(); }
static inline double num_at(const Value& d, const char* k) { return d.dct().find(k)->num(); }
static inline double num_at(const Value& d, const char* k, double dflt) { const Value* v = d.dct().find(k); return v ? v->num() : dflt; }
static inline std::string str_at(const Value& d, const char* k, const char* dflt) {
    const Value* v = d.dct().find(k);
    return v ? v->str() : std::string(dflt);
}
static inline bool get_eq_str(const Value& d, const char* k, const char* s) {
    const Value* v = d.dct().find(k);
    return v && v->type == Value::STR && *v->s == s;
}
static inline V3 v3(const Value& l) { return {l[0].num(), l[1].num(), l[2].num()}; }
static inline D2 d2(const Value& l) { return {l[0].num(), l[1].num()}; }

struct Local {
    double ox, oz;
    V3 operator()(const V3& p) const { return {p[0] - ox, p[1], p[2] - oz}; }
};

// ---------------------------------------------------------------- primitives
static void tube(Builder& builder, const V3& a, const V3& b, double radius, int sides, const Color& color, const D2& anchor, bool caps = false) {
    V3 axis = unit(sub(b, a));
    V3 helper = std::fabs(axis[1]) < 0.9 ? V3{0.0, 1.0, 0.0} : V3{1.0, 0.0, 0.0};
    V3 u = unit(cross(axis, helper));
    V3 v = cross(axis, u);
    std::vector<V3> ring;
    for (int i = 0; i < sides; i++) {
        double ang = 2 * M_PI * (i + 0.5) / sides;
        ring.push_back(add(mul(u, py::cos(ang) * radius), mul(v, py::sin(ang) * radius)));
    }
    for (int i = 0; i < sides; i++) {
        const V3& o0 = ring[i];
        const V3& o1 = ring[(i + 1) % sides];
        V3 outward = unit(add(o0, o1));
        builder.polygon({add(a, o0), add(a, o1), add(b, o1), add(b, o0)}, color, anchor, outward);
    }
    if (caps && radius >= CAP_MIN_RADIUS) {
        std::vector<V3> pa, pb;
        for (const V3& o : ring) { pa.push_back(add(a, o)); pb.push_back(add(b, o)); }
        builder.polygon(pa, color, anchor, mul(axis, -1.0));
        builder.polygon(pb, color, anchor, axis);
    }
}

static void cone(Builder& builder, const V3& base, double height, double r0, double r1, int sides, const Color& color, const D2& anchor,
                 bool cap, const std::map<int, Color>* side_colors) {
    V3 top{base[0], base[1] + height, base[2]};
    std::vector<V3> ring0, ring1;
    for (int i = 0; i < sides; i++) {
        double ang = 2 * M_PI * (i + 0.5) / sides;
        double c = py::cos(ang), s = py::sin(ang);
        ring0.push_back({base[0] + c * r0, base[1], base[2] + s * r0});
        ring1.push_back({top[0] + c * r1, top[1], top[2] + s * r1});
    }
    for (int i = 0; i < sides; i++) {
        int j = (i + 1) % sides;
        double ang = 2 * M_PI * (i + 1) / sides;
        V3 outward{py::cos(ang), (r0 - r1) / height, py::sin(ang)};
        Color c = color;
        if (side_colors) { auto it = side_colors->find(i); if (it != side_colors->end()) c = it->second; }
        builder.polygon({ring0[i], ring0[j], ring1[j], ring1[i]}, c, anchor, outward);
    }
    if (cap) builder.polygon(ring1, color, anchor, {0.0, 1.0, 0.0});
}

static void wire(Builder& builder, const V3& a, const V3& b, double sag, long long pieces, double radius, const Color& color, const D2& anchor) {
    V3 prev = a;
    for (long long i = 1; i <= pieces; i++) {
        double f = (double)i / (double)pieces;
        V3 q = lerp(a, b, f);
        q = {q[0], q[1] - 4.0 * sag * f * (1.0 - f), q[2]};
        tube(builder, prev, q, radius, 3, color, anchor);
        prev = q;
    }
}

struct PoleBand { double y0, y1; Color color; bool has_stripe; D2 stripe; };
static double pole_bands(double bottom, double top_y, const Value* zebra, std::vector<PoleBand>& bands) {
    double height = top_y - bottom;
    double black = bottom + height * POLE_BLACK_FRACTION;
    double white = black - height * POLE_BLACK_FRACTION * POLE_WHITE_FRACTION;
    bands.push_back({white, black, COLOR_POLE_WHITE, false, {}});
    if (zebra) {
        double z0 = bottom + ZEBRA_FROM;
        Value stripe = zebra->get("stripe");
        bool has = !stripe.is_none();
        D2 s = has ? d2(stripe) : D2{0, 0};
        for (int k = 0; k < 7; k++)
            bands.push_back({z0 + k * ZEBRA_STRIPE, z0 + (k + 1) * ZEBRA_STRIPE, k % 2 == 0 ? COLOR_POLE_BLACK : COLOR_POLE_WHITE, has, s});
    }
    return black;
}

static void concrete_pole(Builder& builder, const V3& pole, double base_y, double top_y, const D2& t, double ox, double oz, const D2& anchor,
                          double buried = POLE_BURIED, const Value* zebra = nullptr) {
    double ground_y = pole[1];
    Frame frame({pole[0] - ox, base_y, pole[2] - oz}, t);
    if (ground_y < base_y - 0.05) {
        double half = FOUNDATION_SIDE / 2;
        double drop = base_y - ground_y + FOUNDATION_BURIED;
        sign_box(builder, frame, half, half, -drop, 0.0, {{-drop, 0.0, COLOR_FOUNDATION}}, anchor);
        add_box_collision(builder, frame, half, half, -drop, 0.0, anchor);
    }
    double height = top_y - base_y;
    double taper = base_y + height * POLE_TAPER_FROM;
    double bottom = pymax(base_y, ground_y);
    std::vector<PoleBand> bands;
    double black = pole_bands(bottom, top_y, zebra, bands);
    struct Cut { double y; Color color; bool has_stripe; D2 stripe; };
    std::vector<Cut> cuts{{base_y - buried, COLOR_POLE_BLACK, false, {}}};
    double plain = black;
    for (const PoleBand& b : bands) {
        if (b.y0 > plain + 1e-6) cuts.push_back({plain, COLOR_CONCRETE, false, {}});
        cuts.push_back({b.y0, b.color, b.has_stripe, b.stripe});
        plain = b.y1;
    }
    cuts.push_back({plain, COLOR_CONCRETE, false, {}});
    struct PieceP { double y0, y1; Color color; bool has_stripe; D2 stripe; };
    std::vector<PieceP> pieces;
    for (size_t k = 0; k < cuts.size(); k++) {
        double y0 = cuts[k].y;
        double y1 = k + 1 < cuts.size() ? cuts[k + 1].y : top_y;
        if (y0 < taper && taper < y1) {
            pieces.push_back({y0, taper, cuts[k].color, cuts[k].has_stripe, cuts[k].stripe});
            pieces.push_back({taper, y1, cuts[k].color, cuts[k].has_stripe, cuts[k].stripe});
        } else if (y1 > y0 + 1e-6) {
            pieces.push_back({y0, y1, cuts[k].color, cuts[k].has_stripe, cuts[k].stripe});
        }
    }
    for (size_t k = 0; k < pieces.size(); k++) {
        const PieceP& p = pieces[k];
        std::map<int, Color> sc;
        bool use_sc = false;
        if (p.has_stripe && p.color != COLOR_POLE_BLACK) {
            double ang = py::mod(py::atan2(p.stripe[1], p.stripe[0]), 2 * M_PI);
            long long side = py::round_int(ang / (2 * M_PI / POLE_SIDES)) - 1;
            long long m = ((side % POLE_SIDES) + POLE_SIDES) % POLE_SIDES;
            sc[(int)m] = COLOR_POLE_BLACK;
            use_sc = true;
        }
        double r0 = pole_radius_at(base_y, p.y0, height);
        double r1 = pole_radius_at(base_y, p.y1, height);
        cone(builder, {pole[0] - ox, p.y0, pole[2] - oz}, p.y1 - p.y0, r0, r1, POLE_SIDES, p.color, anchor, k == pieces.size() - 1,
             use_sc ? &sc : nullptr);
    }
    add_box_collision(builder, frame, POLE_RADIUS_GROUND, POLE_RADIUS_GROUND, -buried, height, anchor);
}

static void add_bracket(Builder& builder, const Value& sp, double ox, double oz, const D2& anchor) {
    V3 pole = v3(sp.get("pole")), track = v3(sp.get("track"));
    double base_y = pole_base_y(sp);
    D2 out = unit2(pole[0] - track[0], pole[2] - track[2]);
    double reach = py::hypot(pole[0] - track[0], pole[2] - track[2]);
    double edge = num_at(sp, "bracket");
    double inner = edge - 0.30, outer = reach + 0.40;
    double width = BRACKET_BEAM[0], height = BRACKET_BEAM[1];
    D2 centre{track[0] + out[0] * (inner + outer) / 2, track[2] + out[1] * (inner + outer) / 2};
    Frame frame({centre[0] - ox, base_y - height, centre[1] - oz}, out);
    sign_box(builder, frame, (outer - inner) / 2, width / 2, 0.0, height, {{0.0, height, COLOR_STEEL}}, anchor);
    builder.polygon({frame.at(-(outer - inner) / 2, -width / 2, 0.0), frame.at((outer - inner) / 2, -width / 2, 0.0),
                     frame.at((outer - inner) / 2, width / 2, 0.0), frame.at(-(outer - inner) / 2, width / 2, 0.0)},
                    COLOR_STEEL, anchor, {0.0, -1.0, 0.0});
    V3 strut_top{track[0] + out[0] * (outer - 0.15) - ox, base_y - height, track[2] + out[1] * (outer - 0.15) - oz};
    double drop = num_at(sp, "bracket_drop", BRACKET_DROP);
    V3 strut_foot{track[0] + out[0] * edge - ox, base_y - drop + 0.1, track[2] + out[1] * edge - oz};
    tube(builder, strut_top, strut_foot, 0.06, 4, COLOR_STEEL, anchor, true);
    Frame plate({track[0] + out[0] * edge - ox, base_y - drop, track[2] + out[1] * edge - oz}, out);
    sign_box(builder, plate, 0.03, width / 2 + 0.05, 0.0, drop - height * 0.5, {{0.0, drop - height * 0.5, COLOR_STEEL}}, anchor);
    Frame base({pole[0] - ox, base_y, pole[2] - oz}, out);
    sign_box(builder, base, 0.32, 0.32, 0.0, 0.05, {{0.0, 0.05, COLOR_STEEL}}, anchor);
}

// ---------------------------------------------------------------- portals
struct Ladder { D2 post; V3 foot; double ground; V3 x, z; double top; };
static std::optional<Ladder> portal_ladder(const Value& portal) {
    if (get_eq_str(portal, "kind", "truss") || !cat::portal_twin(portal)) return std::nullopt;
    Value poles = portal.get("poles");
    V3 a = v3(poles[0]), b = v3(poles[1]);
    V3 across = unit({b[0] - a[0], 0.0, b[2] - a[2]});
    D2 along{across[2], -across[0]};
    V3 out{-along[0], 0.0, -along[1]};
    D2 post{a[0] - along[0] * PORTAL_TWIN_OFFSET, a[2] - along[1] * PORTAL_TWIN_OFFSET};
    double base_y = num_at(portal, "rail_y") - POLE_BASE_BELOW_RAIL;
    double ground = pymax(base_y, a[1]);
    auto size = cat::portal_beam_size(portal);
    double top = cat::portal_beam_y(portal) + size.second / 2 + PORTAL_DECK;
    V3 foot{post[0] + out[0] * PORTAL_LADDER_OUT, ground + PORTAL_LADDER_FROM, post[1] + out[2] * PORTAL_LADDER_OUT};
    return Ladder{post, foot, ground, across, out, top};
}

std::vector<LadderElement> portal_ladders(const Value& plan) {
    std::vector<LadderElement> found;
    if (!plan.has("portals")) return found;
    for (const Value& portal : plan.get("portals").lst()) {
        if (truthy_at(portal, "unused")) continue;
        auto ladder = portal_ladder(portal);
        if (!ladder) continue;
        double back = PORTAL_LADDER_ELEMENT_BACK;
        V3 foot{ladder->foot[0] - ladder->z[0] * back, ladder->ground, ladder->foot[2] - ladder->z[2] * back};
        found.push_back({foot, ladder->x, ladder->z, ladder->top - ladder->ground});
    }
    return found;
}

static std::vector<double> ladder_brackets(double foot_y, double head_y) {
    long long count = std::max(2LL, py::round_int((head_y - 0.3 - (foot_y + 0.3)) / 2.5) + 1);
    std::vector<double> out;
    for (long long i = 0; i < count; i++) out.push_back(foot_y + 0.3 + (head_y - 0.6 - foot_y) * i / (count - 1));
    return out;
}

static void lattice_beam(Builder& builder, const V3& start, const V3& end, double width, double height, const Color& color, const D2& anchor) {
    V3 axis = unit(sub(end, start));
    V3 side = unit(cross({0.0, 1.0, 0.0}, axis));
    double length = dist3(start, end);
    long long panels = std::max(2LL, py::round_int(length / PORTAL_PANEL));
    double step = length / panels;
    auto at = [&](double x, double y, double z) { return add(add(add(start, mul(axis, x)), {0.0, y, 0.0}), mul(side, z)); };
    double h = height / 2, w = width / 2;
    for (double y : {-h, h})
        for (double z : {-w, w}) tube(builder, at(0.0, y, z), at(length, y, z), PORTAL_CHORD_RADIUS, 4, color, anchor, true);
    for (long long i = 0; i <= panels; i++) {
        double x = i * step;
        for (double z : {-w, w}) tube(builder, at(x, -h, z), at(x, h, z), PORTAL_WEB_RADIUS, 4, color, anchor);
        for (double y : {-h, h}) tube(builder, at(x, y, -w), at(x, y, w), PORTAL_WEB_RADIUS, 4, color, anchor);
        if (i == panels) break;
        double x1 = x + step;
        bool flip = i % 2 == 0;
        for (double z : {-w, w}) tube(builder, at(x, flip ? -h : h, z), at(x1, flip ? h : -h, z), PORTAL_WEB_RADIUS, 4, color, anchor);
        for (double y : {-h, h}) tube(builder, at(x, y, flip ? -w : w), at(x1, y, flip ? w : -w), PORTAL_WEB_RADIUS, 4, color, anchor);
    }
}

static void add_portal(Builder& builder, const Value& portal, double ox, double oz) {
    Local local{ox, oz};
    Value poles = portal.get("poles");
    V3 a = v3(poles[0]), b = v3(poles[1]);
    V3 across = unit({b[0] - a[0], 0.0, b[2] - a[2]});
    D2 along{across[2], -across[0]};
    double beam_y = cat::portal_beam_y(portal);
    auto size = cat::portal_beam_size(portal);
    double width = size.first, height = size.second;
    D2 frame_t{across[0], across[2]};
    bool truss = get_eq_str(portal, "kind", "truss");
    if (truss && truthy_at(portal, "strut")) return;
    if (truss) {
        V3 centre = lerp({a[0], beam_y, a[2]}, {b[0], beam_y, b[2]}, 0.5);
        Frame frame(local({centre[0], beam_y - height / 2, centre[2]}), frame_t);
        double half_length = dist3(a, b) / 2;
        D2 anchor{centre[0] - ox, centre[2] - oz};
        sign_box(builder, frame, half_length, width / 2, 0.0, height, {{0.0, height, COLOR_TRUSS}}, anchor);
        builder.polygon({frame.at(-half_length, -width / 2, 0.0), frame.at(half_length, -width / 2, 0.0), frame.at(half_length, width / 2, 0.0),
                         frame.at(-half_length, width / 2, 0.0)},
                        COLOR_TRUSS, anchor, {0.0, -1.0, 0.0});
        add_box_collision(builder, frame, half_length, width / 2, 0.0, height, anchor);
        return;
    }
    bool twin = cat::portal_twin(portal);
    double rail_y = num_at(portal, "rail_y");
    double base_y = rail_y - POLE_BASE_BELOW_RAIL;
    double bottom = rail_y + PORTAL_BEAM_BOTTOM;
    double plate_y = bottom - PORTAL_HEAD_PLATE;
    double head_y = plate_y - PORTAL_HEAD_HEIGHT;
    double post_top = plate_y - 0.05;
    std::vector<double> offsets = twin ? std::vector<double>{-PORTAL_TWIN_OFFSET, PORTAL_TWIN_OFFSET} : std::vector<double>{0.0};
    auto hh = cat::portal_head_half(portal);
    double plate_along = hh.first, plate_across = hh.second;
    double corner_along = plate_along - PORTAL_PLATE_MARGIN;
    double corner_across = plate_across - PORTAL_PLATE_MARGIN;
    double leg = PORTAL_ANGLE_LEG, thick = PORTAL_ANGLE_THICK;
    for (const V3& pole : {a, b}) {
        D2 anchor{pole[0] - ox, pole[2] - oz};
        auto block = [&](double c_along, double c_across, double half_along, double half_across, double y0, double y1, bool bottom_face) {
            Frame frame(local({pole[0] + along[0] * c_along + across[0] * c_across, y0, pole[2] + along[1] * c_along + across[2] * c_across}), along);
            sign_box(builder, frame, half_along, half_across, 0.0, y1 - y0, {{0.0, y1 - y0, COLOR_STEEL}}, anchor);
            if (bottom_face)
                builder.polygon({frame.at(-half_along, -half_across, 0.0), frame.at(half_along, -half_across, 0.0),
                                 frame.at(half_along, half_across, 0.0), frame.at(-half_along, half_across, 0.0)},
                                COLOR_STEEL, anchor, {0.0, -1.0, 0.0});
        };
        for (double offset : offsets) {
            V3 post{pole[0] + along[0] * offset, pole[1], pole[2] + along[1] * offset};
            concrete_pole(builder, post, base_y, post_top, along, ox, oz, {post[0] - ox, post[2] - oz});
        }
        for (double sa : {-1.0, 1.0})
            for (double sc : {-1.0, 1.0}) {
                block(sa * (corner_along - leg / 2), sc * (corner_across - thick / 2), leg / 2, thick / 2, head_y, plate_y, false);
                block(sa * (corner_along - thick / 2), sc * (corner_across - leg / 2), thick / 2, leg / 2, head_y, plate_y, false);
            }
        for (auto& rr : PORTAL_HEAD_RINGS) {
            double r0 = rr[0], r1 = rr[1];
            double band = 0.012;
            for (double sc : {-1.0, 1.0})
                block(0.0, sc * (corner_across + band / 2), corner_along + band, band / 2, head_y + r0, head_y + r1, true);
            for (double sa : {-1.0, 1.0})
                block(sa * (corner_along + band / 2), 0.0, band / 2, corner_across, head_y + r0, head_y + r1, true);
        }
        block(0.0, 0.0, plate_along, plate_across, plate_y, bottom, true);
        add_box_collision(builder, Frame(local({pole[0], head_y, pole[2]}), along), plate_along, plate_across, 0.0, bottom - head_y, anchor);
    }
    V3 start = add({a[0], beam_y, a[2]}, mul(across, -plate_across));
    V3 end = add({b[0], beam_y, b[2]}, mul(across, plate_across));
    V3 centre = lerp(start, end, 0.5);
    D2 anchor{centre[0] - ox, centre[2] - oz};
    lattice_beam(builder, local(start), local(end), width, height, COLOR_LATTICE, anchor);
    Frame girder(local({centre[0], bottom, centre[2]}), frame_t);
    add_box_collision(builder, girder, dist3(start, end) / 2, width / 2, 0.0, height + (twin ? PORTAL_DECK : 0.0), anchor);
    if (!twin) return;
    double top = beam_y + height / 2;
    Frame deck(local({centre[0], top, centre[2]}), frame_t);
    double half_length = dist3(start, end) / 2;
    sign_box(builder, deck, half_length, width / 2, 0.0, PORTAL_DECK, {{0.0, PORTAL_DECK, COLOR_STEEL}}, anchor);
    builder.polygon({deck.at(-half_length, -width / 2, 0.0), deck.at(half_length, -width / 2, 0.0), deck.at(half_length, width / 2, 0.0),
                     deck.at(-half_length, width / 2, 0.0)},
                    COLOR_STEEL, anchor, {0.0, -1.0, 0.0});
    double ladder_x = -half_length + plate_across;
    double gap0 = ladder_x - PORTAL_LADDER_WIDTH / 2 - 0.15, gap1 = ladder_x + PORTAL_LADDER_WIDTH / 2 + 0.15;
    double rail_top = top + PORTAL_DECK + PORTAL_RAILING;
    double edge = width / 2 - 0.03;
    for (double side : {-1.0, 1.0}) {
        std::vector<std::pair<double, double>> pieces{{-half_length + 0.03, half_length - 0.03}};
        if (side < 0) pieces = {{-half_length + 0.03, gap0}, {gap1, half_length - 0.03}};
        for (auto& [x0, x1] : pieces) {
            if (x1 - x0 < 0.1) continue;
            long long posts = std::max(2LL, py::round_int((x1 - x0) / PORTAL_RAILING_STEP) + 1);
            for (long long i = 0; i < posts; i++) {
                V3 foot = deck.at(x0 + (x1 - x0) * i / (posts - 1), side * edge, PORTAL_DECK);
                tube(builder, foot, {foot[0], rail_top, foot[2]}, 0.022, 4, COLOR_STEEL, anchor, true);
            }
            for (double y : {rail_top, top + PORTAL_DECK + PORTAL_RAILING / 2}) {
                V3 p0 = deck.at(x0, side * edge, 0.0), p1 = deck.at(x1, side * edge, 0.0);
                tube(builder, {p0[0], y, p0[2]}, {p1[0], y, p1[2]}, 0.022, 4, COLOR_STEEL, anchor, true);
            }
            V3 middle = deck.at((x0 + x1) / 2, side * edge, 0.0);
            add_box_collision(builder, Frame(middle, frame_t), (x1 - x0) / 2, 0.025, PORTAL_DECK, PORTAL_DECK + PORTAL_RAILING, anchor);
        }
    }
    auto ladder = portal_ladder(portal);
    D2 post = ladder->post;
    V3 out = ladder->z;
    double foot_y = ladder->foot[1];
    double top_y = top + PORTAL_DECK + PORTAL_LADDER_ABOVE;
    D2 ladder_anchor{post[0] - ox, post[1] - oz};
    for (double s_ : {-PORTAL_LADDER_WIDTH / 2, PORTAL_LADDER_WIDTH / 2}) {
        double x = post[0] + out[0] * PORTAL_LADDER_OUT + across[0] * s_;
        double z = post[1] + out[2] * PORTAL_LADDER_OUT + across[2] * s_;
        tube(builder, local({x, foot_y, z}), local({x, top_y, z}), 0.025, 4, COLOR_STEEL, ladder_anchor, true);
        for (double y : ladder_brackets(foot_y, head_y)) {
            double radius = pole_radius_at(base_y, y, post_top - base_y);
            double lateral = std::copysign(radius * 0.5, s_);
            double depth = std::sqrt(radius * radius - lateral * lateral) * 0.97;
            tube(builder, local({x, y, z}), local({post[0] + out[0] * depth + across[0] * lateral, y, post[1] + out[2] * depth + across[2] * lateral}),
                 0.018, 4, COLOR_STEEL, ladder_anchor, true);
        }
    }
    for (double y : ladder_brackets(foot_y, head_y)) {
        double band = pole_radius_at(base_y, y, post_top - base_y) + 0.012;
        tube(builder, local({post[0], y - 0.04, post[1]}), local({post[0], y + 0.04, post[1]}), band, POLE_SIDES, COLOR_STEEL, ladder_anchor, true);
    }
    double y = foot_y + 0.15;
    while (y < top + PORTAL_DECK + 0.1) {
        V3 c{post[0] + out[0] * PORTAL_LADDER_OUT, y, post[1] + out[2] * PORTAL_LADDER_OUT};
        tube(builder, local(add(c, mul(across, -PORTAL_LADDER_WIDTH / 2))), local(add(c, mul(across, PORTAL_LADDER_WIDTH / 2))), 0.016, 4,
             COLOR_STEEL, ladder_anchor);
        y += PORTAL_LADDER_STEP;
    }
}

// ---------------------------------------------------------------- support key points
struct FixGeom { V3 clamp, a0, ins_end, end, stand_foot; bool has_bend = false; V3 bend, strings; };
struct Keys {
    D2 r;
    V3 messenger, contact, t;
    bool console = false;
    V3 to_track, hinge, tie, clevis, tube_dir;
    double axis_x = 0, axis_z = 0, rail_y = 0;
    bool has_fix = false;
    FixGeom fix;
    V3 on_tube(double y) const {
        double f = (y - hinge[1]) / pymax(1e-6, clevis[1] - hinge[1]);
        return lerp(hinge, clevis, f);
    }
    V3 from_pole(double dist_out, double height) const {
        return {axis_x + to_track[0] * dist_out, rail_y + height, axis_z + to_track[2] * dist_out};
    }
};

static double messenger_offset(const Value& sp) {
    if (num_at(sp, "radius", 1e9) >= ZIGZAG_MIN_RADIUS && none_at(sp, "overlap_of") && !truthy_at(sp, "rider") && !truthy_at(sp, "traverse") &&
        !get_eq_str(sp, "fixator", "overlap"))
        return 0.0;
    return num_at(sp, "stagger");
}

static Keys support_points(const Value& sp) {
    Keys k;
    D2 t = d2(sp.get("t"));
    double tx = t[0], tz = t[1];
    k.r = vec::right_of(t);
    V3 track = v3(sp.get("track"));
    double shift = num_at(sp, "console_shift", 0.0);
    if (shift != 0.0) track = {track[0] + tx * shift, track[1], track[2] + tz * shift};
    double rail_y = track[1];
    double wire_y = rail_y + CONTACT_WIRE_HEIGHT + num_at(sp, "raise", 0.0);
    double stagger = num_at(sp, "stagger");
    k.contact = {track[0] + k.r[0] * stagger, wire_y, track[2] + k.r[1] * stagger};
    double m_off = messenger_offset(sp);
    k.messenger = {track[0] + k.r[0] * m_off, rail_y + CONTACT_WIRE_HEIGHT + SYSTEM_HEIGHT, track[2] + k.r[1] * m_off};
    k.t = {tx, 0.0, tz};
    k.rail_y = rail_y;
    Value mast = sp.get("mast");
    if (!none_at(sp, "portal") && mast.is_none()) return k;
    bool is_mast = !mast.is_none();
    double base_y = 0;
    if (is_mast) {
        k.axis_x = mast[0].num();
        k.axis_z = mast[1].num();
    } else {
        base_y = pole_base_y(sp);
        Value pole = sp.get("pole");
        k.axis_x = pole[0].num();
        k.axis_z = pole[2].num();
    }
    auto radius = [&](double y) {
        double r = is_mast ? MAST_SIZE / 2 : pole_radius_at(base_y, y) * POLE_FLAT_FACTOR;
        if (shift != 0.0) r = r / POLE_FLAT_FACTOR + TRAVERSE_SIZE[0];
        return r;
    };
    if (shift != 0.0) {
        k.axis_x += tx * shift;
        k.axis_z += tz * shift;
    }
    D2 towards = unit2(k.messenger[0] - k.axis_x, k.messenger[2] - k.axis_z);
    k.to_track = {towards[0], 0.0, towards[1]};
    k.console = true;
    k.hinge = k.from_pole(radius(rail_y + CANTILEVER_HINGE), CANTILEVER_HINGE);
    k.tie = k.from_pole(radius(rail_y + TIE_HEIGHT), TIE_HEIGHT);
    k.clevis = {k.messenger[0], k.messenger[1] + GARLAND_LENGTH, k.messenger[2]};
    k.tube_dir = unit(sub(k.clevis, k.hinge));
    return k;
}

static void wire_ends(const Value& sp, V3& m, V3& c) {
    if (none_at(sp, "anchor")) {
        Keys k = support_points(sp);
        m = k.messenger;
        c = k.contact;
        return;
    }
    V3 pole = v3(sp.get("pole"));
    double rail_y = sp.get("track")[1].num();
    D2 tw = d2(sp.get("anchor").get("towards"));
    m = {pole[0] + tw[0] * MESSENGER_END_OUT, rail_y + MESSENGER_ANCHOR_HEIGHT, pole[2] + tw[1] * MESSENGER_END_OUT};
    c = {pole[0] + tw[0] * CONTACT_END_OUT, rail_y + COMPENSATOR_HEIGHT, pole[2] + tw[1] * CONTACT_END_OUT};
}

static void insulator_chain(Builder& builder, const V3& a, const V3& b, const D2& anchor, int sheds = 3, double shed_radius = 0.11,
                            double core_radius = 0.03, double spacing = SHED_SPACING_FACTOR) {
    V3 axis = unit(sub(b, a));
    double length = dist3(a, b);
    double pitch = length / sheds * spacing;
    double body = pymin(length, sheds * pitch + 0.04);
    V3 body_start = add(a, mul(axis, (length - body) / 2));
    V3 body_end = add(body_start, mul(axis, body));
    tube(builder, a, b, core_radius * 0.6, 4, COLOR_STEEL, anchor);
    tube(builder, body_start, body_end, core_radius, 6, COLOR_INSULATOR, anchor);
    for (int i = 0; i < sheds; i++) {
        V3 centre = add(body_start, mul(axis, 0.02 + pitch * (i + 0.5)));
        double half = pymin(0.022, pitch * 0.25);
        tube(builder, add(centre, mul(axis, -half)), add(centre, mul(axis, half)), shed_radius, 6, COLOR_INSULATOR, anchor, true);
    }
}

static void disc_string(Builder& builder, const V3& a, const V3& b, const D2& anchor, int discs = GARLAND_DISCS, double radius = DISC_RADIUS) {
    V3 axis = unit(sub(b, a));
    double length = dist3(a, b);
    double body = pymin(length * 0.9, discs * DISC_PITCH);
    V3 start = add(a, mul(axis, (length - body) / 2));
    tube(builder, a, b, 0.016, 4, COLOR_STEEL, anchor);
    double pitch = body / discs;
    for (int i = 0; i < discs; i++) {
        V3 cap0 = add(start, mul(axis, pitch * i));
        tube(builder, add(cap0, mul(axis, pitch * 0.42)), add(cap0, mul(axis, pitch * 0.62)), radius, 6, COLOR_GLASS, anchor, true);
    }
}

static void saddle(Builder& builder, const V3& messenger, const V3& t, const D2& anchor, const Local& local) {
    V3 half{t[0] * 0.13, 0.0, t[2] * 0.13};
    tube(builder, local(add(sub(messenger, half), {0.0, 0.03, 0.0})), local(add(add(messenger, half), {0.0, 0.03, 0.0})), 0.032, 6, COLOR_STEEL,
         anchor, true);
}

static void draw_console(Builder& builder, const Value& sp, const Keys& k, const Local& local, const D2& anchor, double base_y, bool mast) {
    const V3 &hinge = k.hinge, &tie = k.tie, &clevis = k.clevis, &tube_dir = k.tube_dir, &messenger = k.messenger;
    if (!mast && !truthy_at(sp, "console_shift")) {
        Value centre = sp.get("pole");
        for (const V3* point : {&hinge, &tie}) {
            double band_radius = pole_radius_at(base_y, (*point)[1]) + 0.015;
            tube(builder, local({centre[0].num(), (*point)[1] - CLAMP_BAND_HEIGHT / 2, centre[2].num()}),
                 local({centre[0].num(), (*point)[1] + CLAMP_BAND_HEIGHT / 2, centre[2].num()}), band_radius, POLE_SIDES, COLOR_STEEL, anchor);
        }
    }
    tube(builder, local(hinge), local(add(clevis, mul(tube_dir, CANTILEVER_OVERHANG))), TUBE_RADIUS, 4, COLOR_STEEL, anchor, true);
    V3 tie_end = add(clevis, mul(tube_dir, CANTILEVER_OVERHANG * 0.6));
    tube(builder, local(tie), local(tie_end), ROD_RADIUS, 4, COLOR_STEEL, anchor, true);
    tube(builder, local(add(clevis, {0.0, -0.07, 0.0})), local(add(clevis, {0.0, 0.05, 0.0})), 0.045, 6, COLOR_STEEL, anchor, true);
    disc_string(builder, local(add(clevis, {0.0, -0.07, 0.0})), local(add(messenger, {0.0, 0.06, 0.0})), anchor);
    saddle(builder, messenger, k.t, anchor, local);
    if (truthy_at(sp, "garland_fix")) {
        V3 start = k.on_tube(messenger[1] + 0.06);
        V3 foot = add(messenger, {0.0, 0.06, 0.0});
        if (dist3(start, foot) > 0.45) {
            insulator_chain(builder, local(start), local(lerp(start, foot, 0.62)), anchor, 4, 0.06, 0.022);
            tube(builder, local(lerp(start, foot, 0.62)), local(foot), ROD_RADIUS, 4, COLOR_STEEL, anchor, true);
        }
    }
}

static FixGeom fixator_geometry(const Value& sp, const Keys& k, const std::string& kind) {
    const V3& contact = k.contact;
    double rail_y = sp.get("track")[1].num();
    double wire_h = contact[1] - rail_y;
    double ax = k.axis_x, az = k.axis_z;
    double out = py::hypot(contact[0] - ax, contact[2] - az);
    auto dist_out = [&](const V3& p) { return py::hypot(p[0] - ax, p[2] - az); };
    FixGeom g;
    g.clamp = {contact[0], contact[1] + 0.02, contact[2]};
    if (kind == "reverse") {
        g.a0 = k.on_tube(rail_y + wire_h + REVERSE_ATTACH);
        g.end = k.from_pole(out + MAIN_FIXATOR_BEYOND, wire_h + REVERSE_MAIN_AT_WIRE - 0.04);
        V3 direction = unit(sub(g.end, g.a0));
        g.ins_end = add(g.a0, mul(direction, FIX_INSULATOR_LENGTH));
        g.stand_foot = add(g.end, {0.0, -STAND_DROP, 0.0});
        g.has_bend = true;
        g.bend = k.from_pole(out + STEADY_ARM_BEND, wire_h + 0.08);
        double f = (out + 0.15 - dist_out(g.a0)) / pymax(0.1, dist_out(g.end) - dist_out(g.a0));
        g.strings = lerp(g.a0, g.end, f);
        return g;
    }
    g.a0 = k.on_tube(rail_y + wire_h + DIRECT_ATTACH);
    double d0 = dist_out(g.a0);
    g.ins_end = k.from_pole(d0 + FIX_INSULATOR_LENGTH, wire_h + DIRECT_ATTACH - 0.02);
    double stand_out = pymax(out - STEADY_ARM_REACH, d0 + FIX_INSULATOR_LENGTH + 0.25);
    g.end = k.from_pole(stand_out, wire_h + DIRECT_MAIN);
    g.stand_foot = add(g.end, {0.0, -STAND_DROP, 0.0});
    if (out - stand_out > STEADY_ARM_BEND + 0.15) {
        g.has_bend = true;
        g.bend = k.from_pole(out - STEADY_ARM_BEND, wire_h + 0.08);
    }
    g.strings = lerp(g.ins_end, g.end, 0.75);
    return g;
}

static bool string_foot(const Value& sp, V3& foot) {
    if (truthy_at(sp, "dropped") || !none_at(sp, "anchor")) return false;
    std::string kind = str_at(sp, "fixator", "direct");
    if (kind != "direct" && kind != "reverse") return false;
    if (!none_at(sp, "portal") && none_at(sp, "mast")) return false;
    foot = fixator_geometry(sp, support_points(sp), kind).strings;
    return true;
}

static void draw_second_arm(Builder& builder, const Value& sp, const Keys& k, const Local& local, const D2& anchor, const Keys& host) {
    const V3& contact = k.contact;
    double rail_y = sp.get("track")[1].num();
    V3 clamp{contact[0], contact[1] + 0.02, contact[2]};
    double ax = host.axis_x, az = host.axis_z;
    double out = py::hypot(contact[0] - ax, contact[2] - az);
    const V3& to_track = host.to_track;
    auto at = [&](double dist_out, double y) { return V3{ax + to_track[0] * dist_out, y, az + to_track[2] * dist_out}; };
    auto dist_out = [&](const V3& p) { return py::hypot(p[0] - ax, p[2] - az); };
    double stand_out = out > dist_out(host.hinge) + 1.0 ? out - STEADY_ARM_BEND : out;
    if (host.has_fix) {
        const FixGeom& fix = host.fix;
        double r0 = dist_out(fix.ins_end), r1 = dist_out(fix.end);
        if (r0 + 0.05 <= stand_out && stand_out <= r1 - 0.05) {
            double f = (stand_out - r0) / (r1 - r0);
            V3 on_rod = lerp(fix.ins_end, fix.end, f);
            if (on_rod[1] - clamp[1] > 0.10) {
                V3 foot = at(stand_out, pymax(clamp[1] + 0.06, on_rod[1] - 0.25));
                tube(builder, local(add(on_rod, {0.0, 0.03, 0.0})), local(foot), 0.018, 4, COLOR_STEEL, anchor, true);
                tube(builder, local(foot), local(clamp), 0.018, 4, COLOR_STEEL, anchor, true);
            } else {
                tube(builder, local(on_rod), local(clamp), 0.018, 4, COLOR_STEEL, anchor, true);
            }
            return;
        }
    }
    V3 a0 = host.on_tube(rail_y + SECOND_ARM_ATTACH);
    double d0 = dist_out(a0);
    double level = a0[1] - 0.02;
    V3 ins_end = at(d0 + FIX_INSULATOR_LENGTH, level);
    insulator_chain(builder, local(a0), local(ins_end), anchor, FIX_INSULATOR_SHEDS, 0.065, 0.024, FIX_SHED_SPACING);
    V3 top = at(pymax(stand_out, d0 + FIX_INSULATOR_LENGTH + 0.10), level);
    tube(builder, local(ins_end), local(top), 0.022, 4, COLOR_STEEL, anchor, true);
    V3 foot{top[0], clamp[1] + 0.08, top[2]};
    tube(builder, local(add(top, {0.0, 0.03, 0.0})), local(foot), 0.02, 4, COLOR_STEEL, anchor, true);
    tube(builder, local(foot), local(clamp), 0.018, 4, COLOR_STEEL, anchor, true);
}

static void draw_fixator(Builder& builder, const Value& sp, const Keys& k, const Local& local, const D2& anchor, const std::string& kind,
                         const Keys* attach_on = nullptr) {
    if (kind == "overlap") {
        draw_second_arm(builder, sp, k, local, anchor, *attach_on);
        return;
    }
    FixGeom g = fixator_geometry(sp, k, kind);
    insulator_chain(builder, local(g.a0), local(g.ins_end), anchor, FIX_INSULATOR_SHEDS, 0.065, 0.024, FIX_SHED_SPACING);
    double radius = TUBE_RADIUS * (kind == "reverse" ? 0.85 : 0.75);
    tube(builder, local(g.ins_end), local(g.end), radius, 4, COLOR_STEEL, anchor, true);
    tube(builder, local(add(g.end, {0.0, 0.05, 0.0})), local(g.stand_foot), 0.02, 4, COLOR_STEEL, anchor, true);
    if (g.has_bend) {
        tube(builder, local(g.stand_foot), local(g.bend), 0.018, 4, COLOR_STEEL, anchor, true);
        tube(builder, local(g.bend), local(g.clamp), 0.018, 4, COLOR_STEEL, anchor, true);
    } else {
        tube(builder, local(g.stand_foot), local(g.clamp), 0.018, 4, COLOR_STEEL, anchor, true);
    }
}

static void draw_traverses(Builder& builder, const Value& sp, const Local& local, const D2& anchor) {
    double base_y = pole_base_y(sp);
    V3 pole = v3(sp.get("pole")), track = v3(sp.get("track"));
    D2 t = d2(sp.get("t"));
    D2 to_track = unit2(track[0] - pole[0], track[2] - pole[2]);
    double depth = TRAVERSE_SIZE[0], height = TRAVERSE_SIZE[1];
    for (double h : {CANTILEVER_HINGE, TIE_HEIGHT}) {
        double y = track[1] + h;
        double radius = pole_radius_at(base_y, y);
        V3 centre{pole[0] + to_track[0] * (radius + depth / 2), y - height / 2, pole[2] + to_track[1] * (radius + depth / 2)};
        Frame frame(local(centre), t);
        sign_box(builder, frame, TRAVERSE_HALF + 0.15, depth / 2, 0.0, height, {{0.0, height, COLOR_STEEL}}, anchor);
        builder.polygon({frame.at(-TRAVERSE_HALF - 0.15, -depth / 2, 0.0), frame.at(TRAVERSE_HALF + 0.15, -depth / 2, 0.0),
                         frame.at(TRAVERSE_HALF + 0.15, depth / 2, 0.0), frame.at(-TRAVERSE_HALF - 0.15, depth / 2, 0.0)},
                        COLOR_STEEL, anchor, {0.0, -1.0, 0.0});
        tube(builder, local({pole[0], y - height / 2 - 0.03, pole[2]}), local({pole[0], y + height / 2 + 0.03, pole[2]}), radius + 0.015, POLE_SIDES,
             COLOR_STEEL, anchor, true);
    }
}

static void add_portal_hanger(Builder& builder, const Value& sp, const Value& portal, double ox, double oz) {
    Local local{ox, oz};
    Keys k = support_points(sp);
    const V3 &messenger = k.messenger, &contact = k.contact;
    D2 anchor{messenger[0] - ox, messenger[2] - oz};
    double beam_bottom = cat::portal_beam_y(portal) - cat::portal_beam_size(portal).second / 2;
    if (none_at(sp, "mast") && truthy_at(portal, "strut")) {
        Value poles = portal.get("poles");
        V3 a = v3(poles[0]), b = v3(poles[1]);
        D2 across = unit2(b[0] - a[0], b[2] - a[2]);
        double clamp_top = beam_bottom + TRUSS_CLAMP[2];
        Frame frame(local({messenger[0], beam_bottom, messenger[2]}), across);
        sign_box(builder, frame, TRUSS_CLAMP[0] / 2, TRUSS_CLAMP[1] / 2, 0.0, TRUSS_CLAMP[2], {{0.0, TRUSS_CLAMP[2], COLOR_TRUSS}}, anchor);
        builder.polygon({frame.at(-TRUSS_CLAMP[0] / 2, -TRUSS_CLAMP[1] / 2, 0.0), frame.at(TRUSS_CLAMP[0] / 2, -TRUSS_CLAMP[1] / 2, 0.0),
                         frame.at(TRUSS_CLAMP[0] / 2, TRUSS_CLAMP[1] / 2, 0.0), frame.at(-TRUSS_CLAMP[0] / 2, TRUSS_CLAMP[1] / 2, 0.0)},
                        COLOR_TRUSS, anchor, {0.0, -1.0, 0.0});
        V3 foot{messenger[0], messenger[1] + 0.06, messenger[2]};
        V3 string_top{messenger[0], pymin(beam_bottom, foot[1] + GARLAND_LENGTH + 0.05), messenger[2]};
        if (beam_bottom - string_top[1] > 0.03)
            tube(builder, local({messenger[0], clamp_top - 0.02, messenger[2]}), local(string_top), ROD_RADIUS, 4, COLOR_STEEL, anchor, true);
        disc_string(builder, local(string_top), local(foot), anchor);
        saddle(builder, messenger, k.t, anchor, local);
        tube(builder, local(messenger), local({contact[0], contact[1] + 0.02, contact[2]}), TUBE_RADIUS * 0.8, 4, COLOR_STEEL, anchor, true);
        return;
    }
    if (none_at(sp, "mast")) {
        V3 top{messenger[0], beam_bottom, messenger[2]};
        V3 foot{messenger[0], messenger[1] + 0.06, messenger[2]};
        V3 string_end{messenger[0], pymax(foot[1], beam_bottom - GARLAND_LENGTH - 0.05), messenger[2]};
        disc_string(builder, local(top), local(string_end), anchor);
        if (string_end[1] > foot[1] + 0.03) tube(builder, local(string_end), local(foot), ROD_RADIUS, 4, COLOR_STEEL, anchor, true);
        saddle(builder, messenger, k.t, anchor, local);
        tube(builder, local(messenger), local({contact[0], contact[1] + 0.02, contact[2]}), TUBE_RADIUS * 0.8, 4, COLOR_STEEL, anchor, true);
        return;
    }
    D2 mast = d2(sp.get("mast"));
    V3 track = v3(sp.get("track"));
    double rail_y = track[1];
    double bottom_y = rail_y + CANTILEVER_HINGE - MAST_BELOW_HINGE;
    D2 m_anchor{mast[0] - ox, mast[1] - oz};
    Value poles = portal.get("poles");
    V3 a = v3(poles[0]), b = v3(poles[1]);
    D2 across = unit2(b[0] - a[0], b[2] - a[2]);
    D2 along{across[1], -across[0]};
    Frame frame(local({mast[0], bottom_y, mast[1]}), along);
    sign_box(builder, frame, MAST_SIZE / 2, MAST_SIZE / 2, 0.0, beam_bottom - bottom_y, {{0.0, beam_bottom - bottom_y, COLOR_STEEL}}, m_anchor);
    builder.polygon({frame.at(-MAST_SIZE / 2, -MAST_SIZE / 2, 0.0), frame.at(MAST_SIZE / 2, -MAST_SIZE / 2, 0.0), frame.at(MAST_SIZE / 2, MAST_SIZE / 2, 0.0),
                     frame.at(-MAST_SIZE / 2, MAST_SIZE / 2, 0.0)},
                    COLOR_STEEL, m_anchor, {0.0, -1.0, 0.0});
    double width = cat::portal_beam_size(portal).first;
    auto girder_clamp = [&](double x, double z) {
        Frame f(local({x, beam_bottom - 0.08, z}), along);
        sign_box(builder, f, width / 2 + 0.04, 0.07, 0.0, 0.08, {{0.0, 0.08, COLOR_STEEL}}, m_anchor);
        builder.polygon({f.at(-width / 2 - 0.04, -0.07, 0.0), f.at(width / 2 + 0.04, -0.07, 0.0), f.at(width / 2 + 0.04, 0.07, 0.0),
                         f.at(-width / 2 - 0.04, 0.07, 0.0)},
                        COLOR_STEEL, m_anchor, {0.0, -1.0, 0.0});
    };
    girder_clamp(mast[0], mast[1]);
    D2 away = unit2(mast[0] - track[0], mast[1] - track[2]);
    girder_clamp(mast[0] + away[0] * MAST_STRUT_OUT, mast[1] + away[1] * MAST_STRUT_OUT);
    V3 strut_top{mast[0] + away[0] * MAST_STRUT_OUT, beam_bottom - 0.08, mast[1] + away[1] * MAST_STRUT_OUT};
    V3 strut_foot{mast[0] + away[0] * MAST_SIZE / 2, bottom_y + 0.25, mast[1] + away[1] * MAST_SIZE / 2};
    tube(builder, local(strut_top), local(strut_foot), 0.030, 4, COLOR_STEEL, m_anchor, true);
    draw_console(builder, sp, k, local, m_anchor, 0.0, true);
    draw_fixator(builder, sp, k, local, m_anchor, str_at(sp, "fixator", "reverse"));
}

static void add_anchor(Builder& builder, const Value& sp, double ox, double oz) {
    Local local{ox, oz};
    V3 pole = v3(sp.get("pole"));
    double rail_y = sp.get("track")[1].num();
    D2 anchor{pole[0] - ox, pole[2] - oz};
    D2 tw = d2(sp.get("anchor").get("towards"));
    double tx = tw[0], tz = tw[1];
    double base_y = pole_base_y(sp);
    auto out = [&](double distance, double height) { return local({pole[0] + tx * distance, rail_y + height, pole[2] + tz * distance}); };
    auto rope = [&](const V3& a, const V3& b, double radius) { tube(builder, a, b, radius, 4, COLOR_STEEL, anchor, true); };
    const double ROPE = DROPPER_RADIUS * 1.4;
    auto clamp = [&](double height) {
        double radius = pole_radius_at(base_y, rail_y + height) + 0.015;
        tube(builder, out(0.0, height - 0.04), out(0.0, height + 0.04), radius, 8, COLOR_STEEL, anchor, true);
    };
    auto surface = [&](double height) { return pole_radius_at(base_y, rail_y + height); };
    V3 across{-tz, 0.0, tx};
    auto pulley = [&](const V3& centre) {
        tube(builder, add(centre, mul(across, -0.035)), add(centre, mul(across, 0.035)), PULLEY_RADIUS, 10, COLOR_STEEL, anchor, true);
    };
    double r = PULLEY_RADIUS;
    double h = COMPENSATOR_HEIGHT;
    clamp(MESSENGER_ANCHOR_HEIGHT);
    disc_string(builder, out(MESSENGER_INSULATOR[0], MESSENGER_ANCHOR_HEIGHT), out(MESSENGER_INSULATOR[1], MESSENGER_ANCHOR_HEIGHT), anchor, ANCHOR_DISCS);
    rope(out(MESSENGER_END_OUT, MESSENGER_ANCHOR_HEIGHT), out(MESSENGER_INSULATOR[1], MESSENGER_ANCHOR_HEIGHT), ROD_RADIUS);
    rope(out(MESSENGER_INSULATOR[0], MESSENGER_ANCHOR_HEIGHT), out(surface(MESSENGER_ANCHOR_HEIGHT), MESSENGER_ANCHOR_HEIGHT), ROD_RADIUS);
    rope(out(CONTACT_END_OUT, h), out(CONTACT_INSULATOR[1], h), ROD_RADIUS);
    disc_string(builder, out(CONTACT_INSULATOR[0], h), out(CONTACT_INSULATOR[1], h), anchor, ANCHOR_DISCS);
    rope(out(CONTACT_INSULATOR[0], h), out(OUTER_PULLEY_OUT + r, h), ROD_RADIUS);
    clamp(h + r);
    V3 outer = out(OUTER_PULLEY_OUT, h);
    V3 inner = out(INNER_PULLEY_OUT, h - r);
    pulley(outer);
    pulley(inner);
    rope(out(surface(h + r), h + r), out(OUTER_PULLEY_OUT, h + r), ROPE);
    rope(out(OUTER_PULLEY_OUT, h - r), inner, ROPE);
    clamp(h);
    rope(out(surface(h), h), out(INNER_PULLEY_OUT, h), ROPE);
    V3 lever_pulley = out(WEIGHTS_OUT + r, h - LEVER_DROP);
    rope(out(INNER_PULLEY_OUT, h - 2 * r), out(WEIGHTS_OUT + r, h - LEVER_DROP + r), ROPE);
    pulley(lever_pulley);
    tube(builder, out(surface(h - 0.08), h - 0.08), lever_pulley, 0.035, 4, COLOR_STEEL, anchor, true);
    double radius = WEIGHT_STACK_RADIUS, disc_height = WEIGHT_STACK_DISC;
    int discs = WEIGHT_STACK_DISCS;
    double stack_top = WEIGHTS_BOTTOM + discs * disc_height;
    double bar_y = stack_top + 0.08;
    V3 weights_centre = local({pole[0] + tx * WEIGHTS_OUT, rail_y, pole[2] + tz * WEIGHTS_OUT});
    D2 frame_r = vec::right_of(D2{tx, tz});
    V3 sideways{frame_r[0], 0.0, frame_r[1]};
    double stack_offset = radius + WEIGHT_STACK_GAP / 2;
    rope(out(WEIGHTS_OUT, h - LEVER_DROP), out(WEIGHTS_OUT, bar_y), ROPE);
    tube(builder, add(out(WEIGHTS_OUT, bar_y), mul(sideways, -stack_offset - 0.02)), add(out(WEIGHTS_OUT, bar_y), mul(sideways, stack_offset + 0.02)),
         0.025, 4, COLOR_STEEL, anchor, true);
    for (double sign : {-1.0, 1.0}) {
        V3 centre = add(weights_centre, mul(sideways, sign * stack_offset));
        for (int i = 0; i < discs; i++) {
            double y0 = rail_y + WEIGHTS_BOTTOM + i * disc_height;
            tube(builder, {centre[0], y0 + 0.008, centre[2]}, {centre[0], y0 + disc_height - 0.008, centre[2]}, radius, 10, COLOR_FOUNDATION, anchor, true);
            tube(builder, {centre[0], y0, centre[2]}, {centre[0], y0 + disc_height, centre[2]}, radius - 0.012, 10, COLOR_FOUNDATION, anchor, false);
        }
        V3 rod_bottom{centre[0], rail_y + WEIGHTS_BOTTOM - 0.04, centre[2]};
        tube(builder, rod_bottom, {centre[0], rail_y + bar_y, centre[2]}, 0.015, 4, COLOR_STEEL, anchor, true);
        tube(builder, rod_bottom, {centre[0], rail_y + WEIGHTS_BOTTOM, centre[2]}, radius * 0.8, 8, COLOR_STEEL, anchor, true);
    }
    V3 ground = v3(sp.get("anchor").get("guy_ground"));
    double block_side = GUY_BLOCK[0], block_height_ground = GUY_BLOCK[1];
    V3 foot = local({ground[0], ground[1] + block_height_ground, ground[2]});
    V3 mean_top = out(0.0, (MESSENGER_ANCHOR_HEIGHT + h) / 2);
    V3 rod_dir = unit(sub(mean_top, foot));
    V3 joint = add(foot, mul(rod_dir, GUY_ROD_LENGTH));
    tube(builder, foot, joint, GUY_ROD_RADIUS, 6, COLOR_STEEL, anchor, true);
    D2 back = unit2(ground[0] - pole[0], ground[2] - pole[2]);
    V3 side{-back[1], 0.0, back[0]};
    for (double height : {MESSENGER_ANCHOR_HEIGHT, h}) {
        double y = rail_y + height;
        double rad = pole_radius_at(base_y, y) + 0.012;
        V3 centre = local({pole[0], y, pole[2]});
        double horizontal = py::hypot(joint[0] - centre[0], joint[2] - centre[2]);
        V3 split = lerp(centre, joint, pymin(0.5, GUY_SPLIT / pymax(horizontal, 1e-6)));
        rope(joint, split, GUY_RADIUS);
        std::vector<V3> loop;
        for (int i = 0; i < 7; i++) {
            double angle = M_PI * i / 6;
            V3 direction = add(mul(side, py::cos(angle)), {-back[0] * py::sin(angle), 0.0, -back[1] * py::sin(angle)});
            loop.push_back(add(centre, mul(direction, rad)));
        }
        rope(split, loop[0], GUY_RADIUS);
        rope(split, loop.back(), GUY_RADIUS);
        for (size_t i = 0; i + 1 < loop.size(); i++) rope(loop[i], loop[i + 1], GUY_RADIUS);
    }
    Frame frame(local({ground[0], ground[1], ground[2]}), back);
    sign_box(builder, frame, block_side / 2, block_side / 2, -0.5, block_height_ground, {{-0.5, block_height_ground, COLOR_FOUNDATION}}, anchor);
}

static void add_support(Builder& builder, const Value& sp, double ox, double oz, const Value& supports) {
    Local local{ox, oz};
    Keys k = support_points(sp);
    V3 pole = v3(sp.get("pole"));
    D2 anchor{pole[0] - ox, pole[2] - oz};
    double base_y = pole_base_y(sp);
    D2 t = d2(sp.get("t"));
    if (none_at(sp, "pole_owner")) {
        if (!none_at(sp, "bracket")) {
            add_bracket(builder, sp, ox, oz, anchor);
            concrete_pole(builder, pole, base_y + 0.05, base_y + POLE_HEIGHT, t, ox, oz, anchor, 0.0);
        } else {
            Value zebra = sp.get("zebra");
            concrete_pole(builder, pole, base_y, base_y + POLE_HEIGHT, t, ox, oz, anchor, POLE_BURIED, zebra.is_none() ? nullptr : &zebra);
        }
        if (truthy_at(sp, "traverse")) draw_traverses(builder, sp, local, anchor);
    }
    if (!none_at(sp, "anchor")) {
        add_anchor(builder, sp, ox, oz);
        return;
    }
    std::string kind = str_at(sp, "fixator", "direct");
    if (kind != "overlap") {
        draw_console(builder, sp, k, local, anchor, base_y, false);
        draw_fixator(builder, sp, k, local, anchor, kind);
        return;
    }
    Value host_index = sp.get("overlap_of");
    if (host_index.is_none()) host_index = sp.get("pole_owner");
    std::optional<Keys> host;
    if (!host_index.is_none()) {
        const Value& h = supports[(size_t)host_index.integer()];
        if (none_at(h, "anchor") && none_at(h, "portal") && !get_eq_str(h, "fixator", "overlap")) {
            host = support_points(h);
            std::string hk = str_at(h, "fixator", "direct");
            if (hk == "direct" || hk == "reverse") {
                host->has_fix = true;
                host->fix = fixator_geometry(h, *host, hk);
            }
        }
    }
    if (!host) {
        draw_console(builder, sp, k, local, anchor, base_y, false);
        draw_fixator(builder, sp, k, local, anchor, "direct");
        return;
    }
    const V3& messenger = k.messenger;
    double d = py::hypot(messenger[0] - host->axis_x, messenger[2] - host->axis_z);
    double dh = py::hypot(host->clevis[0] - host->axis_x, host->clevis[2] - host->axis_z);
    if (std::fabs(d - dh) > 0.12) {
        V3 top = host->on_tube(pymin(host->clevis[1], host->hinge[1] + (host->clevis[1] - host->hinge[1]) * d / pymax(dh, 0.1)));
        top = {messenger[0], top[1], messenger[2]};
        tube(builder, local(add(top, {0.0, -0.06, 0.0})), local(add(top, {0.0, 0.05, 0.0})), 0.04, 6, COLOR_STEEL, anchor, true);
        if (top[1] - messenger[1] > 0.3) {
            disc_string(builder, local(add(top, {0.0, -0.06, 0.0})), local(add(messenger, {0.0, 0.06, 0.0})), anchor);
            saddle(builder, messenger, k.t, anchor, local);
        }
    }
    draw_fixator(builder, sp, k, local, anchor, "overlap", &*host);
}

// ---------------------------------------------------------------- DPR
static void feeder_beam(const Value& fp, V3& root, V3& tip, double& y) {
    D2 pos = d2(fp.get("pos")), out = d2(fp.get("out"));
    double x = pos[0], z = pos[1];
    y = num_at(fp, "bracket_y");
    double root_out = num_at(fp, "root_out", 0.0);
    root = {x + out[0] * root_out, y, z + out[1] * root_out};
    tip = {x + out[0] * (FEEDER_ARM[1] + 0.15), y, z + out[1] * (FEEDER_ARM[1] + 0.15)};
}

static void add_feeder_pole(Builder& builder, const Value& fp, double ox, double oz) {
    Local local{ox, oz};
    D2 pos = d2(fp.get("pos"));
    double x = pos[0], z = pos[1];
    D2 anchor{x - ox, z - oz};
    V3 root, tip;
    double y;
    feeder_beam(fp, root, tip, y);
    D2 o = d2(fp.get("out"));
    V3 away{o[0], 0.0, o[1]};
    tube(builder, local(root), local(tip), 0.035, 4, COLOR_STEEL, anchor, true);
    std::string kind = str_at(fp, "kind", "pole");
    V3 strut_foot;
    auto frame_t = [&]() { return fp.has("t") ? d2(fp.get("t")) : D2{-away[2], away[0]}; };
    if (kind == "pole") {
        double base = num_at(fp, "base_y");
        double radius = pole_radius_at(base, y);
        for (double hh : {y, y - FEEDER_STRUT_DROP})
            tube(builder, local({x, hh - 0.04, z}), local({x, hh + 0.04, z}), pole_radius_at(base, hh) + 0.015, POLE_SIDES, COLOR_STEEL, anchor, true);
        strut_foot = {x + away[0] * radius, y - FEEDER_STRUT_DROP, z + away[2] * radius};
    } else {
        if (kind == "portal") {
            double stand_from = num_at(fp, "stand_from");
            V3 stand_foot{x, stand_from, z};
            tube(builder, local(stand_foot), local({x, y + 0.08, z}), 0.045, 4, COLOR_STEEL, anchor, true);
            double span = num_at(fp, "girder_width", 0.45) / 2 + 0.03;
            Frame frame(local({x, stand_from, z}), frame_t());
            sign_box(builder, frame, span, 0.07, 0.0, 0.06, {{0.0, 0.06, COLOR_STEEL}}, anchor);
            builder.polygon({frame.at(-span, -0.07, 0.0), frame.at(span, -0.07, 0.0), frame.at(span, 0.07, 0.0), frame.at(-span, 0.07, 0.0)}, COLOR_STEEL,
                            anchor, {0.0, -1.0, 0.0});
        }
        if (kind == "truss") {
            double low = num_at(fp, "chord_low", y - 0.4);
            Frame frame(local({x, low, z}), frame_t());
            sign_box(builder, frame, 0.18, 0.015, 0.0, y + 0.04 - low, {{0.0, y + 0.04 - low, COLOR_STEEL}}, anchor);
            strut_foot = {x + away[0] * 0.02, low + 0.03, z + away[2] * 0.02};
        } else {
            strut_foot = {x + away[0] * 0.05, y - FEEDER_STRUT_DROP * 0.8, z + away[2] * 0.05};
        }
    }
    V3 strut_top{x + away[0] * (FEEDER_ARM[0] - FEEDER_STRUT_IN), y - 0.03, z + away[2] * (FEEDER_ARM[0] - FEEDER_STRUT_IN)};
    tube(builder, local(strut_foot), local(strut_top), 0.025, 4, COLOR_STEEL, anchor, true);
    std::vector<V3> held = cat::feeder_points(fp);
    bool end = truthy_at(fp, "end");
    for (int k = 0; k < 2; k++) {
        double out = FEEDER_ARM[k];
        V3 top{x + away[0] * out, y - 0.04, z + away[2] * out};
        if (end) {
            V3 hook{top[0], held[k][1], top[2]};
            tube(builder, local(top), local(hook), 0.012, 4, COLOR_STEEL, anchor, true);
            disc_string(builder, local(hook), local(held[k]), anchor, ANCHOR_DISCS);
        } else {
            disc_string(builder, local(top), local({held[k][0], held[k][1] + WIRE_RADIUS * 0.5, held[k][2]}), anchor);
        }
    }
}

static void add_feeder_span(Builder& builder, const Value& a, const Value& b, double ox, double oz) {
    Local local{ox, oz};
    D2 pa_ = d2(a.get("pos")), pb_ = d2(b.get("pos"));
    D2 anchor{(pa_[0] + pb_[0]) / 2 - ox, (pa_[1] + pb_[1]) / 2 - oz};
    double length = py::dist2(pa_[0], pa_[1], pb_[0], pb_[1]);
    double sag = FEEDER_SAG_70M * py::pow(length / 70.0, 2.0);
    long long pieces = std::max(4LL, py::round_int(length / 8.0));
    std::vector<V3> pa = cat::feeder_points(a), pb = cat::feeder_points(b);
    if (dist3(pa[0], pb[0]) + dist3(pa[1], pb[1]) > dist3(pa[0], pb[1]) + dist3(pa[1], pb[0])) std::reverse(pb.begin(), pb.end());
    for (int k = 0; k < 2; k++) wire(builder, local(pa[k]), local(pb[k]), sag, pieces, WIRE_RADIUS, COLOR_FEEDER, anchor);
}

static void add_span(Builder& builder, const Value& a, const Value& b, double ox, double oz, const Value& span) {
    Local local{ox, oz};
    V3 ta = v3(a.get("track")), tb = v3(b.get("track"));
    D2 anchor{(ta[0] + tb[0]) / 2 - ox, (ta[2] + tb[2]) / 2 - oz};
    double length = py::dist2(ta[0], ta[2], tb[0], tb[2]);
    double scale = py::pow(length / 70.0, 2.0);
    double sag = MESSENGER_SAG_70M * scale;
    long long pieces = std::max(4LL, py::round_int(length / 8.0));
    V3 m0, c0, m1, c1;
    wire_ends(a, m0, c0);
    wire_ends(b, m1, c1);
    wire(builder, local(m0), local(m1), sag, pieces, WIRE_RADIUS, COLOR_MESSENGER, anchor);
    tube(builder, local(c0), local(c1), WIRE_RADIUS, 3, COLOR_CONTACT, anchor);
    auto messenger_at = [&](double f) {
        f = pymin(1.0, pymax(0.0, f));
        long long piece = std::min(pieces - 1, (long long)(f * pieces));
        double f0 = (double)piece / (double)pieces, f1 = (double)(piece + 1) / (double)pieces;
        V3 q0 = lerp(m0, m1, f0), q1 = lerp(m0, m1, f1);
        q0 = {q0[0], q0[1] - 4.0 * sag * f0 * (1.0 - f0), q0[2]};
        q1 = {q1[0], q1[1] - 4.0 * sag * f1 * (1.0 - f1), q1[2]};
        return lerp(q0, q1, (f - f0) * pieces);
    };
    long long count = (long long)py::floordiv(length, DROPPER_SPACING);
    for (long long i = 1; i <= count; i++) {
        double f = (double)i / (double)(count + 1);
        V3 c = lerp(c0, c1, f);
        V3 m = messenger_at(f);
        if (m[1] - c[1] < 0.25) continue;
        tube(builder, local(c), local(m), DROPPER_RADIUS, 3, COLOR_MESSENGER, anchor);
    }
    std::pair<double, const Value*> ends[2] = {{0.0, &a}, {1.0, &b}};
    for (auto& [end, spp] : ends) {
        const Value& sp = *spp;
        double towards = end == 0.0 ? 1.0 : -1.0;
        auto f_at = [&](double d) { return end + towards * d / pymax(length, 1e-6); };
        V3 foot;
        if (string_foot(sp, foot) && length > 2 * STRING_ALONG + 1.0)
            tube(builder, local(foot), local(messenger_at(f_at(STRING_ALONG))), DROPPER_RADIUS, 3, COLOR_STEEL, anchor);
        if (truthy_at(sp, "spring") && length > 2 * SPRING_ALONG + 2.0) {
            V3 here = messenger_at(end);
            double low = here[1] - SPRING_BELOW;
            V3 far = messenger_at(f_at(SPRING_ALONG));
            V3 mid = messenger_at(f_at(SPRING_DROPPER));
            mid = {mid[0], low, mid[2]};
            V3 centre{here[0], low, here[2]};
            tube(builder, local(far), local(mid), DROPPER_RADIUS * 1.3, 3, COLOR_STEEL, anchor);
            tube(builder, local(mid), local(centre), DROPPER_RADIUS * 1.3, 3, COLOR_STEEL, anchor);
            V3 c = lerp(c0, c1, f_at(SPRING_DROPPER));
            if (low - c[1] > 0.2) tube(builder, local(c), local(mid), DROPPER_RADIUS, 3, COLOR_MESSENGER, anchor);
        }
        if (truthy_at(sp, "middle_anchor")) {
            double d = pymin(MIDDLE_ANCHOR_ROPE, 0.45 * length);
            V3 top = messenger_at(end);
            V3 clamp = lerp(c0, c1, f_at(d));
            tube(builder, local(top), local({clamp[0], clamp[1] + 0.03, clamp[2]}), DROPPER_RADIUS * 1.4, 4, COLOR_STEEL, anchor, true);
            tube(builder, local({clamp[0], clamp[1] - 0.02, clamp[2]}), local({clamp[0], clamp[1] + 0.06, clamp[2]}), 0.03, 6, COLOR_STEEL, anchor, true);
        }
    }
    std::string ins = span.type == Value::DICT ? str_at(span, "insulators", "") : std::string();
    if ((ins == "from" || ins == "to") && length > 6.0) {
        double nearv = OVERLAP_INSULATOR_AT[0], farv = OVERLAP_INSULATOR_AT[1];
        double f0, f1;
        if (ins == "from") { f0 = nearv / length; f1 = farv / length; }
        else { f0 = 1.0 - nearv / length; f1 = 1.0 - farv / length; }
        disc_string(builder, local(messenger_at(f0)), local(messenger_at(f1)), anchor, ANCHOR_DISCS);
        disc_string(builder, local(lerp(c0, c1, f0)), local(lerp(c0, c1, f1)), anchor, ANCHOR_DISCS);
    }
}

long long add_catenary(Builder& builder, const Value& plan, const std::string& tile, double ox, double oz) {
    const Value& supports_v = plan.dct().find("supports") ? *plan.dct().find("supports") : Value();
    long long count = 0;
    Value portals = plan.has("portals") ? plan.get("portals") : Value::list();
    for (const Value& portal : portals.lst())
        if (portal.get("tile").str() == tile && !truthy_at(portal, "unused")) {
            add_portal(builder, portal, ox, oz);
            count++;
        }
    for (const Value& sp : supports_v.lst())
        if (sp.get("tile").str() == tile && !truthy_at(sp, "dropped")) {
            if (none_at(sp, "portal")) {
                add_support(builder, sp, ox, oz, supports_v);
                count++;
            } else {
                add_portal_hanger(builder, sp, portals[(size_t)sp.get("portal").integer()], ox, oz);
            }
        }
    for (const Value& span : plan.get("spans").lst())
        if (span.get("tile").str() == tile)
            add_span(builder, supports_v[(size_t)span.get("from").integer()], supports_v[(size_t)span.get("to").integer()], ox, oz, span);
    Value feeder_poles = plan.has("feeder_poles") ? plan.get("feeder_poles") : Value::list();
    for (const Value& fp : feeder_poles.lst())
        if (fp.get("tile").str() == tile) add_feeder_pole(builder, fp, ox, oz);
    if (plan.has("feeder_spans"))
        for (const Value& span : plan.get("feeder_spans").lst())
            if (span.get("tile").str() == tile)
                add_feeder_span(builder, feeder_poles[(size_t)span.get("from").integer()], feeder_poles[(size_t)span.get("to").integer()], ox, oz);
    return count;
}
