// rails.py geometry builder (Builder, polygon_normal, polys_to_meshes, collision chunks) and the
// small vector helpers of rails.py / catenary.py, with Python's evaluation order.
#pragma once
#include <array>
#include <cstdint>
#include <map>
#include <string>
#include <utility>
#include <vector>
#include "py.h"
#include "swmesh.h"

using D2 = std::array<double, 2>;
using Color = std::array<uint8_t, 4>;

namespace vec {
inline V3 sub(const V3& a, const V3& b) { return {a[0] - b[0], a[1] - b[1], a[2] - b[2]}; }
inline V3 add(const V3& a, const V3& b) { return {a[0] + b[0], a[1] + b[1], a[2] + b[2]}; }
inline V3 mul(const V3& a, double s) { return {a[0] * s, a[1] * s, a[2] * s}; }
inline double dot(const V3& a, const V3& b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
inline V3 cross(const V3& a, const V3& b) { return {a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]}; }
// rails.norm: zero vector for a zero input
inline V3 norm(const V3& a) {
    double length = std::sqrt(dot(a, a));
    if (length > 1e-12) return {a[0] / length, a[1] / length, a[2] / length};
    return {0.0, 0.0, 0.0};
}
// catenary._unit: up for a zero input
inline V3 unit(const V3& a) {
    double length = std::sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]);
    if (length > 1e-12) return {a[0] / length, a[1] / length, a[2] / length};
    return {0.0, 1.0, 0.0};
}
inline V3 lerp(const V3& p, const V3& q, double f) { return {p[0] + (q[0] - p[0]) * f, p[1] + (q[1] - p[1]) * f, p[2] + (q[2] - p[2]) * f}; }
inline V3 horizontal_dir(const V3& a, const V3& b) { return norm({b[0] - a[0], 0.0, b[2] - a[2]}); }
inline V3 left_of(const V3& t) { return {-t[2], 0.0, t[0]}; }
inline double dist3(const V3& a, const V3& b) { return py::dist3(a[0], a[1], a[2], b[0], b[1], b[2]); }
inline D2 unit2(double x, double z) {
    double length = py::hypot(x, z);
    if (length > 1e-9) return {x / length, z / length};
    return {1.0, 0.0};
}
inline D2 right_of(const D2& t) { return {t[1], -t[0]}; }
}  // namespace vec

V3 polygon_normal(const std::vector<V3>& points);

struct Poly {
    std::vector<V3> pts;
    D2 anchor{};
    bool strip = false;
    V3 n{};                                 // polygon: one normal and colour
    Color color{};
    std::vector<V3> normals;                // strip: per vertex
    std::vector<Color> colors;
    std::vector<std::array<int, 3>> tris;   // strip triangles (game winding)
};

struct Builder {
    std::vector<Poly> polys;
    std::vector<std::pair<std::array<V3, 3>, D2>> collision;
    void polygon(std::vector<V3> points, const Color& color, const D2& anchor, const V3& outward);
    void quad(const V3& p0, const V3& p1, const V3& p2, const V3& p3, const Color& color, const D2& anchor, const V3& outward) {
        polygon({p0, p1, p2, p3}, color, anchor, outward);
    }
};

extern double CHUNK_SIZE;                   // rails.CHUNK_SIZE (the whole-map build sets 250)
// chunk name -> mesh, sorted by chunk key
std::vector<std::pair<std::string, Mesh>> polys_to_meshes(const std::vector<Poly>& polys);
std::vector<std::pair<std::string, std::vector<std::array<V3, 3>>>> collision_to_phys_chunks(
    const std::vector<std::pair<std::array<V3, 3>, D2>>& collision);
// "%+d"
std::string fmt_plus(long long v);
