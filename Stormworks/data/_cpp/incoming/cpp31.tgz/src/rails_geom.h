// rails.py: rails, sleepers, ballast prism and track collision of one tile (build_tile_v4)
#pragma once
#include <functional>
#include <optional>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include "geom.h"
#include "graph.h"

// border cut of a node: a plain plane normal, or (cut plane normal, reference track direction)
struct BorderCut {
    V3 cut{};
    bool has_reference = false;
    V3 reference{};
};

namespace railsg {
extern double RAIL_PIECE_LENGTH;
}

// nodes: drawn graph (order + positions + raw links); returns the number of sleepers
long long build_tile_v4(Builder& builder, const std::vector<std::string>& order, const std::unordered_map<std::string, V3>& pos,
                        const std::unordered_map<std::string, std::vector<std::string>>& links,
                        const std::unordered_map<std::string, double>& node_y,
                        const std::unordered_map<std::string, BorderCut>& border_cuts,
                        const std::function<bool(const V3&)>* ballast_keep, size_t* chain_count);
