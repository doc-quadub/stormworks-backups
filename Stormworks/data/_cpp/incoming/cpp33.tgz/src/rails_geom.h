// rails.py: rails, sleepers, ballast prism and track collision of one tile (build_tile_v4)
#pragma once
#include <cmath>
#include <functional>
#include <optional>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include "geom.h"
#include "graph.h"

// border cut of a node: a plain plane normal, or (cut plane normal, reference track direction)
struct BorderCut {
    V3 cut{};
    bool has_reference = false;
    V3 reference{};
};

namespace railsg {
extern double RAIL_PIECE_LENGTH;
constexpr double SLEEPER_HALF_LENGTH = 1.35;
constexpr double RAIL_HALF_GAUGE = 0.85;
constexpr double RAIL_TOP_OFFSET = -0.03;
}

struct Sleeper {
    V3 center, axis_u, axis_t;
    double span[2];
    double top_y;
    int chain, segment, order;
    V3 direction;
    bool is_standard() const {
        return std::fabs(span[0] + railsg::SLEEPER_HALF_LENGTH) < 1e-6 && std::fabs(span[1] - railsg::SLEEPER_HALF_LENGTH) < 1e-6;
    }
};
// rails.place_sleepers on chain polylines (rail-top points)
std::vector<Sleeper> place_sleepers(const std::vector<std::vector<V3>>& chains_points);

// nodes: drawn graph (order + positions + raw links); returns the number of sleepers
long long build_tile_v4(Builder& builder, const std::vector<std::string>& order, const std::unordered_map<std::string, V3>& pos,
                        const std::unordered_map<std::string, std::vector<std::string>>& links,
                        const std::unordered_map<std::string, double>& node_y,
                        const std::unordered_map<std::string, BorderCut>& border_cuts,
                        const std::function<bool(const V3&)>* ballast_keep, size_t* chain_count);
