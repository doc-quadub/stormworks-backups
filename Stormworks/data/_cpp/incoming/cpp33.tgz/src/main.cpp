// sro: C++ port of the Stormworks Railway Overhaul generator (build_world.py and its tools)
//   sro <rom_dir> <work_dir> scan|signs|roads|catenary|tiles [workers]|assemble
//   sro <rom_dir> <work_dir> verify [first:last]
//   sro validate_mod <mod_dir>
//   sro compare_xml <mod_dir> <rom_dir>
#include <cstdlib>
#include <iostream>
#include <string>
#include "catenary_plan.h"
#include "checks.h"
#include "scan.h"
#include "signs_plan.h"
#include "swmesh.h"
#include "tiles.h"

int main(int argc, char** argv) {
    try {
        if (argc >= 3 && std::string(argv[1]) == "validate_mod") { step_validate_mod(argv[2]); return 0; }
        if (argc >= 4 && std::string(argv[1]) == "compare_xml") { step_compare_xml(argv[2], argv[3]); return 0; }
        if (argc < 4) {
            std::cerr << "usage: sro <rom_dir> <work_dir> scan|signs|roads|catenary|tiles|assemble|verify\n"
                         "       sro validate_mod <mod_dir>\n       sro compare_xml <mod_dir> <rom_dir>\n";
            return 2;
        }
        std::string rom = argv[1], work = argv[2], step = argv[3];
        make_dirs(work);
        if (step == "scan") step_scan(rom, work);
        else if (step == "signs") step_signs(rom, work);
        else if (step == "roads") step_roads(rom, work);
        else if (step == "catenary") step_catenary(rom, work);
        else if (step == "tiles") step_tiles(rom, work, argc > 4 ? std::atoi(argv[4]) : 2);
        else if (step == "assemble") step_assemble(rom, work);
        else if (step == "verify") step_verify(rom, work, argc > 4 ? argv[4] : "0:9999");
        else { std::cerr << "unknown step " << step << "\n"; return 2; }
    } catch (const std::exception& e) {
        std::cerr << "error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
