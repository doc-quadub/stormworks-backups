// Ports of verify.py, validate_mod.py and compare_xml.py (same printed results)
#include "checks.h"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <dirent.h>
#include <iostream>
#include <map>
#include <set>
#include <sys/stat.h>
#include <unordered_map>
#include <unordered_set>
#include "chains.h"
#include "graph.h"
#include "rails_geom.h"
#include "swmesh.h"
#include "value.h"

// ---------------------------------------------------------------- Python-like printing
static std::string prepr(const std::string& s) {
    bool sq = s.find('\'') != std::string::npos, dq = s.find('"') != std::string::npos;
    char q = (sq && !dq) ? '"' : '\'';
    std::string out(1, q);
    for (char c : s) {
        if (c == '\\') out += "\\\\";
        else if (c == q) { out += '\\'; out += c; }
        else if (c == '\n') out += "\\n";
        else if (c == '\r') out += "\\r";
        else if (c == '\t') out += "\\t";
        else out += c;
    }
    return out + q;
}

// glob.glob order: os.scandir order, hidden names skipped
struct DirEntry { std::string name; bool dir; };
static std::vector<DirEntry> scandir(const std::string& path) {
    std::vector<DirEntry> out;
    DIR* d = opendir(path.c_str());
    if (!d) return out;
    while (dirent* e = readdir(d)) {
        std::string n = e->d_name;
        if (n == "." || n == "..") continue;
        bool is_dir;
        if (e->d_type == DT_DIR) is_dir = true;
        else if (e->d_type == DT_UNKNOWN || e->d_type == DT_LNK) {
            struct stat st;
            is_dir = stat((path + "/" + n).c_str(), &st) == 0 && S_ISDIR(st.st_mode);
        } else is_dir = false;
        out.push_back({n, is_dir});
    }
    closedir(d);
    return out;
}
static bool ends_with(const std::string& s, const std::string& e) { return s.size() >= e.size() && s.compare(s.size() - e.size(), e.size(), e) == 0; }
// files directly in dir matching "*<ext>" (glob1)
static std::vector<std::string> glob_ext(const std::string& dir, const std::string& ext) {
    std::vector<std::string> out;
    for (auto& e : scandir(dir))
        if (e.name[0] != '.' && ends_with(e.name, ext)) out.push_back(dir + "/" + e.name);
    return out;
}
// glob(dir/**/*<ext>, recursive=True): dir itself, then its subdirectories depth first
static void rlist(const std::string& dir, std::vector<std::string>& dirs) {
    for (auto& e : scandir(dir))
        if (e.dir && e.name[0] != '.') {
            dirs.push_back(dir + "/" + e.name);
            rlist(dir + "/" + e.name, dirs);
        }
}
static std::vector<std::string> glob_recursive(const std::string& dir, const std::string& ext) {
    std::vector<std::string> dirs{dir};
    rlist(dir, dirs);
    std::vector<std::string> out;
    for (auto& d : dirs) for (auto& f : glob_ext(d, ext)) out.push_back(f);
    return out;
}
static std::string basename_of(const std::string& p) { size_t s = p.rfind('/'); return s == std::string::npos ? p : p.substr(s + 1); }

// ---------------------------------------------------------------- verify.py
static void check_sleepers(const Value& state, long long& total, long long& missing, std::vector<std::pair<double, double>>& where) {
    const Value graph = state.get("graph");
    const Value node_y = state.get("node_y");
    std::vector<std::string> order;
    std::unordered_map<std::string, V3> pos;
    std::unordered_map<std::string, std::vector<std::string>> links;
    for (auto& kv : graph.dct().items) {
        order.push_back(kv.first);
        pos[kv.first] = {kv.second[0].num(), kv.second[1].num(), kv.second[2].num()};
        std::vector<std::string> ls;
        for (const Value& o : kv.second[3].lst()) ls.push_back(o.str());
        links[kv.first] = ls;
    }
    auto chains = build_chains<std::string>(order, pos, links);
    std::vector<std::vector<V3>> points;
    for (auto& [c, through] : chains) {
        (void)through;
        std::vector<V3> pts;
        for (auto& k : c) pts.push_back({pos[k][0], node_y.get(k).num() + railsg::RAIL_TOP_OFFSET, pos[k][2]});
        points.push_back(pts);
    }
    std::vector<Sleeper> sleepers = place_sleepers(points);
    std::map<std::pair<long long, long long>, std::vector<int>> grid;
    for (size_t i = 0; i < sleepers.size(); i++)
        grid[{(long long)py::floordiv(sleepers[i].center[0], 4.0), (long long)py::floordiv(sleepers[i].center[2], 4.0)}].push_back((int)i);
    total = missing = 0;
    for (auto& pts : points) {
        double s_next = 0.3, s_base = 0.0;
        for (size_t seg = 0; seg + 1 < pts.size(); seg++) {
            const V3& a = pts[seg];
            const V3& b = pts[seg + 1];
            double seg_len = py::dist2(a[0], a[2], b[0], b[2]);
            if (seg_len < 1e-6) continue;
            V3 t = vec::horizontal_dir(a, b);
            while (s_next <= s_base + seg_len) {
                double f = (s_next - s_base) / seg_len;
                V3 p{a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f};
                V3 u = vec::left_of(t);
                for (int side : {-1, 1}) {
                    V3 r = vec::add(p, vec::mul(u, side * railsg::RAIL_HALF_GAUGE));
                    total++;
                    bool supported = false;
                    long long cx = (long long)py::floordiv(r[0], 4.0), cz = (long long)py::floordiv(r[2], 4.0);
                    for (long long ix = cx - 2; ix < cx + 3 && !supported; ix++)
                        for (long long iz = cz - 2; iz < cz + 3 && !supported; iz++) {
                            auto it = grid.find({ix, iz});
                            if (it == grid.end()) continue;
                            for (int si : it->second) {
                                const Sleeper& s = sleepers[si];
                                V3 d = vec::sub(r, s.center);
                                double du = vec::dot(d, s.axis_u);
                                if (s.span[0] <= du && du <= s.span[1] && std::fabs(vec::dot(d, s.axis_t)) <= 0.45) { supported = true; break; }
                            }
                        }
                    if (!supported) {
                        missing++;
                        where.push_back({py::round_nd(r[0], 1), py::round_nd(r[2], 1)});
                    }
                }
                s_next += 0.6;
            }
            s_base += seg_len;
        }
    }
}

static std::vector<std::pair<std::string, std::string>> check_close_nodes(const Value& state) {
    const Value graph = state.get("graph");
    const double cell = smooth::MIN_NODE_GAP;
    std::map<std::pair<long long, long long>, std::vector<std::string>> grid;
    for (auto& kv : graph.dct().items)
        grid[{(long long)py::floordiv(kv.second[0].num(), cell), (long long)py::floordiv(kv.second[2].num(), cell)}].push_back(kv.first);
    auto in_list = [](const Value& l, const std::string& s) {
        for (const Value& x : l.lst()) if (x.str() == s) return true;
        return false;
    };
    std::vector<std::pair<std::string, std::string>> close;
    for (auto& kv : graph.dct().items) {
        const std::string& k = kv.first;
        if (k.compare(0, 9, "train_rt_") != 0) continue;
        const Value& v = kv.second;
        long long cx = (long long)py::floordiv(v[0].num(), cell), cz = (long long)py::floordiv(v[2].num(), cell);
        for (long long ix = cx - 1; ix <= cx + 1; ix++)
            for (long long iz = cz - 1; iz <= cz + 1; iz++) {
                auto it = grid.find({ix, iz});
                if (it == grid.end()) continue;
                for (const std::string& o : it->second) {
                    const Value& w = *graph.dct().find(o);
                    if (o == k || in_list(v[3], o) || in_list(w[3], k)) continue;
                    if (py::hypot(v[0].num() - w[0].num(), v[2].num() - w[2].num()) < cell - 0.01) close.push_back({k, o});
                }
            }
    }
    return close;
}

static void check_switches(const std::string& rom, const std::string& tile, const Value& state, long long& count, std::vector<std::string>& changed) {
    Tracks vanilla = read_tracks(rom + "/data/tiles/" + tile + ".xml");
    const Value graph = state.get("graph");
    count = 0;
    for (const std::string& k : vanilla.order) {
        if (!smooth::is_junction(vanilla, k)) continue;
        count++;
        std::set<std::string> ours, theirs;
        for (const Value& o : graph.get(k)[3].lst()) ours.insert(o.str());
        for (const std::string& o : vanilla.at(k).links) if (vanilla.has(o)) theirs.insert(o);
        if (ours != theirs) changed.push_back(k);
    }
}

void step_verify(const std::string& rom, const std::string& work, const std::string& part) {
    std::vector<std::string> tiles;
    for (auto& f : glob_ext(work + "/tiles", ".json")) { std::string b = basename_of(f); tiles.push_back(b.substr(0, b.size() - 5)); }
    std::sort(tiles.begin(), tiles.end());
    size_t colon = part.find(':');
    long long first = std::stoll(part.substr(0, colon)), last = std::stoll(part.substr(colon + 1));
    long long n = (long long)tiles.size();
    auto clampi = [&](long long i) { if (i < 0) i += n; return std::max(0LL, std::min(n, i)); };
    first = clampi(first);
    last = clampi(last);
    std::vector<std::string> sel;
    for (long long i = first; i < last; i++) sel.push_back(tiles[i]);
    long long sleeper_total = 0, sleeper_missing = 0, switch_total = 0;
    std::vector<std::string> problems;
    for (const std::string& tile : sel) {
        Value state = json::load(work + "/tiles/" + tile + ".json");
        long long total, missing;
        std::vector<std::pair<double, double>> where;
        check_sleepers(state, total, missing, where);
        sleeper_total += total;
        sleeper_missing += missing;
        if (missing) {
            std::string w = "[";
            for (size_t i = 0; i < where.size() && i < 3; i++) w += (i ? ", (" : "(") + py::repr(where[i].first) + ", " + py::repr(where[i].second) + ")";
            problems.push_back("('sleepers', " + prepr(tile) + ", " + std::to_string(missing) + ", " + w + "])");
        }
        auto close = check_close_nodes(state);
        if (!close.empty()) {
            std::string c = "[";
            for (size_t i = 0; i < close.size() && i < 3; i++) c += (i ? ", (" : "(") + prepr(close[i].first) + ", " + prepr(close[i].second) + ")";
            problems.push_back("('new node close to an unlinked node', " + prepr(tile) + ", " + c + "])");
        }
        long long count;
        std::vector<std::string> changed;
        check_switches(rom, tile, state, count, changed);
        switch_total += count;
        if (!changed.empty()) {
            std::string c = "[";
            for (size_t i = 0; i < changed.size() && i < 5; i++) c += (i ? ", " : "") + prepr(changed[i]);
            problems.push_back("('switch links changed', " + prepr(tile) + ", " + c + "])");
        }
    }
    std::cout << "rail samples " << sleeper_total << ", without sleeper " << sleeper_missing << "; switches " << switch_total << "\n";
    for (size_t i = 0; i < problems.size() && i < 40; i++) std::cout << "  " << problems[i] << "\n";
    std::cout << "done" << std::endl;
}

// ---------------------------------------------------------------- validate_mod.py
template <class T> static T rd(const std::string& b, size_t off) { T v; std::memcpy(&v, b.data() + off, sizeof(T)); return v; }

static bool python_float_ok(std::string s, double& value) {
    // float(s): whitespace, sign, inf / infinity / nan, decimal digits with single underscores between digits
    size_t a = 0, e = s.size();
    while (a < e && (is_space(s[a]) || (s[a] >= '\x1c' && s[a] <= '\x1f'))) a++;
    while (e > a && (is_space(s[e - 1]) || (s[e - 1] >= '\x1c' && s[e - 1] <= '\x1f'))) e--;
    s = s.substr(a, e - a);
    if (s.empty()) return false;
    size_t i = 0;
    bool neg = false;
    if (s[i] == '+' || s[i] == '-') { neg = s[i] == '-'; i++; }
    std::string rest = s.substr(i), low;
    for (char c : rest) low += (char)std::tolower((unsigned char)c);
    if (low == "inf" || low == "infinity") { value = neg ? -INFINITY : INFINITY; return true; }
    if (low == "nan") { value = NAN; return true; }
    std::string clean;
    auto digits = [&](size_t& j) {
        size_t start = j;
        if (j >= rest.size() || !is_digit(rest[j])) return false;
        while (j < rest.size()) {
            if (is_digit(rest[j])) { clean += rest[j]; j++; }
            else if (rest[j] == '_' && j + 1 < rest.size() && is_digit(rest[j + 1]) && j > start) j++;
            else break;
        }
        return true;
    };
    size_t j = 0;
    bool intpart = digits(j);
    bool frac = false;
    if (j < rest.size() && rest[j] == '.') {
        clean += '.';
        j++;
        frac = digits(j);
    }
    if (!intpart && !frac) return false;
    if (j < rest.size() && (rest[j] == 'e' || rest[j] == 'E')) {
        clean += 'e';
        j++;
        if (j < rest.size() && (rest[j] == '+' || rest[j] == '-')) { clean += rest[j]; j++; }
        if (!digits(j)) return false;
    }
    if (j != rest.size()) return false;
    value = std::strtod(clean.c_str(), nullptr);
    if (neg) value = -value;
    return true;
}

void step_validate_mod(const std::string& mod) {
    std::vector<std::string> problems;
    std::vector<std::pair<std::string, long long>> degenerate_mesh;      // (path, count) problem entries
    std::vector<std::string> mesh_files = glob_recursive(mod + "/meshes", ".mesh");
    std::vector<std::string> phys_files = glob_recursive(mod + "/meshes", ".phys");
    long long max_v = 0;
    // problems are kept in order as (text, is ballast degenerate, count)
    struct Prob { std::string text; bool ballast_degenerate; long long count; };
    std::vector<Prob> probs;
    auto add = [&](const std::string& t) { probs.push_back({t, false, 0}); };
    for (const std::string& path : mesh_files) {
        std::string b = read_file(path);
        if (b.compare(0, 4, "mesh") != 0) { add("('bad header', " + prepr(path) + ")"); continue; }
        uint16_t vcount = rd<uint16_t>(b, 8);
        max_v = std::max(max_v, (long long)vcount);
        size_t off = 14;
        std::vector<std::array<float, 3>> p(vcount);
        bool finite = true;
        for (size_t i = 0; i < vcount; i++) {
            for (int k = 0; k < 3; k++) {
                p[i][k] = rd<float>(b, off + 28 * i + 4 * k);
                if (!std::isfinite(p[i][k])) finite = false;
                if (!std::isfinite(rd<float>(b, off + 28 * i + 16 + 4 * k))) finite = false;
            }
        }
        off += 28 * (size_t)vcount;
        uint32_t icount = rd<uint32_t>(b, off);
        off += 4;
        std::vector<uint16_t> idx(icount);
        uint16_t imax = 0;
        for (size_t i = 0; i < icount; i++) { idx[i] = rd<uint16_t>(b, off + 2 * i); imax = std::max(imax, idx[i]); }
        off += 2 * (size_t)icount;
        uint16_t sub = rd<uint16_t>(b, off);
        off += 2;
        if (!finite) add("('non-finite vertex', " + prepr(path) + ")");
        if (icount % 3 || (icount && imax >= vcount))
            add("('bad indices', " + prepr(path) + ", " + std::to_string(icount) + ", " + std::to_string(icount ? (long long)imax : -1LL) + ", " +
                std::to_string(vcount) + ")");
        for (int s = 0; s < sub; s++) {
            uint32_t start = rd<uint32_t>(b, off), count = rd<uint32_t>(b, off + 4);
            off += 8;
            off += 4;
            bool fin = true;
            for (int k = 0; k < 6; k++) if (!std::isfinite((double)rd<float>(b, off + 4 * k))) fin = false;
            off += 24;
            off += 2;
            uint16_t nlen = rd<uint16_t>(b, off);
            off += 2 + nlen + 12;
            if ((uint64_t)start + count > icount || !fin)
                add("('bad submesh', " + prepr(path) + ", " + std::to_string(start) + ", " + std::to_string(count) + ", " + std::to_string(icount) + ")");
        }
        if (off + 2 != b.size()) add("('trailing size', " + prepr(path) + ", " + std::to_string(off + 2) + ", " + std::to_string(b.size()) + ")");
        long long degenerate = 0;
        const float limit = (float)1e-10;
        for (size_t t = 0; t + 2 < idx.size() + 0 && t + 2 < icount; t += 3) {
            const auto& p0 = p[idx[t]];
            const auto& p1 = p[idx[t + 1]];
            const auto& p2 = p[idx[t + 2]];
            float a0 = p1[0] - p0[0], a1 = p1[1] - p0[1], a2 = p1[2] - p0[2];
            float b0 = p2[0] - p0[0], b1 = p2[1] - p0[1], b2 = p2[2] - p0[2];
            float c0 = a1 * b2; float tmp = a2 * b1; c0 = c0 - tmp;
            float c1 = a2 * b0; tmp = a0 * b2; c1 = c1 - tmp;
            float c2 = a0 * b1; tmp = a1 * b0; c2 = c2 - tmp;
            float s0 = c0 * c0, s1 = c1 * c1, s2 = c2 * c2;
            float sum = s0 + s1; sum = sum + s2;
            float area = std::sqrt(sum);
            if (area < limit) degenerate++;
        }
        if (degenerate) {
            std::string unix_path = path;
            probs.push_back({"('degenerate mesh triangles', " + prepr(path) + ", " + std::to_string(degenerate) + ")",
                             unix_path.find("/ballast/") != std::string::npos, degenerate});
        }
    }
    long long degenerate_phys = 0, max_part = 0;
    for (const std::string& path : phys_files) {
        std::string b = read_file(path);
        if (b.compare(0, 4, "phys") != 0) { add("('bad phys header', " + prepr(path) + ")"); continue; }
        uint16_t parts = rd<uint16_t>(b, 6);
        size_t off = 8;
        for (int q = 0; q < parts; q++) {
            uint16_t n = rd<uint16_t>(b, off);
            off += 2;
            max_part = std::max(max_part, (long long)n);
            std::vector<float> pts(3 * (size_t)n);
            bool fin = true;
            for (size_t i = 0; i < pts.size(); i++) { pts[i] = rd<float>(b, off + 4 * i); if (!std::isfinite(pts[i])) fin = false; }
            off += 12 * (size_t)n;
            off += 2;
            if (n % 3 || !fin) add("('bad phys part', " + prepr(path) + ", " + std::to_string(n) + ")");
            const float limit = (float)1e-8;
            for (size_t t = 0; t + 2 < (size_t)n; t += 3) {
                const float* v0 = &pts[3 * t];
                const float* v1 = &pts[3 * (t + 1)];
                const float* v2 = &pts[3 * (t + 2)];
                float a0 = v1[0] - v0[0], a1 = v1[1] - v0[1], a2 = v1[2] - v0[2];
                float b0 = v2[0] - v0[0], b1 = v2[1] - v0[1], b2 = v2[2] - v0[2];
                float c0 = a1 * b2; float tmp = a2 * b1; c0 = c0 - tmp;
                float c1 = a2 * b0; tmp = a0 * b2; c1 = c1 - tmp;
                float c2 = a0 * b1; tmp = a1 * b0; c2 = c2 - tmp;
                float sum = c0 * c0 + c1 * c1;
                sum = sum + c2 * c2;
                if (std::sqrt(sum) < limit) degenerate_phys++;
            }
        }
        if (off != b.size()) add("('phys trailing size', " + prepr(path) + ", " + std::to_string(off) + ", " + std::to_string(b.size()) + ")");
    }
    long long missing = 0, bad_links = 0, tiles = 0;
    for (const std::string& path : glob_ext(mod + "/data/tiles", ".xml")) {
        tiles++;
        std::string text = read_text_universal(path);
        size_t cnt = 0;
        for (size_t i = text.find("<train_tracks"); i != std::string::npos; i = text.find("<train_tracks", i + 1)) cnt++;
        if (cnt > 1) add("('two train_tracks', " + prepr(path) + ")");
        static const std::string fpre = "file_name=\"meshes/real_track/";
        for (size_t i = text.find(fpre); i != std::string::npos; i = text.find(fpre, i)) {
            size_t v0 = i + 11;                       // after file_name="
            size_t q = text.find('"', v0);
            if (q == std::string::npos || q == i + fpre.size()) { i++; continue; }
            if (!file_exists(mod + "/" + text.substr(v0, q - v0))) missing++;
            i = q + 1;
        }
        size_t t0 = text.find("<train_tracks>");
        size_t t1 = text.rfind("</train_tracks>");
        if (t0 != std::string::npos && t1 != std::string::npos && t1 >= t0 + 14) {
            std::string g = text.substr(t0 + 14, t1 - t0 - 14);
            std::unordered_set<std::string> ids;
            static const std::string tp = "<track id=\"";
            for (size_t i = g.find(tp); i != std::string::npos; i = g.find(tp, i + 1)) {
                size_t q = g.find('"', i + tp.size());
                if (q != std::string::npos && q > i + tp.size()) ids.insert(g.substr(i + tp.size(), q - i - tp.size()));
            }
            size_t i = 0;
            while ((i = g.find(tp, i)) != std::string::npos) {
                size_t start = i;
                size_t id0 = i + tp.size();
                size_t q = g.find('"', id0);
                bool ok = false;
                if (q != std::string::npos && q > id0 && q + 1 < g.size() && g[q + 1] == '>') {
                    size_t close = g.find("</track>", q + 2);
                    if (close != std::string::npos) {
                        ok = true;
                        std::string id = g.substr(id0, q - id0);
                        std::string body = g.substr(q + 2, close - q - 2);
                        for (const std::string& l : find_links(body))
                            if (!ids.count(l)) {
                                bad_links++;
                                add("('link to unknown node', " + prepr(basename_of(path)) + ", " + prepr(id) + ", " + prepr(l) + ")");
                            }
                        i = close + 8;
                    }
                }
                if (!ok) i = start + 1;
            }
        }
        // re.findall(r'\d\d="([^"]*)"', text)
        for (size_t k = 0; k + 3 < text.size(); ) {
            if (is_digit(text[k]) && is_digit(text[k + 1]) && text[k + 2] == '=' && text[k + 3] == '"') {
                size_t q = text.find('"', k + 4);
                if (q != std::string::npos) {
                    std::string num = text.substr(k + 4, q - k - 4);
                    double v;
                    if (!python_float_ok(num, v)) add("('bad number', " + prepr(path) + ", " + prepr(num) + ")");
                    else if (!std::isfinite(v)) add("('non-finite transform', " + prepr(path) + ")");
                    k = q + 1;
                    continue;
                }
            }
            k++;
        }
    }
    std::cout << "meshes " << mesh_files.size() << " max vertices " << max_v << " phys " << phys_files.size() << " max phys part " << max_part
              << " degenerate phys triangles " << degenerate_phys << " tiles " << tiles << " missing refs " << missing << " links to unknown nodes "
              << bad_links << "\n";
    std::cout << "problems " << probs.size() << "\n";
    long long nb = 0, sb = 0;
    for (auto& p : probs) if (p.ballast_degenerate) { nb++; sb += p.count; }
    std::cout << "degenerate triangles in ballast copies (vanilla geometry, colour-only copies): " << nb << " " << sb << "\n";
    for (auto& p : probs) if (!p.ballast_degenerate) std::cout << "   " << p.text << "\n";
    std::cout.flush();
}

// ---------------------------------------------------------------- compare_xml.py
static bool py_space(char c) { return is_space(c) || (c >= '\x1c' && c <= '\x1f'); }

// re.sub(r'<train_tracks>.*?</train_tracks>|<train_tracks/>', '', t, flags=re.S)
static std::string strip_tracks(const std::string& t) {
    std::string out;
    size_t i = 0;
    while (i < t.size()) {
        if (t.compare(i, 14, "<train_tracks>") == 0) {
            size_t e = t.find("</train_tracks>", i + 14);
            if (e != std::string::npos) { i = e + 15; continue; }
        }
        if (t.compare(i, 15, "<train_tracks/>") == 0) { i += 15; continue; }
        out += t[i++];
    }
    return out;
}
// one of the generated entries at position i: <tag id="<prefix>[^"]*"<mid>">\s*<transform...>\s*</tag>\s*; returns end or npos
static size_t match_entry(const std::string& t, size_t i, const std::string& open_prefix, const std::string& mid_attr, bool transform_attrs,
                          const std::string& closing) {
    if (t.compare(i, open_prefix.size(), open_prefix) != 0) return std::string::npos;
    size_t q = t.find('"', i + open_prefix.size());
    if (q == std::string::npos) return std::string::npos;
    size_t p = q + 1;
    if (t.compare(p, mid_attr.size(), mid_attr) != 0) return std::string::npos;
    size_t q2 = t.find('"', p + mid_attr.size());
    if (q2 == std::string::npos || q2 + 1 >= t.size() || t[q2 + 1] != '>') return std::string::npos;
    p = q2 + 2;
    while (p < t.size() && py_space(t[p])) p++;
    if (transform_attrs) {
        if (t.compare(p, 10, "<transform") != 0) return std::string::npos;
        size_t s = t.find('/', p + 10);
        if (s == std::string::npos || s + 1 >= t.size() || t[s + 1] != '>') return std::string::npos;
        p = s + 2;
    } else {
        if (t.compare(p, 12, "<transform/>") != 0) return std::string::npos;
        p += 12;
    }
    while (p < t.size() && py_space(t[p])) p++;
    if (t.compare(p, closing.size(), closing) != 0) return std::string::npos;
    p += closing.size();
    while (p < t.size() && py_space(t[p])) p++;
    return p;
}
static std::string remove_entries(const std::string& t, const std::string& open_prefix, const std::string& mid_attr, bool transform_attrs,
                                  const std::string& closing) {
    std::string out;
    size_t i = 0;
    while (i < t.size()) {
        size_t e = match_entry(t, i, open_prefix, mid_attr, transform_attrs, closing);
        if (e != std::string::npos) { i = e; continue; }
        out += t[i++];
    }
    return out;
}
static std::string norm_ws(const std::string& t) {
    std::string out;
    for (char c : t) if (!py_space(c)) out += c;
    auto rep = [](std::string s, const std::string& a, const std::string& b) {
        std::string o;
        size_t i = 0;
        while (true) {
            size_t j = s.find(a, i);
            if (j == std::string::npos) { o.append(s, i, std::string::npos); break; }
            o.append(s, i, j - i);
            o += b;
            i = j + a.size();
        }
        return o;
    };
    out = rep(out, "<meshes/>", "<meshes></meshes>");
    out = rep(out, "<physics_meshes/>", "<physics_meshes></physics_meshes>");
    out = rep(out, "<ladders/>", "<ladders></ladders>");
    return out;
}
// dict(re.findall(r'<track id="([^"]+)"([^>]*)>', text))
static std::vector<std::pair<std::string, std::string>> track_attrs(const std::string& t, std::unordered_map<std::string, size_t>& index) {
    std::vector<std::pair<std::string, std::string>> out;
    static const std::string tp = "<track id=\"";
    size_t i = 0;
    while ((i = t.find(tp, i)) != std::string::npos) {
        size_t id0 = i + tp.size();
        size_t q = t.find('"', id0);
        if (q != std::string::npos && q > id0) {
            size_t gt = t.find('>', q + 1);
            if (gt != std::string::npos) {
                std::string id = t.substr(id0, q - id0), attrs = t.substr(q + 1, gt - q - 1);
                auto it = index.find(id);
                if (it == index.end()) { index[id] = out.size(); out.push_back({id, attrs}); }
                else out[it->second].second = attrs;
                i = gt + 1;
                continue;
            }
        }
        i++;
    }
    return out;
}

void step_compare_xml(const std::string& mod, const std::string& rom) {
    long long diff = 0;
    std::vector<std::string> paths = glob_ext(mod + "/data/tiles", ".xml");
    std::sort(paths.begin(), paths.end());
    for (const std::string& path : paths) {
        std::string name = basename_of(path);
        std::string vanilla = read_text_universal(rom + "/data/tiles/" + name);
        std::string ours = read_text_universal(path);
        std::string ours2 = strip_tracks(ours);
        ours2 = remove_entries(ours2, "<mesh id=\"real_track_", " file_name=\"", false, "</mesh>");
        ours2 = remove_entries(ours2, "<physics_mesh id=\"real_track_phys_", " file_name=\"", false, "</physics_mesh>");
        ours2 = remove_entries(ours2, "<ladder id=\"real_track_ladder_", " height=\"", true, "</ladder>");
        {
            static const std::string bp = "file_name=\"meshes/real_track/ballast/";
            std::string out;
            size_t i = 0;
            while (i < ours2.size()) {
                if (ours2.compare(i, bp.size(), bp) == 0) {
                    size_t q = ours2.find('"', i + bp.size());
                    if (q != std::string::npos && q > i + bp.size()) {
                        std::string g = ours2.substr(i + bp.size(), q - i - bp.size());
                        std::string r;
                        for (size_t k = 0; k < g.size(); k++) {
                            if (g.compare(k, 2, "__") == 0) { r += '/'; k++; }
                            else r += g[k];
                        }
                        out += "file_name=\"meshes/" + r + "\"";
                        i = q + 1;
                        continue;
                    }
                }
                out += ours2[i++];
            }
            ours2 = out;
        }
        std::string v2 = strip_tracks(vanilla);
        std::string a = norm_ws(ours2), b = norm_ws(v2);
        if (a != b) {
            diff++;
            size_t m = std::min(a.size(), b.size()), i = 0;
            while (i < m && a[i] == b[i]) i++;
            auto slice = [](const std::string& s, size_t i) {
                size_t from = i >= 60 ? i - 60 : 0;
                return from < s.size() ? s.substr(from, std::min(s.size(), i + 80) - from) : std::string();
            };
            std::cout << "DIFF " << name << " at " << i << " | ours: " << slice(a, i) << " | vanilla: " << slice(b, i) << "\n";
        }
        std::unordered_map<std::string, size_t> vi, oi;
        auto vt = track_attrs(vanilla, vi);
        auto ot = track_attrs(ours, oi);
        for (auto& [k, attrs] : vt) {
            auto it = oi.find(k);
            if (it == oi.end() || ot[it->second].second != attrs) {
                diff++;
                std::cout << "TRACK " << name << " " << k << " " << prepr(attrs) << " " << (it == oi.end() ? std::string("None") : prepr(ot[it->second].second))
                          << "\n";
            }
        }
    }
    std::cout << "tiles with differences outside the intended changes: " << diff << std::endl;
}
