// Port of rails.py geometry (v4 whole-map build)
#include "rails_geom.h"
#include <algorithm>
#include <cmath>
#include <map>
#include "chains.h"

using namespace vec;

namespace railsg {
double RAIL_PIECE_LENGTH = 4.0;
}

static const double RAIL_HALF_GAUGE = 0.85;
static const double RAIL_TOP_OFFSET = -0.03;
static const double SLEEPER_SPACING = 0.60;
static const double SLEEPER_HALF_LENGTH = railsg::SLEEPER_HALF_LENGTH;
static const double SLEEPER_HALF_WIDTH = 0.14;
static const double SLEEPER_TOP_HALF_WIDTH_LOSS = 0.03;
static const double SLEEPER_HEIGHT = 0.19;
static const double SLEEPER_MERGE_MAX_ANGLE = 12.0 * (M_PI / 180.0);
static const double SLEEPER_EXTENSION_MARGIN = 0.35;
static const double SLEEPER_MAX_HALF_SPAN = 4.5;
static const double BALLAST_TOP_BELOW_SLEEPER = 0.03;
static const double BALLAST_TOP_HALF_WIDTH = 1.18;
static const double BALLAST_BOTTOM_HALF_WIDTH = 1.63;
static const double BALLAST_BOTTOM_BELOW_SLEEPER = SLEEPER_HEIGHT;
static const double BALLAST_PIECE_LENGTH = 4.0;
static const Color COLOR_BALLAST = {82, 80, 76, 255};
static const Color COLOR_RAIL_SIDE = {62, 56, 52, 255};
static const Color COLOR_RAIL_TOP = {150, 148, 145, 255};
static const Color COLOR_SLEEPER = {138, 136, 130, 255};
static const Color COLOR_SLEEPER_TOP = {158, 156, 150, 255};
static const double RAIL_PROFILE[14][2] = {
    {-0.075, -0.172}, {-0.075, -0.157}, {-0.009, -0.140}, {-0.009, -0.060}, {-0.036, -0.048}, {-0.036, -0.008}, {-0.030, 0.000},
    {0.030, 0.000},   {0.036, -0.008},  {0.036, -0.048},  {0.009, -0.060},  {0.009, -0.140},  {0.075, -0.157}, {0.075, -0.172}};
static const double RAIL_HEIGHT = 0.172;
static const int RAIL_TOP_EDGE_INDEX = 6;
static const int RAIL_EDGE_COUNT = 13;
static const int RAIL_MAX_RINGS_PER_STRIP = 400;
static const double RAIL_COLLISION_TOP_DROP = 0.11;
static const double RAIL_COLLISION_HALF_WIDTH = 0.04;
static const double COLLISION_PIECE_LENGTH = 20.0;
static const double OVERLAP_DROP = 0.01;

static std::vector<std::array<double, 2>> collision_profile() {
    double seat = -RAIL_HEIGHT, ridge = -RAIL_COLLISION_TOP_DROP, bottom = seat - SLEEPER_HEIGHT;
    double g = RAIL_HALF_GAUGE, w = RAIL_COLLISION_HALF_WIDTH, half = SLEEPER_HALF_LENGTH;
    return {{-half, bottom}, {-half, seat}, {-g - w, seat}, {-g - w, ridge}, {-g + w, ridge}, {-g + w, seat},
            {g - w, seat},   {g - w, ridge}, {g + w, ridge}, {g + w, seat},  {half, seat},     {half, bottom}};
}
static const std::vector<std::array<double, 2>> COLLISION_PROFILE = collision_profile();

// ---------------------------------------------------------------- sleepers
static void concrete_sleeper(Builder& builder, const V3& center, const V3& axis_u, const V3& axis_t, const double span[2], double seat_y) {
    double bottom_y = seat_y - SLEEPER_HEIGHT;
    D2 anchor{center[0], center[2]};
    bool standard = span[0] <= -SLEEPER_HALF_LENGTH + 1e-6 && span[0] >= -SLEEPER_HALF_LENGTH - 1e-6 &&
                    std::fabs(span[1] - SLEEPER_HALF_LENGTH) < 1e-6;
    // the standard profile after without_collinear_points: [(-1.35, 0.19), (1.35, 0.19)]
    double prof[2][2];
    if (standard) { prof[0][0] = -1.35; prof[0][1] = 0.190; prof[1][0] = 1.35; prof[1][1] = 0.190; }
    else { prof[0][0] = span[0]; prof[0][1] = SLEEPER_HEIGHT; prof[1][0] = span[1]; prof[1][1] = SLEEPER_HEIGHT; }
    auto half_width = [&](double h) { return SLEEPER_HALF_WIDTH - SLEEPER_TOP_HALF_WIDTH_LOSS * h / SLEEPER_HEIGHT; };
    auto point = [&](double u, double h, int side) {
        V3 p = add(add(center, mul(axis_u, u)), mul(axis_t, side * half_width(h)));
        return V3{p[0], bottom_y + h, p[2]};
    };
    double u_min = prof[0][0], u_max = prof[1][0];
    {
        double u0 = prof[0][0], h0 = prof[0][1], u1 = prof[1][0], h1 = prof[1][1];
        V3 up = add(mul(axis_u, -(h1 - h0)), {0.0, u1 - u0, 0.0});
        builder.quad(point(u0, h0, -1), point(u1, h1, -1), point(u1, h1, 1), point(u0, h0, 1), COLOR_SLEEPER_TOP, anchor, up);
    }
    for (int side : {-1, 1}) {
        std::vector<V3> pts{point(u_min, 0.0, side), point(u_max, 0.0, side), point(u_max, prof[1][1], side), point(u_min, prof[0][1], side)};
        builder.polygon(pts, COLOR_SLEEPER, anchor, mul(axis_t, side));
    }
    struct E { double u, h; int sign; };
    for (E e : {E{u_min, prof[0][1], -1}, E{u_max, prof[1][1], 1}})
        builder.quad(point(e.u, 0.0, -1), point(e.u, 0.0, 1), point(e.u, e.h, 1), point(e.u, e.h, -1), COLOR_SLEEPER, anchor, mul(axis_u, e.sign));
}

static bool oriented_rect_overlap(const V3& c1, const V3& u1, const double span1[2], const V3& t1, double hw1,
                                  const V3& c2, const V3& u2, const double span2[2], const V3& t2, double hw2) {
    double r1 = std::sqrt(py::pymax(span1[0] * span1[0], span1[1] * span1[1]) + hw1 * hw1);
    double r2 = std::sqrt(py::pymax(span2[0] * span2[0], span2[1] * span2[1]) + hw2 * hw2);
    double dx = c1[0] - c2[0], dz = c1[2] - c2[2];
    if (dx * dx + dz * dz > (r1 + r2) * (r1 + r2)) return false;
    double mid1 = (span1[0] + span1[1]) / 2, half1 = (span1[1] - span1[0]) / 2;
    double mid2 = (span2[0] + span2[1]) / 2, half2 = (span2[1] - span2[0]) / 2;
    const double axes[4][2] = {{u1[0], u1[2]}, {t1[0], t1[2]}, {u2[0], u2[2]}, {t2[0], t2[2]}};
    for (auto& k : axes) {
        double kx = k[0], kz = k[1];
        double ku1 = kx * u1[0] + kz * u1[2];
        double kt1 = kx * t1[0] + kz * t1[2];
        double ku2 = kx * u2[0] + kz * u2[2];
        double kt2 = kx * t2[0] + kz * t2[2];
        double centre1 = kx * c1[0] + kz * c1[2] + ku1 * mid1;
        double centre2 = kx * c2[0] + kz * c2[2] + ku2 * mid2;
        double extent1 = std::fabs(ku1) * half1 + std::fabs(kt1) * hw1;
        double extent2 = std::fabs(ku2) * half2 + std::fabs(kt2) * hw2;
        if (std::fabs(centre1 - centre2) > extent1 + extent2) return false;
    }
    return true;
}

static double sleeper_reach_along(const Sleeper& o, const V3& u) {
    return std::fabs(dot(o.axis_u, u)) * py::pymax(-o.span[0], o.span[1]) + std::fabs(dot(o.axis_t, u)) * SLEEPER_HALF_WIDTH;
}

static bool try_merge(std::vector<Sleeper>& placed, const std::vector<int>& overlapping, const V3 rails[2], const V3& t) {
    if (overlapping.empty()) return false;
    for (int oi : overlapping) {
        const Sleeper& other = placed[oi];
        double angle = std::acos(std::max(-1.0, std::min(1.0, std::fabs(dot(t, other.axis_t)))));
        if (angle >= SLEEPER_MERGE_MAX_ANGLE) return false;
    }
    std::vector<int> by_span = overlapping;
    std::stable_sort(by_span.begin(), by_span.end(), [&](int a, int b) {
        return placed[a].span[1] - placed[a].span[0] < placed[b].span[1] - placed[b].span[0];
    });
    for (int oi : by_span) {
        Sleeper& other = placed[oi];
        double lo = other.span[0], hi = other.span[1];
        for (int k = 0; k < 2; k++) {
            double s = dot(sub(rails[k], other.center), other.axis_u);
            lo = py::pymin(lo, s - SLEEPER_EXTENSION_MARGIN);
            hi = py::pymax(hi, s + SLEEPER_EXTENSION_MARGIN);
        }
        if (lo >= -SLEEPER_MAX_HALF_SPAN && hi <= SLEEPER_MAX_HALF_SPAN) {
            other.span[0] = lo;
            other.span[1] = hi;
            return true;
        }
    }
    return false;
}

std::vector<Sleeper> place_sleepers(const std::vector<std::vector<V3>>& chains_points) {
    std::vector<Sleeper> placed;
    std::map<std::pair<long long, long long>, std::vector<int>> grid;
    double largest_reach = 0.0;
    auto cell = [](double v) { return (long long)py::floordiv(v, 5.0); };
    for (size_t chain_index = 0; chain_index < chains_points.size(); chain_index++) {
        const std::vector<V3>& points = chains_points[chain_index];
        int order = 0;
        // sample_chain(points, SLEEPER_SPACING, SLEEPER_SPACING / 2)
        double s_next = SLEEPER_SPACING / 2, s_base = 0.0;
        for (size_t seg_index = 0; seg_index + 1 < points.size(); seg_index++) {
            const V3& a = points[seg_index];
            const V3& b = points[seg_index + 1];
            double seg_len = py::dist2(a[0], a[2], b[0], b[2]);
            if (seg_len < 1e-6) continue;
            V3 t = horizontal_dir(a, b);
            V3 d3 = norm(sub(b, a));
            while (s_next <= s_base + seg_len) {
                double f = (s_next - s_base) / seg_len;
                V3 pos{a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f};
                // ---- one sleeper
                order += 1;
                V3 u = left_of(t);
                double top_y = pos[1] - RAIL_HEIGHT;
                double span[2] = {-SLEEPER_HALF_LENGTH, SLEEPER_HALF_LENGTH};
                V3 rails[2] = {add(pos, mul(u, -RAIL_HALF_GAUGE)), add(pos, mul(u, RAIL_HALF_GAUGE))};
                double reach = std::sqrt(SLEEPER_HALF_LENGTH * SLEEPER_HALF_LENGTH + SLEEPER_HALF_WIDTH * SLEEPER_HALF_WIDTH);
                std::vector<int> overlapping;
                {
                    double radius = py::pymin(6.0, reach + largest_reach);
                    long long cx = cell(pos[0]), cz = cell(pos[2]);
                    long long r = (long long)py::floordiv(radius, 5.0) + 1;
                    for (long long ix = cx - r; ix <= cx + r; ix++)
                        for (long long iz = cz - r; iz <= cz + r; iz++) {
                            auto it = grid.find({ix, iz});
                            if (it == grid.end()) continue;
                            for (int oi : it->second) {
                                const Sleeper& o = placed[oi];
                                double other_reach = std::sqrt(py::pymax(o.span[0] * o.span[0], o.span[1] * o.span[1]) +
                                                               SLEEPER_HALF_WIDTH * SLEEPER_HALF_WIDTH);
                                double dx = pos[0] - o.center[0], dz = pos[2] - o.center[2];
                                if (dx * dx + dz * dz > (reach + other_reach) * (reach + other_reach)) continue;
                                if (oriented_rect_overlap(pos, u, span, t, SLEEPER_HALF_WIDTH, o.center, o.axis_u, o.span, o.axis_t,
                                                          SLEEPER_HALF_WIDTH))
                                    overlapping.push_back(oi);
                            }
                        }
                }
                if (try_merge(placed, overlapping, rails, t)) {
                    for (int oi : overlapping) {
                        const Sleeper& o = placed[oi];
                        largest_reach = py::pymax(largest_reach, std::sqrt(py::pymax(o.span[0] * o.span[0], o.span[1] * o.span[1]) +
                                                                           SLEEPER_HALF_WIDTH * SLEEPER_HALF_WIDTH));
                    }
                } else {
                    for (int oi : overlapping) {
                        const Sleeper& o = placed[oi];
                        double side = dot(sub(o.center, pos), u);
                        if (side > 0)
                            span[1] = py::pymax(RAIL_HALF_GAUGE + SLEEPER_EXTENSION_MARGIN, py::pymin(span[1], side - sleeper_reach_along(o, u)));
                        else
                            span[0] = py::pymin(-RAIL_HALF_GAUGE - SLEEPER_EXTENSION_MARGIN, py::pymax(span[0], side + sleeper_reach_along(o, u)));
                    }
                    if (!overlapping.empty()) top_y -= OVERLAP_DROP;
                    Sleeper s{pos, u, t, {span[0], span[1]}, top_y, (int)chain_index, (int)seg_index, order, d3};
                    placed.push_back(s);
                    grid[{cell(s.center[0]), cell(s.center[2])}].push_back((int)placed.size() - 1);
                    largest_reach = py::pymax(largest_reach, reach);
                }
                // ----
                s_next += SLEEPER_SPACING;
            }
            s_base += seg_len;
        }
    }
    return placed;
}

static void add_standard_sleeper(Builder& builder, const std::vector<Poly>& tmpl, const Sleeper& s) {
    const V3& forward = s.direction;
    V3 right = norm({forward[2], 0.0, -forward[0]});
    V3 up = cross(forward, right);
    double m[4][3] = {{right[0], right[1], right[2]}, {up[0], up[1], up[2]}, {forward[0], forward[1], forward[2]},
                      {s.center[0], s.top_y, s.center[2]}};
    D2 anchor{s.center[0], s.center[2]};
    for (const Poly& t : tmpl) {
        Poly p;
        p.pts.reserve(t.pts.size());
        for (const V3& q : t.pts)
            p.pts.push_back({q[0] * m[0][0] + q[1] * m[1][0] + q[2] * m[2][0] + m[3][0], q[0] * m[0][1] + q[1] * m[1][1] + q[2] * m[2][1] + m[3][1],
                             q[0] * m[0][2] + q[1] * m[1][2] + q[2] * m[2][2] + m[3][2]});
        const V3& n = t.n;
        p.n = {n[0] * m[0][0] + n[1] * m[1][0] + n[2] * m[2][0], n[0] * m[0][1] + n[1] * m[1][1] + n[2] * m[2][1],
               n[0] * m[0][2] + n[1] * m[1][2] + n[2] * m[2][2]};
        p.color = t.color;
        p.anchor = anchor;
        builder.polys.push_back(std::move(p));
    }
}

// ---------------------------------------------------------------- rails
static std::vector<V3> densify(const std::vector<V3>& points, double max_step) {
    std::vector<V3> out{points[0]};
    for (size_t k = 0; k + 1 < points.size(); k++) {
        const V3& a = points[k];
        const V3& b = points[k + 1];
        long long n = std::max(1LL, (long long)std::ceil(dist3(a, b) / max_step));
        for (long long i = 1; i <= n; i++) {
            double f = (double)i / (double)n;
            out.push_back({a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f});
        }
    }
    return out;
}

struct Offset { V3 n; double scale; };

static Offset miter_for(const V3& cut_dir, const V3& segment_dir) {
    V3 n = left_of(cut_dir);
    double c = dot(n, left_of(segment_dir));
    return {n, c > 0.3 ? 1.0 / c : 1.0};
}

static std::vector<Offset> miter_offsets(const std::vector<V3>& points) {
    std::vector<V3> tangents;
    for (size_t i = 0; i + 1 < points.size(); i++) tangents.push_back(horizontal_dir(points[i], points[i + 1]));
    std::vector<Offset> result;
    for (size_t i = 0; i < points.size(); i++) {
        if (i == 0) result.push_back({left_of(tangents[0]), 1.0});
        else if (i == points.size() - 1) result.push_back({left_of(tangents.back()), 1.0});
        else {
            V3 n1 = left_of(tangents[i - 1]), n2 = left_of(tangents[i]);
            V3 n = norm(add(n1, n2));
            double c = dot(n, n2);
            result.push_back({n, c > 0.3 ? 1.0 / c : 1.0});
        }
    }
    return result;
}

static void add_rail_strips(Builder& builder, const std::vector<V3>& points, const std::vector<std::vector<V3>>& rings) {
    size_t segment_count = rings.size() - 1;
    std::vector<std::array<V3, 13>> face_normals(segment_count);
    std::vector<std::array<bool, 13>> flipped(segment_count);
    for (size_t i = 0; i < segment_count; i++) {
        const auto& a = rings[i];
        const auto& b = rings[i + 1];
        V3 n_seg = left_of(horizontal_dir(points[i], points[i + 1]));
        for (int e = 0; e < RAIL_EDGE_COUNT; e++) {
            double u0 = RAIL_PROFILE[e][0], h0 = RAIL_PROFILE[e][1], u1 = RAIL_PROFILE[e + 1][0], h1 = RAIL_PROFILE[e + 1][1];
            double eu = -(h1 - h0), eh = u1 - u0;
            V3 outward{n_seg[0] * eu, eh, n_seg[2] * eu};
            V3 n = polygon_normal({a[e], a[e + 1], b[e + 1], b[e]});
            bool flip = dot(n, outward) < 0;
            face_normals[i][e] = flip ? mul(n, -1.0) : n;
            flipped[i][e] = flip;
        }
    }
    auto ring_normal = [&](size_t j, int e) {
        V3 n;
        bool has_prev = j >= 1 && j - 1 < segment_count, has_cur = j < segment_count;
        if (has_prev && has_cur) n = norm(add(face_normals[j - 1][e], face_normals[j][e]));
        else n = norm(has_prev ? face_normals[j - 1][e] : face_normals[j][e]);
        if (n[0] == 0.0 && n[1] == 0.0 && n[2] == 0.0) return V3{0.0, 1.0, 0.0};
        return n;
    };
    auto chunk_of = [&](size_t i) {
        return std::make_pair((long long)std::floor((points[i][0] + points[i + 1][0]) / 2 / CHUNK_SIZE),
                              (long long)std::floor((points[i][2] + points[i + 1][2]) / 2 / CHUNK_SIZE));
    };
    size_t start = 0;
    while (start < segment_count) {
        size_t end = start + 1;
        while (end < segment_count && (long long)(end - start) < RAIL_MAX_RINGS_PER_STRIP - 1 && chunk_of(end) == chunk_of(start)) end++;
        Poly p;
        p.strip = true;
        for (size_t j = start; j <= end; j++)
            for (int e = 0; e < RAIL_EDGE_COUNT; e++) {
                const Color& color = e == RAIL_TOP_EDGE_INDEX ? COLOR_RAIL_TOP : COLOR_RAIL_SIDE;
                V3 n = ring_normal(j, e);
                for (int k : {e, e + 1}) {
                    p.pts.push_back(rings[j][k]);
                    p.normals.push_back(n);
                    p.colors.push_back(color);
                }
            }
        int per_ring = 2 * RAIL_EDGE_COUNT;
        for (size_t i = start; i < end; i++) {
            int row_a = (int)(i - start) * per_ring;
            int row_b = row_a + per_ring;
            for (int e = 0; e < RAIL_EDGE_COUNT; e++) {
                int q[4] = {row_a + 2 * e, row_a + 2 * e + 1, row_b + 2 * e + 1, row_b + 2 * e};
                if (flipped[i][e]) { int q1 = q[1]; q[1] = q[3]; q[3] = q1; }
                p.tris.push_back({q[0], q[2], q[1]});
                p.tris.push_back({q[0], q[3], q[2]});
            }
        }
        p.anchor = {(points[start][0] + points[start + 1][0]) / 2, (points[start][2] + points[start + 1][2]) / 2};
        builder.polys.push_back(std::move(p));
        start = end;
    }
}

static void add_rail_cap(Builder& builder, const std::vector<V3>& ring, const V3& outward) {
    D2 anchor{ring[0][0], ring[0][2]};
    static const int pieces[4][4] = {{0, 1, 12, 13}, {2, 3, 10, 11}, {4, 5, 8, 9}, {5, 6, 7, 8}};
    for (auto& q : pieces) builder.quad(ring[q[0]], ring[q[1]], ring[q[2]], ring[q[3]], COLOR_RAIL_SIDE, anchor, outward);
}

static void add_collision_piece(Builder& builder, const std::vector<V3>& a, const std::vector<V3>& b, const V3& n_seg, const D2& anchor) {
    for (size_t e = 0; e + 1 < COLLISION_PROFILE.size(); e++) {
        double u0 = COLLISION_PROFILE[e][0], h0 = COLLISION_PROFILE[e][1];
        double u1 = COLLISION_PROFILE[e + 1][0], h1 = COLLISION_PROFILE[e + 1][1];
        double eu = -(h1 - h0), eh = u1 - u0;
        V3 outward{n_seg[0] * eu, eh, n_seg[2] * eu};
        std::vector<V3> quad{a[e], a[e + 1], b[e + 1], b[e]};
        if (dot(polygon_normal(quad), outward) < 0) quad = {quad[0], quad[3], quad[2], quad[1]};
        builder.collision.push_back({{quad[0], quad[2], quad[1]}, anchor});
        builder.collision.push_back({{quad[0], quad[3], quad[2]}, anchor});
    }
}

static void add_track_collision(Builder& builder, const std::vector<V3>& points, const std::vector<Offset>& offsets) {
    std::vector<std::vector<V3>> rings;
    for (size_t i = 0; i < points.size(); i++) {
        const V3& p = points[i];
        const V3& n = offsets[i].n;
        double scale = offsets[i].scale;
        std::vector<V3> ring;
        for (auto& uh : COLLISION_PROFILE) ring.push_back({p[0] + n[0] * uh[0] * scale, p[1] + uh[1], p[2] + n[2] * uh[0] * scale});
        rings.push_back(ring);
    }
    for (size_t i = 0; i + 1 < rings.size(); i++) {
        V3 n_seg = left_of(horizontal_dir(points[i], points[i + 1]));
        long long pieces = std::max(1LL, (long long)std::ceil(dist3(points[i], points[i + 1]) / COLLISION_PIECE_LENGTH));
        for (long long k = 0; k < pieces; k++) {
            double f0 = (double)k / (double)pieces, f1 = (double)(k + 1) / (double)pieces;
            std::vector<V3> a, b;
            for (size_t q = 0; q < rings[i].size(); q++) {
                a.push_back(lerp(rings[i][q], rings[i + 1][q], f0));
                b.push_back(lerp(rings[i][q], rings[i + 1][q], f1));
            }
            V3 mid = lerp(points[i], points[i + 1], (f0 + f1) / 2);
            add_collision_piece(builder, a, b, n_seg, {mid[0], mid[2]});
        }
    }
}

static Offset end_offset(const BorderCut& bc, const V3& segment_dir) {
    V3 cut = bc.cut;
    V3 reference = bc.has_reference ? bc.reference : segment_dir;
    if (dot(cut, segment_dir) < 0) cut = mul(cut, -1.0);
    if (dot(reference, cut) < 0) reference = mul(reference, -1.0);
    return miter_for(cut, reference);
}

static void build_rails(Builder& builder, const std::vector<V3>& points, bool capped_start, bool capped_end,
                        const BorderCut* start_dir, const BorderCut* end_dir) {
    std::vector<Offset> offsets = miter_offsets(points);
    if (start_dir) offsets[0] = end_offset(*start_dir, horizontal_dir(points[0], points[1]));
    if (end_dir) offsets.back() = end_offset(*end_dir, horizontal_dir(points[points.size() - 2], points.back()));
    for (double side : {-1.0, 1.0}) {
        std::vector<std::vector<V3>> rings;
        for (size_t i = 0; i < points.size(); i++) {
            const V3& p = points[i];
            std::vector<V3> ring;
            for (auto& uh : RAIL_PROFILE) {
                double lateral = (side * RAIL_HALF_GAUGE + uh[0]) * offsets[i].scale;
                V3 q = add(p, mul(offsets[i].n, lateral));
                ring.push_back({q[0], p[1] + uh[1], q[2]});
            }
            rings.push_back(ring);
        }
        add_rail_strips(builder, points, rings);
        V3 t_start = horizontal_dir(points[0], points[1]);
        V3 t_end = horizontal_dir(points[points.size() - 2], points.back());
        if (capped_start) add_rail_cap(builder, rings[0], mul(t_start, -1.0));
        if (capped_end) add_rail_cap(builder, rings.back(), t_end);
    }
    add_track_collision(builder, points, offsets);
}

static void add_ballast_prism(Builder& builder, const std::vector<V3>& points_in, const std::function<bool(const V3&)>& keep) {
    std::vector<V3> points = densify(points_in, BALLAST_PIECE_LENGTH);
    std::vector<std::vector<V3>> runs;
    std::vector<V3> current;
    for (const V3& p : points) {
        if (keep(p)) current.push_back(p);
        else if (!current.empty()) { runs.push_back(current); current.clear(); }
    }
    if (!current.empty()) runs.push_back(current);
    for (const auto& run : runs) {
        if (run.size() < 2) continue;
        std::vector<Offset> offsets = miter_offsets(run);
        std::vector<std::array<V3, 4>> sections;
        for (size_t i = 0; i < run.size(); i++) {
            const V3& p = run[i];
            const V3& n = offsets[i].n;
            double scale = offsets[i].scale;
            double top_y = p[1] - RAIL_HEIGHT - BALLAST_TOP_BELOW_SLEEPER;
            double bottom_y = p[1] - RAIL_HEIGHT - BALLAST_BOTTOM_BELOW_SLEEPER;
            auto at = [&](double u, double y) { V3 q = add(p, mul(n, u * scale)); return V3{q[0], y, q[2]}; };
            sections.push_back({at(BALLAST_BOTTOM_HALF_WIDTH, bottom_y), at(BALLAST_TOP_HALF_WIDTH, top_y), at(-BALLAST_TOP_HALF_WIDTH, top_y),
                                at(-BALLAST_BOTTOM_HALF_WIDTH, bottom_y)});
        }
        for (size_t i = 0; i + 1 < run.size(); i++) {
            const auto& a = sections[i];
            const auto& b = sections[i + 1];
            D2 anchor{(run[i][0] + run[i + 1][0]) / 2, (run[i][2] + run[i + 1][2]) / 2};
            const V3& n = offsets[i].n;
            V3 outs[3] = {add(n, {0.0, 0.6, 0.0}), {0.0, 1.0, 0.0}, add(mul(n, -1.0), {0.0, 0.6, 0.0})};
            for (int k = 0; k < 3; k++) builder.quad(a[k], b[k], b[k + 1], a[k + 1], COLOR_BALLAST, anchor, outs[k]);
        }
        struct End { const std::array<V3, 4>* s; V3 p, q; };
        End ends[2] = {{&sections[0], run[0], run[1]}, {&sections.back(), run.back(), run[run.size() - 2]}};
        for (auto& e : ends) {
            V3 outward = horizontal_dir(e.q, e.p);
            builder.polygon(std::vector<V3>(e.s->begin(), e.s->end()), COLOR_BALLAST, {e.p[0], e.p[2]}, outward);
        }
    }
}

long long build_tile_v4(Builder& builder, const std::vector<std::string>& order, const std::unordered_map<std::string, V3>& pos,
                        const std::unordered_map<std::string, std::vector<std::string>>& links,
                        const std::unordered_map<std::string, double>& node_y,
                        const std::unordered_map<std::string, BorderCut>& border_cuts,
                        const std::function<bool(const V3&)>* ballast_keep, size_t* chain_count) {
    auto chains = build_chains<std::string>(order, pos, links);
    if (chain_count) *chain_count = chains.size();
    std::vector<std::vector<V3>> chains_points;
    for (auto& [chain, through] : chains) {
        (void)through;
        std::vector<V3> pts;
        for (const std::string& k : chain) {
            const V3& p = pos.at(k);
            pts.push_back({p[0], node_y.at(k) + RAIL_TOP_OFFSET, p[2]});
        }
        chains_points.push_back(pts);
        auto capped = [&](const std::string& k) { return links.at(k).size() == 1 && !border_cuts.count(k); };
        auto c0 = border_cuts.find(chain.front()), c1 = border_cuts.find(chain.back());
        build_rails(builder, densify(pts, railsg::RAIL_PIECE_LENGTH), capped(chain.front()), capped(chain.back()),
                    c0 == border_cuts.end() ? nullptr : &c0->second, c1 == border_cuts.end() ? nullptr : &c1->second);
        if (ballast_keep) add_ballast_prism(builder, pts, *ballast_keep);
    }
    Builder tb;
    double std_span[2] = {-SLEEPER_HALF_LENGTH, SLEEPER_HALF_LENGTH};
    concrete_sleeper(tb, {0.0, 0.0, 0.0}, {1.0, 0.0, 0.0}, {0.0, 0.0, 1.0}, std_span, 0.0);
    std::vector<Sleeper> sleepers = place_sleepers(chains_points);
    for (const Sleeper& s : sleepers) {
        if (s.is_standard()) add_standard_sleeper(builder, tb.polys, s);
        else concrete_sleeper(builder, s.center, s.axis_u, s.axis_t, s.span, s.top_y);
    }
    return (long long)sleepers.size();
}
