#pragma once
#include <string>
void step_verify(const std::string& rom, const std::string& work, const std::string& part);
void step_validate_mod(const std::string& mod);
void step_compare_xml(const std::string& mod, const std::string& rom);
