#include "swmesh.h"
#include <cstring>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <dirent.h>
#include <sys/stat.h>

std::string read_file(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) throw std::runtime_error("cannot open " + path);
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

std::string read_text_universal(const std::string& path) {
    std::string raw = read_file(path);
    std::string out;
    out.reserve(raw.size());
    for (size_t i = 0; i < raw.size(); i++) {
        char c = raw[i];
        if (c == '\r') {
            out += '\n';
            if (i + 1 < raw.size() && raw[i + 1] == '\n') i++;
        } else {
            out += c;
        }
    }
    return out;
}

void write_file(const std::string& path, const std::string& data) {
    std::ofstream f(path, std::ios::binary);
    if (!f) throw std::runtime_error("cannot write " + path);
    f.write(data.data(), data.size());
}

bool file_exists(const std::string& path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0;
}
bool dir_exists(const std::string& path) {
    struct stat st;
    return stat(path.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}
std::vector<std::string> list_dir(const std::string& path) {
    std::vector<std::string> out;
    DIR* d = opendir(path.c_str());
    if (!d) throw std::runtime_error("cannot list " + path);
    while (dirent* e = readdir(d)) {
        std::string n = e->d_name;
        if (n != "." && n != "..") out.push_back(n);
    }
    closedir(d);
    return out;
}
void make_dirs(const std::string& path) {
    std::string cur;
    for (size_t i = 0; i <= path.size(); i++) {
        if (i == path.size() || path[i] == '/') {
            if (!cur.empty()) mkdir(cur.c_str(), 0777);
        }
        if (i < path.size()) cur += path[i];
    }
}
std::string path_join(const std::string& a, const std::string& b) {
    if (a.empty()) return b;
    if (a.back() == '/') return a + b;
    return a + "/" + b;
}

template <class T> static T rd(const std::string& d, size_t off) {
    if (off + sizeof(T) > d.size()) throw std::runtime_error("truncated file");
    T v;
    std::memcpy(&v, d.data() + off, sizeof(T));
    return v;
}
template <class T> static void wr(std::string& out, T v) {
    out.append(reinterpret_cast<const char*>(&v), sizeof(T));
}

Mesh read_mesh_full(const std::string& path) {
    std::string data = read_file(path);
    if (data.compare(0, 4, "mesh") != 0) throw std::runtime_error("not a mesh file");
    uint16_t vcount = rd<uint16_t>(data, 8);
    size_t off = 14;
    Mesh mesh;
    mesh.vertices.resize(vcount);
    for (int i = 0; i < vcount; i++) {
        std::memcpy(&mesh.vertices[i], data.data() + off, 28);
        off += 28;
    }
    uint32_t icount = rd<uint32_t>(data, off);
    off += 4;
    mesh.indices.resize(icount);
    if (icount) std::memcpy(mesh.indices.data(), data.data() + off, 2 * (size_t)icount);
    off += 2 * (size_t)icount;
    uint16_t scount = rd<uint16_t>(data, off);
    off += 2;
    for (int i = 0; i < scount; i++) {
        Submesh sm;
        sm.index_start = rd<uint32_t>(data, off);
        sm.index_count = rd<uint32_t>(data, off + 4);
        sm.shader = rd<uint16_t>(data, off + 10);
        off += 12;
        for (int k = 0; k < 3; k++) sm.bounds_min[k] = rd<float>(data, off + 4 * k);
        for (int k = 0; k < 3; k++) sm.bounds_max[k] = rd<float>(data, off + 12 + 4 * k);
        off += 24;
        sm.unknown_u16 = rd<uint16_t>(data, off);
        uint16_t nlen = rd<uint16_t>(data, off + 2);
        off += 4;
        sm.name = data.substr(off, nlen);
        off += nlen;
        for (int k = 0; k < 3; k++) sm.scale[k] = rd<float>(data, off + 4 * k);
        off += 12;
        mesh.submeshes.push_back(sm);
    }
    mesh.trailer = data.substr(off);
    return mesh;
}

static_assert(sizeof(MeshVertex) == 28, "vertex layout");

std::string mesh_bytes(const Mesh& mesh) {
    if (mesh.vertices.size() >= 65536) throw std::runtime_error("too many vertices for one mesh");
    std::string out = "mesh";
    wr<uint16_t>(out, 7);
    wr<uint16_t>(out, 1);
    wr<uint16_t>(out, (uint16_t)mesh.vertices.size());
    wr<uint16_t>(out, 0x13);
    wr<uint16_t>(out, 0);
    out.append(reinterpret_cast<const char*>(mesh.vertices.data()), 28 * mesh.vertices.size());
    wr<uint32_t>(out, (uint32_t)mesh.indices.size());
    out.append(reinterpret_cast<const char*>(mesh.indices.data()), 2 * mesh.indices.size());
    wr<uint16_t>(out, (uint16_t)mesh.submeshes.size());
    for (const Submesh& sm : mesh.submeshes) {
        wr<uint32_t>(out, sm.index_start);
        wr<uint32_t>(out, sm.index_count);
        wr<uint16_t>(out, 0);
        wr<uint16_t>(out, sm.shader);
        for (float v : sm.bounds_min) wr<float>(out, v);
        for (float v : sm.bounds_max) wr<float>(out, v);
        wr<uint16_t>(out, sm.unknown_u16);
        wr<uint16_t>(out, (uint16_t)sm.name.size());
        out += sm.name;
        for (float v : sm.scale) wr<float>(out, v);
    }
    out += mesh.trailer;
    return out;
}

void write_mesh(const std::string& path, const Mesh& mesh) { write_file(path, mesh_bytes(mesh)); }

std::vector<std::vector<V3>> read_phys(const std::string& path) {
    std::string data = read_file(path);
    if (data.compare(0, 4, "phys") != 0) throw std::runtime_error("not a phys file");
    uint16_t parts_n = rd<uint16_t>(data, 6);
    size_t off = 8;
    std::vector<std::vector<V3>> parts;
    for (int p = 0; p < parts_n; p++) {
        uint16_t n = rd<uint16_t>(data, off);
        std::vector<V3> part(n);
        for (int i = 0; i < n; i++)
            for (int k = 0; k < 3; k++) part[i][k] = (double)rd<float>(data, off + 2 + 12 * i + 4 * k);
        parts.push_back(std::move(part));
        off += 2 + 12 * (size_t)n + 2;
    }
    return parts;
}

static const size_t PHYS_MAX_VERTICES_PER_PART = 65535 / 3 * 3;

void write_phys(const std::string& path, const std::vector<std::array<V3, 3>>& triangles) {
    std::vector<const V3*> flat;
    for (const auto& t : triangles) for (const V3& p : t) flat.push_back(&p);
    size_t parts = (flat.size() + PHYS_MAX_VERTICES_PER_PART - 1) / PHYS_MAX_VERTICES_PER_PART;
    std::string out = "phys";
    wr<uint16_t>(out, 2);
    wr<uint16_t>(out, (uint16_t)parts);
    for (size_t i = 0; i < flat.size(); i += PHYS_MAX_VERTICES_PER_PART) {
        size_t n = std::min(PHYS_MAX_VERTICES_PER_PART, flat.size() - i);
        wr<uint16_t>(out, (uint16_t)n);
        for (size_t k = i; k < i + n; k++)
            for (int c = 0; c < 3; c++) wr<float>(out, (float)(*flat[k])[c]);
        wr<uint16_t>(out, 0);
    }
    write_file(path, out);
}

Mat4 identity4() {
    Mat4 m{};
    for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) m[r][c] = r == c ? 1.0 : 0.0;
    return m;
}

static bool value_char(char c) { return is_digit(c) || c == '-' || c == '.' || c == 'e' || c == 'E' || c == '+'; }

// re.findall(r'(\d\d)="([-\d.eE+]+)"', text) -> dict (later keys overwrite) -> matrix
Mat4 parse_transform(std::string_view t) {
    Mat4 m = identity4();
    size_t i = 0, n = t.size();
    while (i + 4 < n || i + 4 == n) {
        if (i + 4 > n) break;
        if (is_digit(t[i]) && is_digit(t[i + 1]) && t[i + 2] == '=' && t[i + 3] == '"') {
            size_t j = i + 4;
            while (j < n && value_char(t[j])) j++;
            if (j > i + 4 && j < n && t[j] == '"') {
                std::string val(t.substr(i + 4, j - i - 4));
                m[t[i] - '0'][t[i + 1] - '0'] = std::stod(val);
                i = j + 1;
                continue;
            }
        }
        i++;
    }
    return m;
}

std::vector<std::pair<std::string, std::string>> find_attrs(std::string_view t) {
    std::vector<std::pair<std::string, std::string>> out;
    size_t i = 0, n = t.size();
    while (i < n) {
        if (is_word(t[i])) {
            size_t j = i;
            while (j < n && is_word(t[j])) j++;
            // (\w+)= : the greedy word run must be followed by ="
            if (j + 1 < n && t[j] == '=' && t[j + 1] == '"') {
                size_t k = j + 2;
                while (k < n && t[k] != '"') k++;
                if (k < n) {
                    out.emplace_back(std::string(t.substr(i, j - i)), std::string(t.substr(j + 2, k - j - 2)));
                    i = k + 1;
                    continue;
                }
            }
            // no match starting at i: the regex retries from i + 1, but every start inside the
            // same word run ends at the same j, so it fails the same way
            i = j;
            continue;
        }
        i++;
    }
    return out;
}

std::vector<std::pair<std::string, std::string>> attrs_dict(std::string_view t) {
    std::vector<std::pair<std::string, std::string>> out;
    for (auto& kv : find_attrs(t)) {
        bool found = false;
        for (auto& o : out) if (o.first == kv.first) { o.second = kv.second; found = true; break; }
        if (!found) out.push_back(kv);
    }
    return out;
}

const std::string* attr_get(const std::vector<std::pair<std::string, std::string>>& attrs, const std::string& key) {
    for (auto& kv : attrs) if (kv.first == key) return &kv.second;
    return nullptr;
}

std::vector<std::string> find_links(std::string_view t) {
    std::vector<std::string> out;
    static const std::string_view pre = "<link id=\"";
    size_t i = 0;
    while ((i = t.find(pre, i)) != std::string_view::npos) {
        size_t s = i + pre.size();
        size_t e = t.find('"', s);
        if (e != std::string_view::npos && e > s) {
            out.emplace_back(t.substr(s, e - s));
            i = e + 1;
        } else {
            i += 1;
        }
    }
    return out;
}

// pattern = r'<track id="([^"]+)"[^>]*>\s*<transform([^/]*)/>\s*(?:<links>(.*?)</links>|<links/>)'  (re.S)
Tracks parse_tracks(const std::string& text) {
    Tracks out;
    std::string_view t(text);
    static const std::string_view pre = "<track id=\"";
    size_t i = 0;
    while ((i = t.find(pre, i)) != std::string_view::npos) {
        size_t start = i;
        auto fail = [&]() { i = start + 1; };
        size_t s = i + pre.size();
        size_t e = t.find('"', s);
        if (e == std::string_view::npos || e == s) { fail(); continue; }
        std::string id(t.substr(s, e - s));
        size_t gt = t.find('>', e + 1);
        if (gt == std::string_view::npos) { fail(); continue; }
        size_t p = gt + 1;
        while (p < t.size() && is_space(t[p])) p++;
        if (t.substr(p, 10) != "<transform") { fail(); continue; }
        size_t q = p + 10;
        size_t slash = t.find('/', q);
        if (slash == std::string_view::npos || slash + 1 >= t.size() || t[slash + 1] != '>') { fail(); continue; }
        std::string_view transform = t.substr(q, slash - q);
        p = slash + 2;
        while (p < t.size() && is_space(t[p])) p++;
        std::string_view links_text;
        size_t end_pos;
        if (t.substr(p, 7) == "<links>") {
            size_t close = t.find("</links>", p + 7);
            if (close == std::string_view::npos) {
                if (t.substr(p, 8) == "<links/>") { links_text = {}; end_pos = p + 8; }
                else { fail(); continue; }
            } else {
                links_text = t.substr(p + 7, close - p - 7);
                end_pos = close + 8;
            }
        } else if (t.substr(p, 8) == "<links/>") {
            links_text = {};
            end_pos = p + 8;
        } else {
            fail();
            continue;
        }
        Mat4 m = parse_transform(transform);
        TrackNode node{{m[3][0], m[3][1], m[3][2]}, find_links(links_text)};
        auto it = out.nodes.find(id);
        if (it == out.nodes.end()) {
            out.order.push_back(id);
            out.nodes.emplace(id, std::move(node));
        } else {
            it->second = std::move(node);
        }
        i = end_pos;
    }
    return out;
}

Tracks read_tracks(const std::string& path) { return parse_tracks(read_text_universal(path)); }
