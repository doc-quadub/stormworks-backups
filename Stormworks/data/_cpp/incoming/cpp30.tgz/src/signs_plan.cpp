// signs.py: plan_signs (kilometre and picket posts, whistle signs before bridges); step "signs"
#include "signs_plan.h"
#include "scan.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <optional>

using D2 = std::array<double, 2>;

static const double PICKET_SPACING = 100.0;
static const double RIGHTMOST_SEARCH = 12.0;
static const double MIN_CLEARANCE = 2.6;
static const double LATERAL_OFFSETS[] = {3.1, 3.6, 4.2, 5.0, 5.7};
static const double GROUND_BELOW_RAIL = 4.0;
static const double GROUND_ABOVE_RAIL = 3.0;
static const double HEADROOM = 2.7;
static const double KM_SHIFT_MAX = 100.0;
static const double PICKET_SHIFT_MAX = 95.0;
static const double SHIFT_STEP = 5.0;
static const double MIN_POST_GAP = 6.0;
static const double LEFT_SEARCH = 25.0;
static const double GROUND_ABOVE_RAIL_POST = 1.5;
static const double EYE_HEIGHT = 3.0;
static const double SIGHT_STEP = 0.5;
static const double KM_POST_HEIGHT = 2.10;
static const double POST_SIDE = 0.16;
static double km_plate_width(int digits) { return digits <= 2 ? 0.30 : digits == 3 ? 0.36 : 0.45; }
static const double WHISTLE_PLATE_WIDTH = 0.35;
static const double WHISTLE_DISTANCE = 500.0;
static const double WHISTLE_FURTHER = 100.0;
static const double WHISTLE_NEARER = 250.0;
static const double BRIDGE_SAMPLE = 3.0;
static const double BRIDGE_MIN_LENGTH = 20.0;
static const double BRIDGE_MERGE = 9.0;
static const double BRIDGE_SIDE = 7.5;
static const double BRIDGE_AIR = 2.0;
static const double BRIDGE_ROW_GAP = 150.0;

// Python's "%s" % dict for the log line
static std::string stats_repr(const std::vector<std::pair<std::string, long long>>& s) {
    std::string out = "{";
    for (size_t i = 0; i < s.size(); i++) {
        if (i) out += ", ";
        out += "'" + s[i].first + "': " + std::to_string(s[i].second);
    }
    return out + "}";
}

bool is_bridge(Ground& ground, double x, double z, double rail_y, const D2& t) {
    std::vector<double> hs = ground.heights(x, z);
    std::stable_sort(hs.begin(), hs.end(), [](double a, double b) { return a > b; });
    std::vector<double> deck;
    for (double h : hs) if (rail_y - 1.5 <= h && h <= rail_y + 0.1) deck.push_back(h);
    if (deck.empty()) return false;
    double top = deck[0];
    for (double h : deck) if (h > top) top = h;
    std::vector<double> below;
    for (double h : hs) if (h < top - 0.05) below.push_back(h);
    double bottom;
    if (!below.empty() && top - below[0] <= 2.5) {
        bottom = below[0];
        below.erase(below.begin());
    } else {
        bottom = top;
    }
    if (!below.empty() && bottom - below[0] < BRIDGE_AIR) return false;
    D2 r = right_of(t);
    for (double side : {1.0, -1.0}) {
        std::vector<double> side_h = ground.heights(x + r[0] * side * BRIDGE_SIDE, z + r[1] * side * BRIDGE_SIDE);
        bool level = false;
        for (double h : side_h) if (top - 2.0 <= h && h <= top + 2.0) { level = true; break; }
        if (level) continue;
        if (below.empty() && !side_h.empty()) continue;
        return true;
    }
    return false;
}

struct Walker {
    Network& net;
    std::unordered_map<NKey, std::vector<NKey>> after, before;
    explicit Walker(Network& n) : net(n) {
        for (auto& e : net.lines) {
            after[e.first].push_back(e.second);
            before[e.second].push_back(e.first);
        }
    }
    V3 point_on(NKey a, NKey b, double f) const {
        const V3& pa = net.pos.at(a);
        const V3& pb = net.pos.at(b);
        return {pa[0] + (pb[0] - pa[0]) * f, pa[1] + (pb[1] - pa[1]) * f, pa[2] + (pb[2] - pa[2]) * f};
    }
    // (edge, fraction) `extra` metres further on along the line
    bool walk(NKey a, NKey b, double f, double extra, NEdge& e, double& g) const {
        while (true) {
            double length = std::max(1e-6, net.dist.at(b) - net.dist.at(a));
            double gg = f + extra / length;
            if (gg <= 1.0) { e = {a, b}; g = gg; return true; }
            extra -= (1.0 - f) * length;
            auto it = after.find(b);
            if (it == after.end() || it->second.empty()) return false;
            const V3& pa = net.pos.at(a);
            const V3& pb = net.pos.at(b);
            D2 ta = {pb[0] - pa[0], pb[2] - pa[2]};
            NKey nb = -1;
            double best = 0;
            for (NKey c : it->second) {
                const V3& pc = net.pos.at(c);
                double v = (ta[0] * (pc[0] - pb[0]) + ta[1] * (pc[2] - pb[2]))
                           / std::max(1e-6, py::hypot(pc[0] - pb[0], pc[2] - pb[2]));
                if (nb < 0 || v > best) { nb = c; best = v; }
            }
            a = b; b = nb; f = 0.0;
        }
    }
    bool tangent(NKey a, NKey b, D2& t) const {
        const V3& pa = net.pos.at(a);
        const V3& pb = net.pos.at(b);
        double tx = pb[0] - pa[0], tz = pb[2] - pa[2];
        double tl = py::hypot(tx, tz);
        if (tl > 1e-6) { t = {tx / tl, tz / tl}; return true; }
        return false;
    }
    bool walk_back(NKey a, NKey b, double f, double extra, NEdge& e, double& g) const {
        while (true) {
            double length = std::max(1e-6, net.dist.at(b) - net.dist.at(a));
            double gg = f - extra / length;
            if (gg >= 0.0) { e = {a, b}; g = gg; return true; }
            extra -= f * length;
            auto it = before.find(a);
            if (it == before.end() || it->second.empty()) return false;
            D2 ta;
            if (!tangent(a, b, ta)) throw std::runtime_error("walk_back: zero tangent");   // Python: None[0] fails
            const V3& pa = net.pos.at(a);
            NKey nb = -1;
            double best = 0;
            for (NKey c : it->second) {
                const V3& pc = net.pos.at(c);
                double v = (ta[0] * (pa[0] - pc[0]) + ta[1] * (pa[2] - pc[2]))
                           / std::max(1e-6, py::hypot(pa[0] - pc[0], pa[2] - pc[2]));
                if (nb < 0 || v > best) { nb = c; best = v; }
            }
            b = a; a = nb; f = 1.0;
        }
    }
};

struct SignOut {
    std::vector<std::string> tile_order;
    std::map<std::string, std::vector<Value>> by_tile;
    void add(const std::string& tile, Value v) {
        if (!by_tile.count(tile)) tile_order.push_back(tile);
        by_tile[tile].push_back(std::move(v));
    }
};

static void plan_whistle_signs(Network& net, Ground& ground, Walker& W, SignOut& signs,
                               std::vector<D2>& placed_posts,
                               const std::function<bool(const V3&, const D2&, double, double, double, V3&)>& spot,
                               const std::string& name) {
    // 1. deck samples along every line edge
    struct Flag { double f; bool on; V3 p; };
    std::vector<NEdge> per_edge_order;
    std::map<NEdge, std::vector<Flag>> per_edge;
    for (auto& e : net.lines) {
        D2 t;
        if (!W.tangent(e.first, e.second, t)) continue;
        double length = net.dist.at(e.second) - net.dist.at(e.first);
        long long n = std::max<long long>(1, (long long)std::ceil(length / BRIDGE_SAMPLE));
        std::vector<Flag> flags;
        for (long long k = 0; k <= n; k++) {
            double f = (double)k / (double)n;
            V3 p = W.point_on(e.first, e.second, f);
            flags.push_back({f, is_bridge(ground, p[0], p[2], p[1], t), p});
        }
        if (!per_edge.count(e)) per_edge_order.push_back(e);
        per_edge[e] = flags;
    }
    // 2. bridges
    std::vector<D2> deck_points;
    for (auto& e : per_edge_order)
        for (auto& fl : per_edge.at(e))
            if (fl.on) deck_points.push_back({fl.p[0], fl.p[2]});
    std::vector<size_t> parent(deck_points.size());
    for (size_t i = 0; i < parent.size(); i++) parent[i] = i;
    auto find = [&](size_t i) {
        while (parent[i] != i) { parent[i] = parent[parent[i]]; i = parent[i]; }
        return i;
    };
    std::map<std::pair<long long, long long>, std::vector<size_t>> cell;
    for (size_t i = 0; i < deck_points.size(); i++) {
        double x = deck_points[i][0], z = deck_points[i][1];
        long long cx = (long long)py::floordiv(x, BRIDGE_MERGE), cz = (long long)py::floordiv(z, BRIDGE_MERGE);
        for (long long gx = cx - 1; gx <= cx + 1; gx++)
            for (long long gz = cz - 1; gz <= cz + 1; gz++) {
                auto it = cell.find({gx, gz});
                if (it == cell.end()) continue;
                for (size_t j : it->second)
                    if (py::hypot(deck_points[j][0] - x, deck_points[j][1] - z) < BRIDGE_MERGE) {
                        size_t fi = find(i);
                        parent[fi] = find(j);
                    }
            }
        cell[{cx, cz}].push_back(i);
    }
    std::vector<size_t> group_order;
    std::map<size_t, std::vector<size_t>> groups;
    for (size_t i = 0; i < deck_points.size(); i++) {
        size_t r = find(i);
        if (!groups.count(r)) group_order.push_back(r);
        groups[r].push_back(i);
    }
    std::map<D2, int> bridge_of;
    int bridges = 0;
    for (size_t r : group_order) {
        const auto& members = groups.at(r);
        double xmax = deck_points[members[0]][0], xmin = xmax, zmax = deck_points[members[0]][1], zmin = zmax;
        for (size_t i : members) {
            xmax = std::max(xmax, deck_points[i][0]); xmin = std::min(xmin, deck_points[i][0]);
            zmax = std::max(zmax, deck_points[i][1]); zmin = std::min(zmin, deck_points[i][1]);
        }
        if (py::hypot(xmax - xmin, zmax - zmin) < BRIDGE_MIN_LENGTH) continue;
        for (size_t i : members) bridge_of[deck_points[i]] = bridges;
        bridges++;
    }
    // 3. approaches
    struct Approach { int bridge; NEdge edge; double f; double travel; };
    std::vector<Approach> approaches;
    for (auto& e : per_edge_order) {
        const auto& flags = per_edge.at(e);
        for (size_t i = 0; i + 1 < flags.size(); i++) {
            const Flag &f0 = flags[i], &f1 = flags[i + 1];
            if (f0.on == f1.on) continue;
            D2 key = f1.on ? D2{f1.p[0], f1.p[2]} : D2{f0.p[0], f0.p[2]};
            auto it = bridge_of.find(key);
            if (it == bridge_of.end()) continue;
            if (f1.on) approaches.push_back({it->second, e, f0.f, 1.0});
            else approaches.push_back({it->second, e, f1.f, -1.0});
        }
    }
    auto on_bridge_deck = [&](const NEdge& e, double g) {
        auto it = per_edge.find(e);
        if (it == per_edge.end() || it->second.empty()) return false;
        const auto& flags = it->second;
        const Flag& fl = flags[(size_t)py::round_int(g * (double)(flags.size() - 1))];
        return fl.on && bridge_of.count(D2{fl.p[0], fl.p[2]}) != 0;
    };
    std::stable_sort(approaches.begin(), approaches.end(), [](const Approach& x, const Approach& y) {
        if (x.bridge != y.bridge) return x.bridge < y.bridge;
        return x.travel < y.travel;
    });
    struct Placed { double x, z; D2 d; };
    std::vector<Placed> placed;
    long long c_whistle = 0, c_not_outer = 0, c_no_place = 0, c_short = 0, c_follows = 0;
    for (const Approach& ap : approaches) {
        NKey a = ap.edge.first, b = ap.edge.second;
        double f = ap.f, travel = ap.travel;
        auto step = [&](double extra, NEdge& e, double& g) {
            return travel > 0 ? W.walk_back(a, b, f, extra, e, g) : W.walk(a, b, f, extra, e, g);
        };
        bool follows = false;
        for (int extra = 5; extra <= (int)BRIDGE_ROW_GAP; extra += 5) {
            NEdge e; double g;
            if (!step((double)extra, e, g)) break;
            if (on_bridge_deck(e, g)) { follows = true; break; }
        }
        if (follows) { c_follows++; continue; }
        enum { NONE, NOT_OUTER, NO_PLACE, DUPLICATE, FOUND } site = NONE;
        V3 found_p{};
        NEdge found_e{};
        D2 found_d{};
        std::vector<double> extras;
        for (int d = 0; d <= (int)WHISTLE_FURTHER; d += 5) extras.push_back(WHISTLE_DISTANCE + d);
        for (int d = 5; d <= (int)WHISTLE_NEARER; d += 5) extras.push_back(WHISTLE_DISTANCE - d);
        for (double extra : extras) {
            NEdge e; double g;
            if (!step(extra, e, g)) continue;
            V3 q = W.point_on(e.first, e.second, g);
            D2 t;
            if (!W.tangent(e.first, e.second, t)) continue;
            D2 d = {t[0] * travel, t[1] * travel};
            D2 r = right_of(d);
            bool outer = true;
            for (int idx : net.line_index.near(q[0], q[2], RIGHTMOST_SEARCH)) {
                const auto& it = net.line_index.items[idx];
                if (it.info == e || it.info == NEdge{e.second, e.first}) continue;
                if (ray_hits_segment({q[0], q[2]}, r, RIGHTMOST_SEARCH, it.a, it.b)) { outer = false; break; }
            }
            if (!outer) { site = NOT_OUTER; break; }
            V3 fp;
            if (!spot(q, d, 1.0, 0.0, WHISTLE_PLATE_WIDTH / 2, fp)) {
                if (site == NONE) site = NO_PLACE;
                continue;
            }
            bool dup = false;
            for (const Placed& pl : placed)
                if (py::hypot(fp[0] - pl.x, fp[2] - pl.z) < 30.0 && pl.d[0] * d[0] + pl.d[1] * d[1] > 0.5) { dup = true; break; }
            if (dup) { site = DUPLICATE; break; }
            site = FOUND;
            found_p = fp; found_e = e; found_d = d;
            break;
        }
        if (site == NONE) { c_short++; continue; }
        if (site == NOT_OUTER) { c_not_outer++; continue; }
        if (site == NO_PLACE) { c_no_place++; continue; }
        if (site == DUPLICATE) continue;
        placed.push_back({found_p[0], found_p[2], found_d});
        placed_posts.push_back({found_p[0], found_p[2]});
        const std::string& tile = net.edge_tile.at(found_e);
        double ox, oz;
        tile_origin(tile, ox, oz);
        Value s = Value::dict();
        s["kind"] = Value("whistle");
        s["pos"] = vec3(found_p[0] - ox, found_p[1], found_p[2] - oz);
        s["dir"] = vec2(found_d[0], found_d[1]);
        signs.add(tile, s);
        c_whistle++;
    }
    std::cout << name << ": whistle signs: "
              << stats_repr({{"bridges", bridges}, {"whistle", c_whistle}, {"not_outer", c_not_outer},
                             {"no_place", c_no_place}, {"short", c_short}, {"follows_bridge", c_follows}}) << "\n";
}

static SignOut plan_network_signs(const std::string& rom, const std::vector<std::string>& tiles, const PrepareFn& prepare,
                                  const std::string& family, const std::string& name) {
    Network net = build_network(tiles, prepare, family);
    Walker W(net);
    Ground ground(rom, family);
    SignOut signs;
    std::vector<D2> placed_posts;
    long long c_cand = 0, c_not_outer = 0, c_no_place = 0, c_km = 0, c_picket = 0, c_left = 0, c_moved = 0;
    bool ignore_opposite = family == "arid_island";

    auto visible = [&](const V3& eye, const V3& target) {
        double dx = target[0] - eye[0], dy = target[1] - eye[1], dz = target[2] - eye[2];
        double length = py::hypot(dx, dz);
        long long steps = std::max<long long>(1, (long long)(length / SIGHT_STEP));
        for (long long i = 1; i < steps; i++) {
            double f = (double)i / (double)steps;
            double x = eye[0] + dx * f, y = eye[1] + dy * f, z = eye[2] + dz * f;
            std::vector<double> hs = ground.heights(x, z);
            if (!hs.empty() && *std::min_element(hs.begin(), hs.end()) > y) return false;
        }
        return true;
    };
    std::function<bool(const V3&, const D2&, double, double, double, V3&)> spot =
        [&](const V3& p, const D2& t, double side, double start, double half_width, V3& out) {
        D2 r = right_of(t);
        for (double offset : LATERAL_OFFSETS) {
            double lateral = start + offset + half_width;
            double x = p[0] + r[0] * side * lateral, z = p[2] + r[1] * side * lateral;
            bool clear = true;
            for (int idx : net.all_tracks.near(x, z, MIN_CLEARANCE + 2)) {
                const auto& it = net.all_tracks.items[idx];
                if (!(point_segment_distance({x, z}, it.a, it.b) >= MIN_CLEARANCE + half_width)) { clear = false; break; }
            }
            if (!clear) continue;
            std::vector<double> hs = ground.heights(x, z);
            bool any = false;
            double y = 0;
            for (double h : hs)
                if (p[1] - GROUND_BELOW_RAIL <= h && h <= p[1] + GROUND_ABOVE_RAIL) {
                    if (!any || h > y) y = h;
                    any = true;
                }
            if (!any) continue;
            if (y > p[1] + GROUND_ABOVE_RAIL_POST) continue;
            bool blocked = false;
            const double probes[5][2] = {{0, 0}, {half_width, 0}, {-half_width, 0}, {0, 0.2}, {0, -0.2}};
            for (auto& pr : probes) {
                double sx = x + r[0] * pr[0] + t[0] * pr[1];
                double sz = z + r[1] * pr[0] + t[1] * pr[1];
                double lo = 0, hi = 0;
                bool have = false;
                for (double h : ground.heights(sx, sz))
                    if (y - 1.0 < h && h < y + HEADROOM) {
                        if (!have) { lo = hi = h; have = true; }
                        else { lo = std::min(lo, h); hi = std::max(hi, h); }
                    }
                if (have && hi - lo > 0.3) { blocked = true; break; }
            }
            if (blocked) continue;
            bool near_post = false;
            for (const D2& pp : placed_posts) if (py::hypot(x - pp[0], z - pp[1]) < MIN_POST_GAP) { near_post = true; break; }
            if (near_post) continue;
            V3 eye = {p[0] - t[0] * 40.0, p[1] + EYE_HEIGHT, p[2] - t[1] * 40.0};
            if (!visible(eye, {x, y + KM_POST_HEIGHT, z})) continue;
            out = {x, y, z};
            return true;
        }
        return false;
    };
    auto bundle_width = [&](const V3& p, const D2& t, double side) {
        D2 r = right_of(t);
        D2 d = {r[0] * side, r[1] * side};
        double widest = 0.0, reach = LEFT_SEARCH;
        for (int idx : net.all_tracks.near(p[0], p[2], reach)) {
            const auto& it = net.all_tracks.items[idx];
            double s;
            if (ray_hits_segment({p[0], p[2]}, d, reach, it.a, it.b, &s) && s > 0.5) widest = std::max(widest, s);
        }
        return widest;
    };
    auto runs_opposite = [&](const NEdge& edge, const D2& t) {
        NKey u = edge.first, v = edge.second;
        if (!net.has_dist(u) || !net.has_dist(v)) return false;
        const V3& pu = net.pos.at(u);
        const V3& pv = net.pos.at(v);
        double gx = pv[0] - pu[0], gz = pv[2] - pu[2];
        if (net.dist.at(v) < net.dist.at(u)) { gx = -gx; gz = -gz; }
        double gl = py::hypot(gx, gz);
        return gl > 1e-6 && (gx * t[0] + gz * t[1]) / gl < -0.5;
    };

    for (const NEdge& e : net.lines) {
        NKey a = e.first, b = e.second;
        double da = net.dist.at(a), db = net.dist.at(b);
        long long first = (long long)std::floor(da / PICKET_SPACING) + 1;
        long long last = (long long)std::floor(db / PICKET_SPACING);
        if (db - da < 1e-6) continue;
        for (long long m = std::max<long long>(first, 1); m <= last; m++) {
            double mark = (double)m * PICKET_SPACING;
            c_cand++;
            double f = (mark - da) / (db - da);
            V3 p = W.point_on(a, b, f);
            const V3& pa = net.pos.at(a);
            const V3& pb = net.pos.at(b);
            double tx = pb[0] - pa[0], tz = pb[2] - pa[2];
            double tl = py::hypot(tx, tz);
            if (tl < 1e-6) continue;
            D2 t = {tx / tl, tz / tl};
            D2 r = right_of(t);
            bool outer = true;
            for (int idx : net.line_index.near(p[0], p[2], RIGHTMOST_SEARCH)) {
                const auto& it = net.line_index.items[idx];
                if (it.info == e) continue;
                if (ray_hits_segment({p[0], p[2]}, r, RIGHTMOST_SEARCH, it.a, it.b)) {
                    if (ignore_opposite && runs_opposite(it.info, t)) continue;
                    outer = false;
                    break;
                }
            }
            if (!outer) { c_not_outer++; continue; }
            bool km = py::mod(mark, 1000.0) < 1e-6;
            long long kilometre = py::round_int(py::floordiv(mark, 1000.0));
            long long behind, ahead;
            double half_width;
            if (km) {
                behind = kilometre; ahead = kilometre + 1;
                half_width = km_plate_width(std::min<int>(4, (int)std::to_string(ahead).size())) / 2;
            } else {
                long long picket = py::round_int((mark - (double)(kilometre * 1000)) / PICKET_SPACING);
                behind = picket; ahead = picket + 1;
                half_width = POST_SIDE / 2;
            }
            bool have = false;
            V3 found_p{};
            NEdge found_e{};
            D2 found_t{};
            double found_side = 1.0;
            double shift = 0.0;
            double limit = km ? KM_SHIFT_MAX : PICKET_SHIFT_MAX;
            while (shift <= limit + 1e-6) {
                NEdge qe; double g;
                if (!W.walk(a, b, f, shift, qe, g)) break;
                V3 q = W.point_on(qe.first, qe.second, g);
                const V3& qa = net.pos.at(qe.first);
                const V3& qb = net.pos.at(qe.second);
                double ql = py::hypot(qb[0] - qa[0], qb[2] - qa[2]);
                D2 tq = ql > 1e-6 ? D2{(qb[0] - qa[0]) / ql, (qb[2] - qa[2]) / ql} : t;
                V3 fp;
                bool ok = spot(q, tq, 1.0, 0.0, half_width, fp);
                double side = 1.0;
                if (!ok) {
                    ok = spot(q, tq, -1.0, bundle_width(q, tq, -1.0), half_width, fp);
                    side = -1.0;
                }
                if (ok) { have = true; found_p = fp; found_e = qe; found_t = tq; found_side = side; break; }
                shift += SHIFT_STEP;
            }
            if (!have) { c_no_place++; continue; }
            placed_posts.push_back({found_p[0], found_p[2]});
            c_left += found_side < 0;
            c_moved += shift > 0;
            const std::string& tile = net.edge_tile.at(found_e);
            double ox, oz;
            tile_origin(tile, ox, oz);
            Value s = Value::dict();
            s["kind"] = Value(km ? "km" : "picket");
            s["pos"] = vec3(found_p[0] - ox, found_p[1], found_p[2] - oz);
            s["dir"] = vec2(found_t[0], found_t[1]);
            s["behind"] = Value(behind);
            s["ahead"] = Value(ahead);
            s["distance"] = Value(mark);
            signs.add(tile, s);
            (km ? c_km : c_picket)++;
        }
    }
    std::cout << name << ": tiles " << net.mainland.size() << ", nodes " << net.order.size() << ", tile joins " << net.joins
              << ", reached " << net.dist.size() << ", line edges " << net.lines.size() << "; "
              << stats_repr({{"candidates", c_cand}, {"not_outer", c_not_outer}, {"no_place", c_no_place}, {"km", c_km},
                             {"picket", c_picket}, {"left", c_left}, {"moved", c_moved}}) << "\n";
    plan_whistle_signs(net, ground, W, signs, placed_posts, spot, name);
    return signs;
}

Value plan_signs(const std::string& rom, const std::vector<std::string>& tiles, const PrepareFn& prepare) {
    Value out = Value::dict();
    for (auto fam : std::vector<std::pair<std::string, std::string>>{{"mega_island", "Sawyer"}, {"arid_island", "Meier"}}) {
        SignOut part = plan_network_signs(rom, tiles, prepare, fam.first, fam.second);
        for (const std::string& tile : part.tile_order) {
            if (!out.has(tile)) out[tile] = Value::list();
            for (Value& v : part.by_tile.at(tile)) out[tile].append(v);
        }
    }
    return out;
}

void step_signs(const std::string& rom, const std::string& work) {
    Value scan = json::load(work + "/scan.json");
    std::vector<std::string> tiles;
    for (const Value& v : scan["tiles"].lst()) tiles.push_back(v.str());
    Value planned = plan_signs(rom, tiles, [&](const std::string& tile) { return prepare_graph(rom, tile, scan); });
    json::dump(planned, work + "/signs.json");
    std::cout << "done\n";
}
