#pragma once
#include "network.h"
Value plan_signs(const std::string& rom, const std::vector<std::string>& tiles, const PrepareFn& prepare);
void step_signs(const std::string& rom, const std::string& work);
bool is_bridge(Ground& ground, double x, double z, double rail_y, const std::array<double, 2>& t);
