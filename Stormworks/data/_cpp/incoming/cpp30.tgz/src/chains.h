// rails.build_chains: split a track graph into polylines (shared by the rails and the overhead line)
#pragma once
#include <algorithm>
#include <map>
#include <set>
#include <unordered_map>
#include <utility>
#include <vector>
#include "py.h"
#include "swmesh.h"

namespace rails_v {
inline V3 norm(const V3& a) {
    double d = a[0] * a[0] + a[1] * a[1] + a[2] * a[2];
    double length = std::sqrt(d);
    if (length > 1e-12) return {a[0] / length, a[1] / length, a[2] / length};
    return {0.0, 0.0, 0.0};
}
inline double dot(const V3& a, const V3& b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
inline V3 horizontal_dir(const V3& a, const V3& b) { return norm({b[0] - a[0], 0.0, b[2] - a[2]}); }
}  // namespace rails_v

// order: dict order of `nodes`; pos / links: nodes[k] = (pos, links)
template <class K, class PosMap, class LinkMap>
std::vector<std::pair<std::vector<K>, bool>> build_chains(const std::vector<K>& order, const PosMap& pos, const LinkMap& raw_links) {
    using namespace rails_v;
    std::map<K, std::vector<K>> links;                  // (lookup only; iteration follows `order`)
    for (const K& k : order) {
        std::vector<K> v;
        for (const K& o : raw_links.at(k)) {
            if (!pos.count(o) || o == k) continue;
            if (std::find(v.begin(), v.end(), o) == v.end()) v.push_back(o);   // dict.fromkeys
        }
        links[k] = v;
    }
    std::map<std::pair<K, K>, K> pair;
    for (const K& k : order) {
        const std::vector<K>& nbrs = links[k];
        const V3& p = pos.at(k);
        if (nbrs.size() == 2) {
            const K& a = nbrs[0];
            const K& b = nbrs[1];
            if (dot(horizontal_dir(p, pos.at(a)), horizontal_dir(p, pos.at(b))) < 0) {
                pair[{k, a}] = b;
                pair[{k, b}] = a;
            }
        } else if (nbrs.size() >= 3) {
            bool have = false;
            double best_s = 0;
            K ba{}, bb{};
            for (size_t i = 0; i < nbrs.size(); i++)
                for (size_t j = i + 1; j < nbrs.size(); j++) {
                    V3 da = horizontal_dir(p, pos.at(nbrs[i]));
                    V3 db = horizontal_dir(p, pos.at(nbrs[j]));
                    double straightness = -dot(da, db);
                    if (!have || straightness > best_s) { have = true; best_s = straightness; ba = nbrs[i]; bb = nbrs[j]; }
                }
            pair[{k, ba}] = bb;
            pair[{k, bb}] = ba;
        }
    }
    std::set<std::pair<K, K>> used_edges;
    auto edge = [](const K& a, const K& b) { return a < b ? std::make_pair(a, b) : std::make_pair(b, a); };
    std::vector<std::vector<K>> chains;
    auto walk = [&](const K& start, const K& first) {
        std::vector<K> chain{start, first};
        used_edges.insert(edge(start, first));
        K prev = start, cur = first;
        while (true) {
            auto it = pair.find({cur, prev});
            if (it == pair.end()) break;
            K nxt = it->second;
            auto e = edge(cur, nxt);
            if (used_edges.count(e)) break;
            used_edges.insert(e);
            chain.push_back(nxt);
            prev = cur;
            cur = nxt;
        }
        return chain;
    };
    for (const K& k : order)
        for (const K& o : links[k])
            if (!pair.count({k, o}) && !used_edges.count(edge(k, o))) chains.push_back(walk(k, o));
    for (const K& k : order)
        for (const K& o : links[k])
            if (!used_edges.count(edge(k, o))) chains.push_back(walk(k, o));

    auto length = [&](const std::vector<K>& c) {
        double s = 0.0;
        for (size_t i = 0; i + 1 < c.size(); i++) {
            const V3& a = pos.at(c[i]);
            const V3& b = pos.at(c[i + 1]);
            s += py::dist3(a[0], a[1], a[2], b[0], b[1], b[2]);
        }
        return s;
    };
    auto is_branch_end = [&](const K& e, const K& nb) { return links[e].size() >= 3 && !pair.count({e, nb}); };
    struct R { std::vector<K> c; bool through; double len; };
    std::vector<R> result;
    for (auto& c : chains) {
        bool branch = is_branch_end(c[0], c[1]) || is_branch_end(c.back(), c[c.size() - 2]);
        result.push_back({c, !branch, length(c)});
    }
    std::stable_sort(result.begin(), result.end(), [](const R& x, const R& y) {
        bool kx = !x.through, ky = !y.through;
        if (kx != ky) return kx < ky;
        return -x.len < -y.len;
    });
    std::vector<std::pair<std::vector<K>, bool>> out;
    for (auto& r : result) out.push_back({r.c, r.through});
    return out;
}
