// Port of catenary.py planning (plan_catenary and helpers) - same results as the Python reference
#include "catenary_plan.h"
#include <algorithm>
#include <cmath>
#include <functional>
#include <iostream>
#include <map>
#include <optional>
#include <set>
#include <sstream>
#include <unordered_map>
#include <unordered_set>
#include "chains.h"
#include "pyset.h"
#include "scan.h"

using D2 = std::array<double, 2>;
using namespace cat;
using py::pymax;
using py::pymin;

// ---------------------------------------------------------------- constants (catenary.py)
static const double POLE_CLEARANCE = 3.10;
static const double PORTAL_GAP = POLE_OFFSET + POLE_CLEARANCE;
static const double PORTAL_REACH = 30.0;
static const int PORTAL_ROUNDS = 6;
static const double PORTAL_SEARCH_STEP = 3.0;
static const double PORTAL_REUSE_AHEAD = 15.0;
static const double PORTAL_STRETCH = 1.2;
static const double PORTAL_POST_HIGH = 6.5;
static const double CROSS_CELL = 50.0;
static const double PORTAL_DUPLICATE = 15.0;
static const double COVER_LOW = 3.0, COVER_HIGH = 10.5, COVER_SAMPLE_STEP = 3.0, COVER_MARGIN = 3.0;
static const double MIN_RUN_LENGTH = 50.0;
static const double END_GAP = 6.0;
static const double SHARE_SHIFT = 8.0, SHARE_SHIFT_AT_END = 16.0;
static const double SHARE_REACH[2] = {2.6, 6.3};
static const double SHARE_KEEP_SPAN = 10.0;
static const double SHARE_MIN_TRACK_GAP = 2.0;
static const double JUNCTION_DROP = 15.0;
static const double ANCHOR_POLE_SHIFTS[7] = {-6.0, -9.0, -12.0, -4.0, 6.0, 9.0, 12.0};
static const double POLE_SPACING = 2.5;
static const double ANCHOR_POLE_OUTSET = 0.8;
static const double GUY_POLE_CLEARANCE = 1.5;
static const double FEEDER_OUTER_CHECK = 15.0;
static const double FEEDER_MAX_SPAN = 80.0;
static const double FEEDER_SIDE_PENALTY = 4.0;
static const double FEEDER_TRACK_CLEARANCE = 2.5;
static const double FEEDER_GROUND_CLEARANCE = 1.5;
static const double FEEDER_SAG_70M = 1.40;
static const double OVERLAP_FIRST_SPAN = 20.0;
static const double OVERLAP_MAX_REACH = 160.0;
static const double FALLBACK_ANCHOR_REACH[2] = {12.0, 90.0};
static const char* SIGNAL_PLAYLIST = "data/missions/default_railroad_signals/playlist.xml";
static const double SIGNAL_CLEARANCE = 1.6;
static const double SIGNAL_SHADOW_ALONG = 25.0;
static const double SIGNAL_SHADOW_SIDE = 1.2;
static const double GUY_DISTANCES[4] = {7.0, 6.0, 5.0, 4.0};
static const double GUY_TURNS[9] = {0.0, 0.35, 0.7, 1.05, 1.4, -0.35, -0.7, -1.05, 1.75};
static const double GUY_CLEARANCE = 2.6;
static const double GUY_KEPT_TURN = 0.75;
static const double BRANCH_POLE_CLEARANCE = 0.8;
static const double MAST_REACHES[5] = {2.20, 2.00, 2.40, 1.80, 2.60};
static const double MAST_MIN_GAP = 1.0;
static const double MAST_TRACK_CLEARANCE = 1.6;
static const double FOOTING_LOW = 3.0, FOOTING_HIGH = 3.0, FOOTING_HIGH_GOOD = 2.0;
static const int ROAD_COLOUR[3] = {45, 41, 45};
static const double ROAD_SAMPLES[6] = {-15.0, -10.0, -5.0, 5.0, 10.0, 15.0};
static const int ROAD_YARD_SAMPLES = 3;
static const double ROAD_KEEP_OUT[1][3] = {{-1808.0, -6744.0, 8.0}};
static const double FOOTING_LOW_FAR = 6.0;
static const double DECK_EDGE_SEARCH[5] = {3.0, 2.7, 2.4, 2.1, 1.8};
static const double DECK_LEVEL[2] = {-1.6, 0.3};
static const double BRIDGE_GAP = 4.0;
static const double BRIDGE_SIDE = 8.0;
static const double BRACKET_BEAM[2] = {0.50, 0.35};
static const double BRACKET_DROP = 1.80;
static const double BRACKET_DROP_DEFAULT = 1.00;
static const int TRUSS_COLOR[3] = {45, 34, 32};
static const double TRUSS_TOP[2] = {9.0, 14.0};
static const double TRUSS_WALL[2] = {2.0, 14.0};
static const double TRUSS_REACH = 12.0;
static const double TRUSS_STEP = 2.0;
static const double TRUSS_STRUT_SEARCH = 6.0;
static const double TRUSS_STRUT_HEIGHTS[2] = {8.8, 14.0};
static const double SECTION_MAX = 1600.0, SECTION_CURVED_CUT = 300.0, SECTION_CURVE_RADIUS = 1500.0, SECTION_SEARCH = 300.0;
static const double INSULATING_GAP = 0.55;
static const double STATION_TURNOUT_GAP = 400.0, STATION_LINE_BEYOND = 500.0;
static const double STATION_OVERLAP_RANGE[2] = {40.0, 350.0};
static const double STATION_OVERLAP_TARGET = 120.0;
static const double MIDDLE_ANCHOR_MIN = 500.0;
static const double OVERLAP_RAISE_PLAIN = 0.20, OVERLAP_RAISE_INSULATING = 0.50;
static const double OVERLAP_OFFSET = 0.20;
static const double SECOND_WIRE_RAISE = 0.20;
static const double TRAVERSE_HALF = 0.60;
static const double GARLAND_FIX_RADIUS = 600.0;
static const double SPRING_MIN_SPAN = 40.0, SPRING_MIN_RADIUS = 800.0;
static const double AIR_GAP_NEIGHBOUR = 7.0;
static const double TILE_HALF = 500.0;

// ---------------------------------------------------------------- shared geometry helpers
namespace cat {
double pole_radius_at(double sp_base_y, double y, double height) {
    double taper = sp_base_y + height * POLE_TAPER_FROM;
    double f = std::max(0.0, std::min(1.0, (y - taper) / (height * (1.0 - POLE_TAPER_FROM))));
    return POLE_RADIUS_GROUND * (1 - f) + POLE_RADIUS_TOP * f;
}
double pole_base_y(const Value& sp) {
    const Value* v = sp.dct().find("pole_base");
    if (v) return v->num();
    return sp.get("track")[1].num() - POLE_BASE_BELOW_RAIL;
}
bool portal_twin(const Value& portal) {
    Value poles = portal.get("poles");
    Value a = poles[0], b = poles[1];
    return py::hypot(b[0].num() - a[0].num(), b[2].num() - a[2].num()) > PORTAL_TWIN_SPAN;
}
std::pair<double, double> portal_head_half(const Value& portal) {
    double along = (portal_twin(portal) ? PORTAL_TWIN_OFFSET : 0.0) + PORTAL_HEAD_HALF + PORTAL_PLATE_MARGIN;
    return {along, PORTAL_HEAD_HALF + PORTAL_PLATE_MARGIN};
}
static bool is_truss(const Value& portal) {
    Value k = portal.get("kind");
    return k.type == Value::STR && k.str() == "truss";
}
std::pair<double, double> portal_beam_size(const Value& portal) {
    if (is_truss(portal)) {
        if (portal.get("strut").truthy()) return {TRUSS_CLAMP[1], TRUSS_CLAMP[2]};
        return {TRUSS_BEAM_SIZE[0], TRUSS_BEAM_SIZE[1]};
    }
    double height = portal_twin(portal) ? PORTAL_TWIN_TRUSS_HEIGHT : PORTAL_TRUSS_HEIGHT;
    return {2 * portal_head_half(portal).first, height};
}
double portal_beam_y(const Value& portal) {
    if (is_truss(portal)) {
        const Value* v = portal.dct().find("beam_y");
        if (v) return v->num();
        return portal.get("rail_y").num() + PORTAL_BEAM_HEIGHT;
    }
    return portal.get("rail_y").num() + PORTAL_BEAM_BOTTOM + portal_beam_size(portal).second / 2;
}
std::vector<V3> feeder_points(const Value& fp) {
    Value pos = fp.get("pos"), out = fp.get("out");
    double x = pos[0].num(), z = pos[1].num();
    double y = fp.get("bracket_y").num() - GARLAND_LENGTH - 0.05;
    std::vector<V3> points;
    for (double o : FEEDER_ARM) points.push_back({x + out[0].num() * o, y, z + out[1].num() * o});
    Value end = fp.get("end");
    if (end.truthy()) {
        double tw0 = end[0].num(), tw1 = end[1].num();
        y = fp.get("bracket_y").num() - 0.12;
        for (V3& p : points)
            p = {p[0] + tw0 * (ANCHOR_DISCS * DISC_PITCH + 0.25), y, p[2] + tw1 * (ANCHOR_DISCS * DISC_PITCH + 0.25)};
    }
    return points;
}
}  // namespace cat

// ---------------------------------------------------------------- small helpers
static inline bool none_at(const Value& d, const char* k) { const Value* v = d.dct().find(k); return !v || v->is_none(); }
static inline bool truthy_at(const Value& d, const char* k) { const Value* v = d.dct().find(k); return v && v->truthy(); }
static inline double num_at(const Value& d, const char* k) { return d.dct().find(k)->num(); }
static inline double num_at(const Value& d, const char* k, double dflt) { const Value* v = d.dct().find(k); return v ? v->num() : dflt; }
static inline long long int_at(const Value& d, const char* k) { return d.dct().find(k)->integer(); }
static inline bool eq_int(const Value& v, long long i) { return v.type == Value::INT && v.i == i; }
static inline bool eq_str(const Value& v, const char* s) { return v.type == Value::STR && *v.s == s; }
static inline bool get_eq_int(const Value& d, const char* k, long long i) { const Value* v = d.dct().find(k); return v && eq_int(*v, i); }
static inline bool get_eq_str(const Value& d, const char* k, const char* s) { const Value* v = d.dct().find(k); return v && eq_str(*v, s); }
static inline V3 v3(const Value& l) { return {l[0].num(), l[1].num(), l[2].num()}; }
static inline D2 d2(const Value& l) { return {l[0].num(), l[1].num()}; }
static inline Value list3(const V3& p) { return vec3(p[0], p[1], p[2]); }
static inline Value list2(const D2& p) { return vec2(p[0], p[1]); }
static inline D2 right_of2(const D2& t) { return {t[1], -t[0]}; }

static D2 unit2(double x, double z) {
    double length = py::hypot(x, z);
    if (length > 1e-9) return {x / length, z / length};
    return {1.0, 0.0};
}
static V3 lerp(const V3& a, const V3& b, double f) {
    return {a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f, a[2] + (b[2] - a[2]) * f};
}
static inline long long ifloor(double x) { return (long long)std::floor(x); }
static inline long long cellkey(long long x, long long z) { return x * 4000003LL + z; }
static std::string mega_tile(long long tx, long long tz) {
    return "mega_island_" + std::to_string(tx) + "_" + std::to_string(tz);
}

// polyline point and horizontal unit tangent at arc length s
static void polyline_at(const std::vector<V3>& pts, const std::vector<double>& cum, double s, V3& p, D2& t) {
    s = pymax(0.0, pymin(cum.back(), s));
    size_t lo = 0, hi = cum.size() - 1;
    while (hi - lo > 1) {
        size_t mid = (lo + hi) / 2;
        if (cum[mid] <= s) lo = mid; else hi = mid;
    }
    double seg = cum[hi] - cum[lo];
    double f = seg < 1e-9 ? 0.0 : (s - cum[lo]) / seg;
    const V3& a = pts[lo];
    const V3& b = pts[hi];
    double tx = b[0] - a[0], tz = b[2] - a[2];
    double tl = py::hypot(tx, tz);
    p = lerp(a, b, f);
    if (tl > 1e-9) t = {tx / tl, tz / tl}; else t = {1.0, 0.0};
}
static V3 polyline_point(const std::vector<V3>& pts, const std::vector<double>& cum, double s) {
    V3 p; D2 t;
    polyline_at(pts, cum, s, p, t);
    return p;
}
static double heading(const D2& t) { return py::atan2(t[1], t[0]); }
static double turn_of(const D2& t1, const D2& t2) {
    return py::mod(heading(t2) - heading(t1) + M_PI, 2 * M_PI) - M_PI;
}

// ---------------------------------------------------------------- roads
struct RoadMask {
    bool has_dir = false;
    std::string dir;
    struct Tri { double v[6]; };
    std::unordered_map<std::string, std::unordered_map<long long, std::vector<Tri>>> tiles;
    static constexpr double CELL = 8.0;
    std::unordered_map<long long, std::vector<Tri>>& load(const std::string& tile) {
        auto it = tiles.find(tile);
        if (it != tiles.end()) return it->second;
        auto& grid = tiles[tile];
        if (has_dir) {
            std::string path = dir + "/" + tile + ".json";
            if (file_exists(path)) {
                Value all = json::load(path);
                for (const Value& tri : all.lst()) {
                    Tri T;
                    for (int k = 0; k < 6; k++) T.v[k] = tri[k].num();
                    double xs[3] = {T.v[0], T.v[2], T.v[4]}, zs[3] = {T.v[1], T.v[3], T.v[5]};
                    double x0 = std::min({xs[0], xs[1], xs[2]}), x1 = std::max({xs[0], xs[1], xs[2]});
                    double z0 = std::min({zs[0], zs[1], zs[2]}), z1 = std::max({zs[0], zs[1], zs[2]});
                    for (long long ix = ifloor(x0 / CELL); ix <= ifloor(x1 / CELL); ix++)
                        for (long long iz = ifloor(z0 / CELL); iz <= ifloor(z1 / CELL); iz++)
                            grid[cellkey(ix, iz)].push_back(T);
                }
            }
        }
        return grid;
    }
    bool asphalt(double wx, double wz) {
        long long tx = ifloor((wx + 8000 + 500) / 1000);
        long long tz = ifloor((wz + 12000 + 500) / 1000);
        auto& grid = load(mega_tile(tx, tz));
        double x = wx - (double)(tx * 1000 - 8000), z = wz - (double)(tz * 1000 - 12000);
        auto it = grid.find(cellkey(ifloor(x / CELL), ifloor(z / CELL)));
        if (it == grid.end()) return false;
        for (const Tri& T : it->second) {
            double ax = T.v[0], az = T.v[1], bx = T.v[2], bz = T.v[3], cx = T.v[4], cz = T.v[5];
            double d = (bx - ax) * (cz - az) - (cx - ax) * (bz - az);
            if (std::fabs(d) < 1e-12) continue;
            double l1 = ((x - ax) * (cz - az) - (cx - ax) * (z - az)) / d;
            double l2 = ((bx - ax) * (z - az) - (x - ax) * (bz - az)) / d;
            if (l1 >= -1e-6 && l2 >= -1e-6 && l1 + l2 <= 1 + 1e-6) return true;
        }
        return false;
    }
};

Value extract_roads(const std::string& mesh_path) {
    Mesh mesh = read_mesh_full(mesh_path);
    const auto& v = mesh.vertices;
    const auto& idx = mesh.indices;
    Value out = Value::list();
    auto road = [&](const MeshVertex& q) { return q.r == ROAD_COLOUR[0] && q.g == ROAD_COLOUR[1] && q.b == ROAD_COLOUR[2]; };
    for (size_t i = 0; i + 2 < idx.size(); i += 3) {
        const MeshVertex& a = v[idx[i]];
        const MeshVertex& b = v[idx[i + 1]];
        const MeshVertex& c = v[idx[i + 2]];
        if (road(a) && road(b) && road(c))
            out.append(Value::list({Value(py::round_nd(a.x, 2)), Value(py::round_nd(a.z, 2)), Value(py::round_nd(b.x, 2)),
                                    Value(py::round_nd(b.z, 2)), Value(py::round_nd(c.x, 2)), Value(py::round_nd(c.z, 2))}));
    }
    return out;
}

static bool fullmatch_mega_mesh(const std::string& n) {      // mega_island_\d+_\d+\.mesh
    const std::string pre = "mega_island_";
    if (n.compare(0, pre.size(), pre) != 0) return false;
    size_t i = pre.size(), j = i;
    while (j < n.size() && is_digit(n[j])) j++;
    if (j == i || j >= n.size() || n[j] != '_') return false;
    size_t k = j + 1, m = k;
    while (m < n.size() && is_digit(n[m])) m++;
    if (m == k) return false;
    return n.substr(m) == ".mesh";
}

void step_roads(const std::string& rom, const std::string& work) {
    std::string out_dir = work + "/roads";
    make_dirs(out_dir);
    std::string mesh_dir = rom + "/meshes/mainland";
    std::vector<std::string> names;
    for (const std::string& n : list_dir(mesh_dir))
        if (fullmatch_mega_mesh(n)) names.push_back(n.substr(0, n.size() - 5));
    std::sort(names.begin(), names.end());
    for (const std::string& name : names) {
        std::string target = out_dir + "/" + name + ".json";
        if (file_exists(target)) continue;
        json::dump(extract_roads(mesh_dir + "/" + name + ".mesh"), target + ".tmp");
        std::rename((target + ".tmp").c_str(), target.c_str());
    }
    std::cout << "remaining 0\ndone" << std::endl;
}

// ---------------------------------------------------------------- trusses
struct Trusses {
    std::string rom;
    static constexpr double CELL = 10.0, TRI_CELL = 4.0;
    std::unordered_map<std::string, std::unordered_map<long long, std::vector<V3>>> tiles;
    std::unordered_map<long long, std::vector<std::array<V3, 3>>> triangles;     // global, as in Python
    explicit Trusses(const std::string& r) : rom(r) {}

    std::unordered_map<long long, std::vector<V3>>& load(const std::string& tile) {
        auto it = tiles.find(tile);
        if (it != tiles.end()) return it->second;
        std::unordered_map<long long, std::vector<V3>> grid;
        double ox, oz;
        bool origin = mainland_origin(tile, ox, oz);
        std::string path = rom + "/data/tiles/" + tile + ".xml";
        if (origin && file_exists(path)) {
            std::string text = read_text_universal(path);
            std::string_view t(text);
            // re.finditer(r"<mesh ([^>]*)>\s*<transform([^/]*)/>", text)
            static const std::string_view pre = "<mesh ";
            size_t i = 0;
            while ((i = t.find(pre, i)) != std::string_view::npos) {
                size_t start = i;
                size_t a0 = i + pre.size();
                size_t gt = t.find('>', a0);
                bool ok = false;
                if (gt != std::string_view::npos) {
                    size_t p = gt + 1;
                    while (p < t.size() && is_space(t[p])) p++;
                    if (t.substr(p, 10) == "<transform") {
                        size_t q = p + 10;
                        size_t slash = t.find('/', q);
                        if (slash != std::string_view::npos && slash + 1 < t.size() && t[slash + 1] == '>') {
                            ok = true;
                            i = slash + 2;
                            auto attrs = attrs_dict(t.substr(a0, gt - a0));
                            if (attr_get(attrs, "parent_id") || !attr_get(attrs, "file_name")) continue;
                            std::string mesh_path = rom + "/" + *attr_get(attrs, "file_name");
                            if (!file_exists(mesh_path)) continue;
                            Mat4 m = parse_transform(t.substr(q, slash - q));
                            Mesh mesh = read_mesh_full(mesh_path);
                            std::vector<char> has(mesh.vertices.size(), 0);
                            std::vector<V3> world(mesh.vertices.size());
                            for (size_t n = 0; n < mesh.vertices.size(); n++) {
                                const MeshVertex& v = mesh.vertices[n];
                                if (v.r != TRUSS_COLOR[0] || v.g != TRUSS_COLOR[1] || v.b != TRUSS_COLOR[2]) continue;
                                V3 w = transform_point({(double)v.x, (double)v.y, (double)v.z}, m);
                                w[0] = w[0] + ox;
                                w[2] = w[2] + oz;
                                world[n] = w;
                                has[n] = 1;
                                grid[cellkey(ifloor(w[0] / CELL), ifloor(w[2] / CELL))].push_back(w);
                            }
                            const auto& idx = mesh.indices;
                            for (size_t k = 0; k + 2 < idx.size(); k += 3) {
                                if (!(has[idx[k]] && has[idx[k + 1]] && has[idx[k + 2]])) continue;
                                std::array<V3, 3> tri{world[idx[k]], world[idx[k + 1]], world[idx[k + 2]]};
                                double x0 = std::min({tri[0][0], tri[1][0], tri[2][0]});
                                double x1 = std::max({tri[0][0], tri[1][0], tri[2][0]});
                                double z0 = std::min({tri[0][2], tri[1][2], tri[2][2]});
                                double z1 = std::max({tri[0][2], tri[1][2], tri[2][2]});
                                for (long long ix = ifloor(x0 / TRI_CELL); ix <= ifloor(x1 / TRI_CELL); ix++)
                                    for (long long iz = ifloor(z0 / TRI_CELL); iz <= ifloor(z1 / TRI_CELL); iz++)
                                        triangles[cellkey(ix, iz)].push_back(tri);
                            }
                        }
                    }
                }
                if (!ok) i = start + 1;
            }
        }
        return tiles[tile] = std::move(grid);
    }
    std::vector<V3> near(double x, double z, double radius) {
        std::vector<V3> found;
        for (long long cx = ifloor((x - radius) / CELL); cx <= ifloor((x + radius) / CELL); cx++)
            for (long long cz = ifloor((z - radius) / CELL); cz <= ifloor((z + radius) / CELL); cz++) {
                std::string tile = mega_tile(ifloor((cx * CELL + 5 + 8500) / 1000), ifloor((cz * CELL + 5 + 12500) / 1000));
                auto& g = load(tile);
                auto it = g.find(cellkey(cx, cz));
                if (it != g.end()) found.insert(found.end(), it->second.begin(), it->second.end());
            }
        return found;
    }
    std::vector<double> ray_up(double x, double z) {
        near(x, z, 1.0);
        std::vector<double> hits;
        auto it = triangles.find(cellkey(ifloor(x / TRI_CELL), ifloor(z / TRI_CELL)));
        if (it == triangles.end()) return hits;
        for (const auto& T : it->second) {
            const V3 &a = T[0], &b = T[1], &c = T[2];
            double d = (b[0] - a[0]) * (c[2] - a[2]) - (c[0] - a[0]) * (b[2] - a[2]);
            if (std::fabs(d) < 1e-12) continue;
            double l1 = ((x - a[0]) * (c[2] - a[2]) - (c[0] - a[0]) * (z - a[2])) / d;
            double l2 = ((b[0] - a[0]) * (z - a[2]) - (x - a[0]) * (b[2] - a[2])) / d;
            if (l1 < -1e-6 || l2 < -1e-6 || l1 + l2 > 1 + 1e-6) continue;
            hits.push_back(a[1] + l1 * (b[1] - a[1]) + l2 * (c[1] - a[1]));
        }
        return hits;
    }
    // (along, lateral, height above the rail)
    std::vector<V3> at(const V3& p, const D2& t, const D2& r, double along, const double heights[2]) {
        std::vector<V3> out;
        for (const V3& q : near(p[0], p[2], TRUSS_REACH + along)) {
            double dx = q[0] - p[0], dz = q[2] - p[2];
            double a = dx * t[0] + dz * t[1];
            double b = dx * r[0] + dz * r[1];
            double h = q[1] - p[1];
            if (std::fabs(a) <= along && std::fabs(b) <= TRUSS_REACH && heights[0] <= h && h <= heights[1]) out.push_back({a, b, h});
        }
        return out;
    }
};

struct Zone { double a, b; bool top = false; double c = 0, d = 0; };

static std::vector<Zone> truss_zones(Trusses& trusses, const std::vector<V3>& points, const std::vector<double>& cum,
                                     double first, double last) {
    std::vector<Zone> zones;
    int current = -1;
    double s = pymax(0.0, first - 20.0);
    double end = pymin(cum.back(), last + 20.0);
    while (s <= end) {
        V3 p; D2 t;
        polyline_at(points, cum, s, p, t);
        D2 r = right_of2(t);
        if (!trusses.at(p, t, r, 5.0, TRUSS_WALL).empty()) {
            if (current < 0 || s - zones[current].b > 20.0) {
                zones.push_back({s, s});
                current = (int)zones.size() - 1;
            }
            zones[current].b = s;
            if (!trusses.at(p, t, r, 5.0, TRUSS_TOP).empty()) {
                if (!zones[current].top) { zones[current].top = true; zones[current].c = s; }
                zones[current].d = s;
            }
        }
        s += TRUSS_STEP;
    }
    return zones;
}

static bool strut_hit(double h, double py1) { return TRUSS_STRUT_HEIGHTS[0] <= h - py1 && h - py1 <= TRUSS_STRUT_HEIGHTS[1]; }

static bool truss_strut(Trusses& trusses, const V3& p, const D2& t, double& mid_out, double& under_out) {
    std::vector<double> offsets{0.0};
    int k = 1;
    while (k * 0.5 <= TRUSS_STRUT_SEARCH) {
        offsets.push_back(k * 0.5);
        offsets.push_back(-k * 0.5);
        k++;
    }
    for (double a : offsets) {
        double x = p[0] + t[0] * a, z = p[2] + t[1] * a;
        std::vector<double> hits;
        for (double h : trusses.ray_up(x, z)) if (strut_hit(h, p[1])) hits.push_back(h);
        if (hits.empty()) continue;
        double lo = a, hi = a;
        auto overhead = [&](double o) {
            for (double h : trusses.ray_up(p[0] + t[0] * o, p[2] + t[1] * o)) if (strut_hit(h, p[1])) return true;
            return false;
        };
        while (hi - a < 2.0 && overhead(hi + 0.1)) hi += 0.1;
        while (a - lo < 2.0 && overhead(lo - 0.1)) lo -= 0.1;
        double mid = (lo + hi) / 2;
        x = p[0] + t[0] * mid;
        z = p[2] + t[1] * mid;
        std::vector<double> under;
        for (double h : trusses.ray_up(x, z)) if (strut_hit(h, p[1])) under.push_back(h);
        mid_out = mid;
        under_out = under.empty() ? *std::min_element(hits.begin(), hits.end()) : *std::min_element(under.begin(), under.end());
        return true;
    }
    return false;
}

struct Chord { double outer, low, high; };
static std::optional<Chord> truss_chord(Trusses& trusses, const V3& p, const D2& t, const D2& r, double side) {
    std::vector<std::pair<double, double>> top;
    for (const V3& q : trusses.at(p, t, r, 3.0, TRUSS_TOP)) if (q[1] * side > 1.0) top.push_back({q[1], q[2]});
    if (top.empty()) return std::nullopt;
    double outer = top[0].first * side;
    for (auto& bh : top) outer = pymax(outer, bh.first * side);
    std::vector<double> chord;
    for (auto& bh : top) if (bh.first * side > outer - 0.7) chord.push_back(bh.second);
    double low = p[1] + *std::min_element(chord.begin(), chord.end());
    double high = p[1] + *std::max_element(chord.begin(), chord.end());
    D2 rs{r[0] * side, r[1] * side};
    std::vector<double> hits;
    for (double a : {-1.0, -0.5, 0.0, 0.5, 1.0})
        for (double inset : {0.1, 0.2}) {
            double x = p[0] + t[0] * a + rs[0] * (outer - inset);
            double z = p[2] + t[1] * a + rs[1] * (outer - inset);
            for (double h : trusses.ray_up(x, z))
                if (p[1] + TRUSS_TOP[0] <= h && h <= p[1] + TRUSS_TOP[1]) hits.push_back(h);
        }
    if (!hits.empty()) {
        double mn = *std::min_element(hits.begin(), hits.end()), mx = *std::max_element(hits.begin(), hits.end());
        if (mx - mn > 0.2) { low = mn; high = mx; return Chord{outer, low, high}; }
    }
    if (high - low < 0.2) high = low + 0.5;
    return Chord{outer, low, high};
}

static Value make_truss_portal(Trusses& trusses, const V3& p, const D2& t, const D2& r) {
    double a, under;
    if (truss_strut(trusses, p, t, a, under)) {
        V3 q{p[0] + t[0] * a, p[1], p[2] + t[1] * a};
        std::optional<Chord> faces[2] = {truss_chord(trusses, q, t, r, 1.0), truss_chord(trusses, q, t, r, -1.0)};
        double reach[2] = {faces[0] ? faces[0]->outer : 4.0, faces[1] ? faces[1]->outer : 4.0};
        Value poles = Value::list({vec3(q[0] + r[0] * reach[0], q[1], q[2] + r[1] * reach[0]),
                                   vec3(q[0] - r[0] * reach[1], q[1], q[2] - r[1] * reach[1])});
        Value chords = Value::list();
        const double sides[2] = {1.0, -1.0};
        for (int k = 0; k < 2; k++)
            if (faces[k]) {
                const Chord& f = *faces[k];
                chords.append(Value::list({Value(q[0] + r[0] * sides[k] * f.outer), Value(q[2] + r[1] * sides[k] * f.outer),
                                           Value(f.low), Value(f.high)}));
            }
        Value d = Value::dict();
        d["poles"] = poles;
        d["rail_y"] = Value(p[1]);
        d["centre"] = vec3(q[0], q[1], q[2]);
        d["kind"] = Value("truss");
        d["strut"] = Value::Bool(true);
        d["strut_offset"] = Value(a);
        d["beam_y"] = Value(under - TRUSS_CLAMP[2] / 2);
        d["chords"] = chords;
        return d;
    }
    std::vector<V3> top = trusses.at(p, t, r, 8.0, TRUSS_TOP);
    if (top.size() < 2) return Value();
    double height = top[0][2], lo = top[0][1], hi = top[0][1];
    for (const V3& q : top) { height = pymin(height, q[2]); lo = pymin(lo, q[1]); hi = pymax(hi, q[1]); }
    if (hi < 1.0 || lo > -1.0) return Value();
    Value pa = vec3(p[0] + r[0] * hi, p[1], p[2] + r[1] * hi);
    Value pb = vec3(p[0] + r[0] * lo, p[1], p[2] + r[1] * lo);
    Value d = Value::dict();
    d["poles"] = Value::list({pa, pb});
    d["rail_y"] = Value(p[1]);
    d["centre"] = vec3((pa[0].num() + pb[0].num()) / 2, p[1], (pa[2].num() + pb[2].num()) / 2);
    d["kind"] = Value("truss");
    d["beam_y"] = Value(p[1] + height - TRUSS_BEAM_SIZE[1] / 2);
    return d;
}

static bool on_bridge(Ground& ground, const V3& point, const D2* t) {
    std::vector<double> heights = ground.heights(point[0], point[2]);
    bool any_deck = false;
    double top = 0;
    for (double h : heights)
        if (point[1] - 1.5 <= h && h <= point[1] + 0.5) { top = any_deck ? pymax(top, h) : h; any_deck = true; }
    if (!any_deck) return false;
    for (double h : heights) if (h < top - BRIDGE_GAP) return true;
    if (!t) return false;
    D2 r = right_of2(*t);
    for (int side : {1, -1}) {
        for (double h : ground.heights(point[0] + r[0] * side * BRIDGE_SIDE, point[2] + r[1] * side * BRIDGE_SIDE))
            if (point[1] - FOOTING_LOW_FAR <= h && h <= point[1] + FOOTING_HIGH) return false;
    }
    return true;
}

// ---------------------------------------------------------------- signals
struct CatNet {
    Network net;
    std::vector<D2> signals, facings;
    RoadMask roads;
};

// dict(re.findall(r'(\d\d)="([^"]*)"', text))
static std::map<std::string, std::string> digit_attrs(std::string_view s) {
    std::map<std::string, std::string> out;
    size_t i = 0;
    while (i + 3 < s.size()) {
        if (is_digit(s[i]) && is_digit(s[i + 1]) && s[i + 2] == '=' && s[i + 3] == '"') {
            size_t q = s.find('"', i + 4);
            if (q != std::string_view::npos) {
                out[std::string(s.substr(i, 2))] = std::string(s.substr(i + 4, q - i - 4));
                i = q + 1;
                continue;
            }
        }
        i++;
    }
    return out;
}
static double pyfloat(const std::map<std::string, std::string>& m, const char* k, double dflt) {
    auto it = m.find(k);
    if (it == m.end()) return dflt;
    return std::strtod(it->second.c_str(), nullptr);
}

static void load_signals(const std::string& rom, std::vector<D2>& found, std::vector<D2>& facings) {
    std::string path = rom + "/" + SIGNAL_PLAYLIST;
    if (!file_exists(path)) return;
    std::string text = read_text_universal(path);
    std::string_view t(text);
    static const std::string_view pre = "<l id=\"";
    size_t i = 0;
    while ((i = t.find(pre, i)) != std::string_view::npos) {
        size_t start = i;
        size_t j = i + pre.size(), d0 = j;
        while (j < t.size() && is_digit(t[j])) j++;
        bool ok = false;
        static const std::string_view mid = "\" tile=\"data/tiles/";
        if (j > d0 && t.substr(j, mid.size()) == mid) {
            size_t v0 = j + mid.size();
            size_t q = t.find('"', v0);
            if (q != std::string_view::npos && q - v0 >= 5 && t.substr(q - 4, 4) == ".xml") {
                size_t close = t.find("</l>", q + 1);
                if (close != std::string_view::npos) {
                    ok = true;
                    std::string tile(t.substr(v0, q - 4 - v0));
                    std::string_view loc = t.substr(start, close + 4 - start);
                    i = close + 4;
                    double ox, oz;
                    if (mainland_origin(tile, ox, oz)) {
                        static const std::string_view zp = "cargo_zone_import_cargo_type=\"railroad_signal";
                        size_t k = 0;
                        while ((k = loc.find(zp, k)) != std::string_view::npos) {
                            size_t zs = k;
                            size_t qq = loc.find('"', k + zp.size());
                            bool zok = false;
                            if (qq != std::string_view::npos) {
                                size_t from = qq + 1;
                                static const std::string_view st = "<spawn_transform";
                                size_t sp = from;
                                while ((sp = loc.find(st, sp)) != std::string_view::npos) {
                                    size_t a0 = sp + st.size();
                                    size_t slash = loc.find('/', a0);
                                    if (slash != std::string_view::npos && slash + 1 < loc.size() && loc[slash + 1] == '>') {
                                        auto values = digit_attrs(loc.substr(a0, slash - a0));
                                        found.push_back({pyfloat(values, "30", 0.0) + ox, pyfloat(values, "32", 0.0) + oz});
                                        facings.push_back(unit2(pyfloat(values, "20", 0.0), pyfloat(values, "22", 1.0)));
                                        k = slash + 2;
                                        zok = true;
                                        break;
                                    }
                                    sp++;
                                }
                            }
                            if (!zok) k = zs + 1;
                        }
                    }
                }
            }
        }
        if (!ok) i = start + 1;
    }
}

static bool near_signal(const CatNet& cn, const D2& a) {
    for (const D2& s : cn.signals)
        if (py::dist2(s[0], s[1], a[0], a[1]) < SIGNAL_CLEARANCE) return true;
    return false;
}
static bool near_signal_seg(const CatNet& cn, const D2& a, const D2& b) {
    for (const D2& s : cn.signals)
        if (point_segment_distance(s, a, b) < SIGNAL_CLEARANCE) return true;
    return false;
}
static bool shades_signal(const CatNet& cn, const D2& spot) {
    for (size_t i = 0; i < cn.signals.size() && i < cn.facings.size(); i++) {
        const D2& s = cn.signals[i];
        const D2& f = cn.facings[i];
        double dx = spot[0] - s[0], dz = spot[1] - s[1];
        if (std::fabs(dx) > SIGNAL_SHADOW_ALONG + 2 || std::fabs(dz) > SIGNAL_SHADOW_ALONG + 2) continue;
        double ahead = dx * f[0] + dz * f[1];
        double side = dx * -f[1] + dz * f[0];
        if (0.0 < ahead && ahead < SIGNAL_SHADOW_ALONG && std::fabs(side) < SIGNAL_SHADOW_SIDE) return true;
    }
    return false;
}
static bool on_road(CatNet& cn, double x, double z, const D2* t) {
    for (auto& k : ROAD_KEEP_OUT)
        if (py::hypot(x - k[0], z - k[1]) < k[2]) return true;
    if (!cn.roads.has_dir) return false;
    static const double probe[5][2] = {{0.0, 0.0}, {0.4, 0.0}, {-0.4, 0.0}, {0.0, 0.4}, {0.0, -0.4}};
    bool any = false;
    for (auto& d : probe) if (cn.roads.asphalt(x + d[0], z + d[1])) { any = true; break; }
    if (!any) return false;
    if (!t) return true;
    int n = 0;
    for (double d : ROAD_SAMPLES) if (cn.roads.asphalt(x + (*t)[0] * d, z + (*t)[1] * d)) n++;
    return n < ROAD_YARD_SAMPLES;
}

// ---------------------------------------------------------------- track queries
static std::vector<double> crossings_ray(CatNet& cn, const V3& p, const D2& d, double reach) {
    std::vector<double> hits;
    for (int i : cn.net.all_tracks.near(p[0], p[2], reach)) {
        const auto& it = cn.net.all_tracks.items[i];
        double s;
        if (ray_hits_segment({p[0], p[2]}, d, reach, it.a, it.b, &s) && s > 0.5) hits.push_back(s);
    }
    std::sort(hits.begin(), hits.end());
    return hits;
}
template <class Idx>
static bool crosses_track(const Idx& index, const D2& a, const D2& b) {
    double length = py::dist2(a[0], a[1], b[0], b[1]);
    if (length < 1e-6) return false;
    D2 d{(b[0] - a[0]) / length, (b[1] - a[1]) / length};
    D2 mid{(a[0] + b[0]) / 2, (a[1] + b[1]) / 2};
    for (int i : index.near(mid[0], mid[1], length / 2 + 1.0)) {
        const auto& it = index.items[i];
        if (ray_hits_segment(a, d, length, it.a, it.b)) return true;
    }
    return false;
}
static double track_distance(CatNet& cn, double x, double z, double radius = 10.0) {
    double best = 0;
    bool have = false;
    for (int i : cn.net.all_tracks.near(x, z, radius)) {
        const auto& it = cn.net.all_tracks.items[i];
        double d = point_segment_distance({x, z}, it.a, it.b);
        if (!have || d < best) { best = d; have = true; }
    }
    if (!have || radius < best) return radius;      // min([...] + [radius])
    return best;
}

// ---------------------------------------------------------------- spans along a chain
static void span_at(const std::vector<V3>& pts, const std::vector<double>& cum, double s, double& span, double& radius, double& turn) {
    V3 p; D2 ta, tb;
    polyline_at(pts, cum, s + 30.0, p, ta);
    polyline_at(pts, cum, s - 30.0, p, tb);
    turn = turn_of(tb, ta);
    radius = std::fabs(turn) > 1e-4 ? 60.0 / std::fabs(turn) : 1e9;
    span = pymin(MAX_SPAN, pymax(MIN_SPAN, std::sqrt(8.0 * radius * CURVE_SAG_ALLOWANCE)));
    if (radius < ZIGZAG_MIN_RADIUS)
        span = pymin(MAX_SPAN, pymax(CURVE_MIN_SPAN, std::sqrt(8.0 * radius * 2.0 * CURVE_OFFSET_MAX * 0.9)));
}
static double longest_span(const std::vector<V3>& pts, const std::vector<double>& cum, double s) {
    double best = 0;
    for (int f = 0; f < 8; f++) {
        double span, radius, turn;
        span_at(pts, cum, s + MAX_SPAN * f / 7.0, span, radius, turn);
        if (f == 0 || span < best) best = span;
    }
    return best;
}
static double polyline_sag(const std::vector<V3>& pts, const std::vector<double>& cum, double s0, double s1) {
    V3 pa = polyline_point(pts, cum, s0), pb = polyline_point(pts, cum, s1);
    D2 d = unit2(pb[0] - pa[0], pb[2] - pa[2]);
    double worst = 0.0;
    for (int k = 1; k < 8; k++) {
        V3 q = polyline_point(pts, cum, s0 + (s1 - s0) * k / 8.0);
        worst = pymax(worst, std::fabs((q[0] - pa[0]) * -d[1] + (q[2] - pa[2]) * d[0]));
    }
    return worst;
}

// ---------------------------------------------------------------- supports
struct Footing { double rank = 0; bool has_edge = false; double edge = 0; bool has_cut = false; double cut = 0; };
struct Item {
    double s = 0;
    V3 p{};
    D2 t{}, r{};
    double radius = 0, turn = 0;
    long long portal = -1;      // -1: None
    int side = 0;               // 0: None
    bool has_footing = false;
    Footing footing;
};

static void footing_of(Ground& ground, const V3& p, const D2& r, int side, double& rank, bool& has_edge, double& edge) {
    double rail_y = p[1];
    has_edge = false;
    std::vector<double> heights = ground.heights(p[0] + r[0] * side * POLE_OFFSET, p[2] + r[1] * side * POLE_OFFSET);
    bool any_near = false, any_above = false;
    double min_above = 0;
    for (double h : heights) {
        if (rail_y - FOOTING_LOW_FAR <= h && h <= rail_y + 15.0) any_near = true;
        if (h >= rail_y - FOOTING_LOW_FAR) { min_above = any_above ? pymin(min_above, h) : h; any_above = true; }
    }
    if (any_above && min_above > rail_y + FOOTING_HIGH_GOOD) { rank = 1.5; has_edge = true; edge = min_above - rail_y; return; }
    for (double h : heights) if (rail_y - FOOTING_LOW <= h && h <= rail_y + FOOTING_HIGH) { rank = 3; return; }
    if (any_near) { rank = 2; return; }
    for (double e : DECK_EDGE_SEARCH) {
        for (double h : ground.heights(p[0] + r[0] * side * e, p[2] + r[1] * side * e))
            if (rail_y + DECK_LEVEL[0] <= h && h <= rail_y + DECK_LEVEL[1]) { rank = 1; has_edge = true; edge = e; return; }
    }
    rank = 0;
}

static void pole_side(CatNet& cn, const V3& p, const D2& r, Ground& ground, int& side_out, Footing& footing_out) {
    bool have = false;
    double bk0 = 0, bk1 = 0, bk2 = 0;
    side_out = 0;
    for (int side : {1, -1}) {
        std::vector<double> hits = crossings_ray(cn, p, {r[0] * side, r[1] * side}, PORTAL_GAP + 1.0);
        double room = hits.empty() ? 99.0 : hits[0];
        D2 spot{p[0] + r[0] * side * POLE_OFFSET, p[2] + r[1] * side * POLE_OFFSET};
        D2 tt{-r[1], r[0]};
        if (near_signal(cn, spot) || shades_signal(cn, spot) || on_road(cn, spot[0], spot[1], &tt)) room = 0.0;
        if (room < PORTAL_GAP) continue;
        double rank = 0, edge = 0;
        bool has_edge = false;
        footing_of(ground, p, r, side, rank, has_edge, edge);
        if (rank == 0) continue;
        double k0, k1, k2;
        Footing f;
        f.rank = rank;
        if (rank == 1.5) {
            k0 = rank; k1 = -edge; k2 = room;
            f.has_edge = false; f.has_cut = true; f.cut = edge;
        } else {
            k0 = rank; k1 = 0.0; k2 = room;
            f.has_edge = has_edge; f.edge = edge;
        }
        bool greater = !have || (k0 > bk0 || (k0 == bk0 && (k1 > bk1 || (k1 == bk1 && k2 > bk2))));
        if (greater) {
            have = true; bk0 = k0; bk1 = k1; bk2 = k2;
            side_out = side;
            footing_out = f;
        }
    }
}

static Value make_portal(Ground& ground, CatNet& cn, const V3& p, const D2& r) {
    double ends[2];
    int n = 0;
    for (int side : {1, -1}) {
        D2 d{r[0] * side, r[1] * side};
        std::vector<double> hits{0.0};
        for (double h : crossings_ray(cn, p, d, PORTAL_REACH)) hits.push_back(h);
        bool have = false;
        double edge = 0;
        for (size_t k = 0; k < hits.size(); k++) {
            double a = hits[k];
            double b = k + 1 < hits.size() ? hits[k + 1] : PORTAL_REACH + PORTAL_GAP;
            if (b - a >= PORTAL_GAP) { edge = a; have = true; break; }
        }
        if (!have || edge > PORTAL_REACH - PORTAL_GAP) return Value();
        ends[n++] = edge + POLE_OFFSET;
    }
    double rail_y = p[1];
    Value poles = Value::list();
    const int sides[2] = {1, -1};
    for (int k = 0; k < 2; k++) {
        int side = sides[k];
        double out = ends[k];
        double x = p[0] + r[0] * side * out, z = p[2] + r[1] * side * out;
        bool have = false;
        double best = 0;
        for (double h : ground.heights(x, z))
            if (rail_y - 6.0 <= h && h <= rail_y + PORTAL_POST_HIGH) { best = have ? pymax(best, h) : h; have = true; }
        if (!have) return Value();
        D2 tt{-r[1], r[0]};
        if (shades_signal(cn, {x, z}) || on_road(cn, x, z, &tt)) return Value();
        poles.append(vec3(x, best, z));
    }
    Value d = Value::dict();
    d["poles"] = poles;
    d["rail_y"] = Value(rail_y);
    d["centre"] = vec3((poles[0][0].num() + poles[1][0].num()) / 2, rail_y, (poles[0][2].num() + poles[1][2].num()) / 2);
    return d;
}

static long long duplicate_portals(std::vector<Value>& portals) {
    long long dropped = 0;
    std::vector<Value> live;
    for (Value& p : portals) if (!truthy_at(p, "dead") && !get_eq_str(p, "kind", "truss")) live.push_back(p);
    for (size_t i = 0; i < live.size(); i++) {
        Value& a = live[i];
        if (truthy_at(a, "dead")) continue;
        for (size_t j = i + 1; j < live.size(); j++) {
            Value& b = live[j];
            if (truthy_at(b, "dead")) continue;
            Value ca = a.get("centre"), cb = b.get("centre");
            if (py::dist2(ca[0].num(), ca[2].num(), cb[0].num(), cb[2].num()) < PORTAL_DUPLICATE) {
                b["dead"] = Value::Bool(true);
                dropped++;
            }
        }
    }
    return dropped;
}

using Cells = std::unordered_map<long long, std::vector<int>>;
static std::optional<double> chain_crossing(const std::vector<V3>& points, const std::vector<double>& cum, const Value& portal, const Cells& cells) {
    Value poles = portal.get("poles");
    V3 a = v3(poles[0]), b = v3(poles[1]);
    std::set<int> found;
    for (long long cx = ifloor(std::min(a[0], b[0]) / CROSS_CELL); cx <= ifloor(std::max(a[0], b[0]) / CROSS_CELL); cx++)
        for (long long cz = ifloor(std::min(a[2], b[2]) / CROSS_CELL); cz <= ifloor(std::max(a[2], b[2]) / CROSS_CELL); cz++) {
            auto it = cells.find(cellkey(cx, cz));
            if (it != cells.end()) found.insert(it->second.begin(), it->second.end());
        }
    for (int i : found) {
        const V3& p = points[i];
        const V3& q = points[i + 1];
        D2 d{q[0] - p[0], q[2] - p[2]};
        double seg = py::hypot(d[0], d[1]);
        if (seg < 1e-9) continue;
        double hit;
        if (ray_hits_segment({p[0], p[2]}, {d[0] / seg, d[1] / seg}, seg + 1e-6, {a[0], a[2]}, {b[0], b[2]}, &hit))
            return cum[i] + hit;
    }
    return std::nullopt;
}

static std::vector<Item> space_supports(Ground& ground, CatNet& cn, const std::vector<V3>& points, const std::vector<double>& cum,
                                        double first, double last, std::vector<Value>& portals, Trusses* trusses,
                                        const std::vector<Zone>& zones) {
    Cells cells;
    for (size_t i = 0; i + 1 < points.size(); i++) {
        const V3& a = points[i];
        const V3& b = points[i + 1];
        for (long long cx = ifloor(std::min(a[0], b[0]) / CROSS_CELL); cx <= ifloor(std::max(a[0], b[0]) / CROSS_CELL); cx++)
            for (long long cz = ifloor(std::min(a[2], b[2]) / CROSS_CELL); cz <= ifloor(std::max(a[2], b[2]) / CROSS_CELL); cz++)
                cells[cellkey(cx, cz)].push_back((int)i);
    }
    size_t seen = 0;
    std::vector<std::pair<double, long long>> found_cross;
    auto crossings = [&]() {
        for (size_t k = seen; k < portals.size(); k++) {
            const Value& portal = portals[k];
            if (truthy_at(portal, "dead")) continue;
            auto c = chain_crossing(points, cum, portal, cells);
            if (c && first - 2.0 <= *c && *c <= last + 2.0) found_cross.push_back({*c, int_at(portal, "id")});
        }
        seen = portals.size();
        std::vector<std::pair<double, long long>> out = found_cross;
        std::sort(out.begin(), out.end());
        return out;
    };
    auto in_truss = [&](double s, double margin) {
        for (const Zone& z : zones) if (z.a - margin <= s && s <= z.b + margin) return true;
        return false;
    };
    auto under_truss_top = [&](double s) {
        for (const Zone& z : zones) if (z.top && z.c <= s && s <= z.d) return true;
        return false;
    };
    auto item_at = [&](double s, long long portal) {
        Item it;
        it.s = s;
        polyline_at(points, cum, s, it.p, it.t);
        double span;
        span_at(points, cum, s, span, it.radius, it.turn);
        it.r = right_of2(it.t);
        it.portal = portal;
        if (portal < 0 && !in_truss(s, 1.0)) {
            Footing f;
            pole_side(cn, it.p, it.r, ground, it.side, f);
            if (it.side != 0) { it.has_footing = true; it.footing = f; }
        }
        return it;
    };
    auto truss_item = [&](double s, std::optional<Item>& out) {
        V3 p; D2 t;
        polyline_at(points, cum, s, p, t);
        Value portal = make_truss_portal(*trusses, p, t, right_of2(t));
        if (portal.is_none()) return false;
        long long id = (long long)portals.size();
        portal["id"] = Value(id);
        portals.push_back(portal);
        out = item_at(pymin(last, s + num_at(portal, "strut_offset", 0.0)), id);
        return true;
    };
    auto settle = [&](double target, double lowest) -> std::optional<Item> {
        double s = target;
        std::optional<Item> cutting;
        while (s >= lowest - 1e-6) {
            if (trusses && under_truss_top(s)) {
                std::optional<Item> item;
                if (truss_item(s, item)) return item;
            }
            Item item = item_at(s, -1);
            if (item.side != 0) {
                if (item.footing.rank != 1.5) return item;
                if (!cutting || item.footing.cut < cutting->footing.cut) cutting = item;
            }
            s -= PORTAL_SEARCH_STEP;
        }
        std::vector<std::pair<double, long long>> near;
        for (auto& c : crossings()) if (lowest <= c.first && c.first <= target + PORTAL_DUPLICATE) near.push_back(c);
        if (!near.empty()) {
            size_t best = 0;
            for (size_t k = 1; k < near.size(); k++)
                if (std::fabs(near[k].first - target) < std::fabs(near[best].first - target)) best = k;
            return item_at(pymin(near[best].first, last), near[best].second);
        }
        s = target;
        while (s >= lowest - 1e-6) {
            if (in_truss(s, 4.0)) { s -= PORTAL_SEARCH_STEP; continue; }
            Item item = item_at(s, -1);
            Value portal = make_portal(ground, cn, item.p, item.r);
            if (!portal.is_none()) {
                long long id = (long long)portals.size();
                portal["id"] = Value(id);
                portals.push_back(portal);
                item.portal = id;
                return item;
            }
            s -= PORTAL_SEARCH_STEP;
        }
        return cutting;
    };

    std::vector<Item> items;
    auto under = crossings();
    std::vector<std::pair<double, long long>> start_cross;
    for (auto& c : under) if (c.first <= first + PORTAL_SEARCH_STEP) start_cross.push_back(c);
    Item item;
    if (!start_cross.empty()) {
        item = item_at(pymax(first, pymin(last, start_cross[0].first)), start_cross[0].second);
    } else {
        auto st = settle(first + PORTAL_SEARCH_STEP * 2, first);
        item = st ? *st : item_at(first, -1);
    }
    items.push_back(item);
    double s = item.s;
    while (s < last - 1.0) {
        double longest = longest_span(points, cum, s);
        long long pieces = std::max(1LL, (long long)std::ceil((last - s) / longest - 0.02));
        double target = s + (last - s) / pieces;
        while (target - s > CURVE_MIN_SPAN && polyline_sag(points, cum, s, target) > 2.0 * CURVE_OFFSET_MAX) target -= 2.0;
        double reach = pymin(s + longest * PORTAL_STRETCH, target + PORTAL_REUSE_AHEAD);
        std::vector<std::pair<double, long long>> ahead;
        for (auto& c : crossings()) if (s + 3.0 < c.first && c.first <= reach + 1e-6) ahead.push_back(c);
        if (!ahead.empty()) {
            item = item_at(pymin(ahead[0].first, last), ahead[0].second);
        } else {
            double lowest = s + (target - s >= MIN_SPAN * 0.5 ? MIN_SPAN * 0.5 : (target - s));
            auto st = settle(target, lowest);
            item = st ? *st : item_at(target, -1);
        }
        items.push_back(item);
        s = item.s;
    }
    return items;
}

static Value place_support(Ground& ground, const Item& item) {
    const V3& p = item.p;
    const D2& t = item.t;
    const D2& r = item.r;
    double rail_y = p[1];
    Value sp = Value::dict();
    sp["track"] = list3(p);
    sp["t"] = list2(t);
    sp["stagger"] = Value(0.0);
    sp["side"] = item.side ? Value((long long)item.side) : Value();
    sp["portal"] = item.portal >= 0 ? Value(item.portal) : Value();
    sp["radius"] = Value(item.radius);
    sp["turn"] = Value(item.turn);
    if (item.portal < 0) {
        int side = item.side;
        double pole_x = p[0] + r[0] * side * POLE_OFFSET;
        double pole_z = p[2] + r[1] * side * POLE_OFFSET;
        bool have = false;
        double best = 0;
        for (double h : ground.heights(pole_x, pole_z))
            if (rail_y - 6.0 <= h && h <= rail_y + 3.0) { best = have ? pymax(best, h) : h; have = true; }
        sp["pole"] = vec3(pole_x, have ? best : rail_y - 0.6, pole_z);
        sp["pole_base"] = Value(rail_y - POLE_BASE_BELOW_RAIL);
        sp["pole_owner"] = Value();
        if (item.has_footing && item.footing.has_edge) {
            double edge = item.footing.edge;
            sp["bracket"] = Value(edge);
            sp["pole"][1] = sp["pole_base"];
            double ex = p[0] + r[0] * side * (edge - 0.2);
            double ez = p[2] + r[1] * side * (edge - 0.2);
            std::vector<double> deck;
            for (double h : ground.heights(ex, ez)) if (rail_y - 4.0 <= h && h <= rail_y + 0.5) deck.push_back(h);
            std::stable_sort(deck.begin(), deck.end(), [](double a, double b) { return a > b; });
            bool has_bottom = false;
            double bottom = 0;
            for (size_t k = 1; k < deck.size(); k++)
                if (deck[0] - deck[k] > 0.4) { bottom = deck[k]; has_bottom = true; break; }
            double drop = has_bottom ? (num_at(sp, "pole_base") - bottom - 0.15) : BRACKET_DROP_DEFAULT;
            sp["bracket_drop"] = Value(pymax(BRACKET_BEAM[1] + 0.25, pymin(BRACKET_DROP, drop)));
        }
    }
    return sp;
}

// ---------------------------------------------------------------- the plan
struct ChainData {
    std::vector<NKey> chain;
    std::vector<V3> points;
    std::vector<double> cum;
    double first, last;
};

using Supports = std::vector<Value>;
using Runs = std::vector<std::vector<long long>>;

static std::string tile_of_point(double x, double z) {
    return mega_tile(ifloor((x + 8000 + 500) / 1000), ifloor((z + 12000 + 500) / 1000));
}
static double plan_distance(const Value& a, const Value& b) {
    Value ta = a.get("track"), tb = b.get("track");
    return py::dist2(ta[0].num(), ta[2].num(), tb[0].num(), tb[2].num());
}
static std::string chain_tile(const Network& net, const std::vector<NKey>& chain, const std::vector<double>& cum, double s) {
    for (size_t i = 0; i + 1 < cum.size(); i++)
        if (cum[i + 1] >= s) return net.edge_tile.at({chain[i], chain[i + 1]});
    return net.edge_tile.at({chain[chain.size() - 2], chain.back()});
}
static void closest_on_chain(const std::vector<V3>& points, const std::vector<double>& cum, double x, double z, double& s_out, double& d_out) {
    bool have = false;
    for (size_t i = 0; i + 1 < points.size(); i++) {
        const V3& a = points[i];
        const V3& b = points[i + 1];
        double dx = b[0] - a[0], dz = b[2] - a[2];
        double length2 = dx * dx + dz * dz;
        double f = length2 == 0 ? 0.0 : std::max(0.0, std::min(1.0, ((x - a[0]) * dx + (z - a[2]) * dz) / length2));
        double d = py::hypot(a[0] + dx * f - x, a[2] + dz * f - z);
        if (!have || d < d_out) {
            have = true;
            s_out = cum[i] + f * (cum[i + 1] - cum[i]);
            d_out = d;
        }
    }
}
static double side_sign(const Value& sp) {        // pole side (units of r): +1 / -1
    D2 r = right_of2(d2(sp.get("t")));
    Value pole = sp.get("pole"), track = sp.get("track");
    return ((pole[0].num() - track[0].num()) * r[0] + (pole[2].num() - track[2].num()) * r[1]) > 0 ? 1.0 : -1.0;
}

static long long share_poles(CatNet& cn, const std::vector<ChainData>& chain_data, const Runs& runs, Supports& supports) {
    std::map<std::pair<long long, long long>, std::vector<long long>> grid;
    std::unordered_map<long long, long long> users;
    long long moved = 0;
    for (const auto& indices : runs) {
        for (size_t position = 0; position < indices.size(); position++) {
            long long index = indices[position];
            Value sp = supports[index];
            if (!none_at(sp, "portal")) continue;
            const ChainData& cd = chain_data[int_at(sp, "run")];
            bool at_end = position == 0 || position == indices.size() - 1;
            double limit = at_end ? SHARE_SHIFT_AT_END : SHARE_SHIFT;
            double low = position > 0 ? num_at(supports[indices[position - 1]], "s") + SHARE_KEEP_SPAN : cd.first - END_GAP + 1.0;
            double high = position + 1 < indices.size() ? num_at(supports[indices[position + 1]], "s") - SHARE_KEEP_SPAN
                                                        : cd.last + END_GAP - 1.0;
            Value pole = sp.get("pole");
            double spx = pole[0].num(), spz = pole[2].num();
            long long cx = (long long)py::floordiv(spx, 20.0), cz = (long long)py::floordiv(spz, 20.0);
            bool have = false;
            double b_shift = 0, b_s = 0;
            long long b_owner = 0;
            V3 b_p{};
            D2 b_t{};
            bool b_rider = false;
            double sps = num_at(sp, "s");
            long long sprun = int_at(sp, "run");
            long long spside = int_at(sp, "side");
            for (long long gx = cx - 1; gx <= cx + 1; gx++)
                for (long long gz = cz - 1; gz <= cz + 1; gz++) {
                    auto it = grid.find({gx, gz});
                    if (it == grid.end()) continue;
                    for (long long owner : it->second) {
                        const Value& other = supports[owner];
                        auto u = users.find(owner);
                        if (int_at(other, "run") == sprun || (u != users.end() && u->second >= 1)) continue;
                        Value op = other.get("pole");
                        double px = op[0].num(), pz = op[2].num();
                        if (py::hypot(px - spx, pz - spz) > limit + 6.0) continue;
                        double s_new = 0, reach = 0;
                        closest_on_chain(cd.points, cd.cum, px, pz, s_new, reach);
                        if (!(SHARE_REACH[0] <= reach && reach <= SHARE_REACH[1])) continue;
                        if (std::fabs(s_new - sps) > limit || !(low <= s_new && s_new <= high)) continue;
                        V3 p; D2 t;
                        polyline_at(cd.points, cd.cum, s_new, p, t);
                        D2 r = right_of2(t);
                        double side = (px - p[0]) * r[0] + (pz - p[2]) * r[1];
                        if (side * spside <= 0) continue;
                        if (!crossings_ray(cn, p, unit2(px - p[0], pz - p[2]), reach - 0.5).empty()) continue;
                        Value ot = other.get("track");
                        bool rider = py::hypot(ot[0].num() - p[0], ot[2].num() - p[2]) < SHARE_MIN_TRACK_GAP;
                        if (!have || std::fabs(s_new - sps) < b_shift) {
                            have = true;
                            b_shift = std::fabs(s_new - sps);
                            b_owner = owner; b_s = s_new; b_p = p; b_t = t; b_rider = rider;
                        }
                    }
                }
            if (!have) {
                grid[{cx, cz}].push_back(index);
                continue;
            }
            users[b_owner] += 1;
            sp["rider"] = Value::Bool(b_rider);
            sp["s"] = Value(b_s);
            sp["track"] = list3(b_p);
            sp["t"] = list2(b_t);
            sp["pole"] = supports[b_owner].get("pole").copy();
            sp["pole_owner"] = Value(b_owner);
            sp["pole_base"] = supports[b_owner].get("pole_base");
            moved++;
        }
    }
    return moved;
}

static long long extend_over_turnouts(CatNet& cn, const std::vector<ChainData>& chain_data, Runs& runs, Supports& supports) {
    std::unordered_map<NKey, std::vector<std::pair<long long, double>>> passing;
    for (size_t run = 0; run < chain_data.size(); run++) {
        const ChainData& cd = chain_data[run];
        for (size_t i = 1; i + 1 < cd.chain.size(); i++)
            if (cd.first - END_GAP <= cd.cum[i] && cd.cum[i] <= cd.last + END_GAP) passing[cd.chain[i]].push_back({(long long)run, cd.cum[i]});
    }
    long long extended = 0;
    std::set<long long> used_middles;
    auto owner_of_any = [&](long long i) {
        for (const Value& o : supports) if (get_eq_int(o, "pole_owner", i)) return true;
        return false;
    };
    for (size_t run = 0; run < chain_data.size(); run++) {
        const ChainData& cd = chain_data[run];
        for (bool at_start : {true, false}) {
            std::vector<long long> indices = runs[run];
            if (indices.size() < 2) continue;
            NKey node;
            V3 before;
            if (at_start) {
                if (cd.first - END_GAP > 0.5) continue;
                node = cd.chain[0];
                before = cd.points[1];
            } else {
                if (cd.last + END_GAP < cd.cum.back() - 0.5) continue;
                node = cd.chain.back();
                before = cd.points[cd.points.size() - 2];
            }
            Value end_support = supports[at_start ? indices[0] : indices.back()];
            std::vector<std::pair<long long, double>> through;
            auto pit = passing.find(node);
            if (pit != passing.end())
                for (auto& rs : pit->second) if (rs.first != (long long)run) through.push_back(rs);
            if (through.empty()) continue;
            struct Plan { long long main_run; long long middle; long long anchor; double offset_side; };
            std::optional<Plan> plan, fallback;
            for (auto& [main_run, s_node] : through) {
                const ChainData& md = chain_data[main_run];
                V3 node_p; D2 t;
                polyline_at(md.points, md.cum, s_node, node_p, t);
                D2 into = unit2(node_p[0] - before[0], node_p[2] - before[2]);
                double ahead = into[0] * t[0] + into[1] * t[1] > 0 ? 1.0 : -1.0;
                D2 r = right_of2(t);
                double offset_side = (before[0] - node_p[0]) * r[0] + (before[2] - node_p[2]) * r[1] > 0 ? 1.0 : -1.0;
                const std::vector<long long>& main = runs[main_run];
                std::vector<long long> ordered;
                for (long long i : main)
                    if ((num_at(supports[i], "s") - s_node) * ahead > 0 && none_at(supports[i], "overlap_of")) ordered.push_back(i);
                std::stable_sort(ordered.begin(), ordered.end(), [&](long long x, long long y) {
                    return (num_at(supports[x], "s") - s_node) * ahead < (num_at(supports[y], "s") - s_node) * ahead;
                });
                if (!fallback) {
                    for (long long i : ordered) {
                        const Value& si = supports[i];
                        double reach = std::fabs(num_at(si, "s") - s_node);
                        if (none_at(si, "portal") && none_at(si, "bracket") && FALLBACK_ANCHOR_REACH[0] <= reach &&
                            reach <= FALLBACK_ANCHOR_REACH[1] && plan_distance(si, end_support) <= MAX_SPAN) {
                            fallback = Plan{main_run, -1, i, offset_side};
                            break;
                        }
                    }
                }
                std::vector<long long> beyond;
                for (long long i : ordered)
                    if (plan_distance(supports[i], end_support) >= OVERLAP_FIRST_SPAN) beyond.push_back(i);
                std::vector<long long> free;
                for (long long i : beyond)
                    if (!used_middles.count(i) && !owner_of_any(i)) free.push_back(i);
                if (free.size() < 2) continue;
                long long middle = free[0], anchor = free[1];
                if (plan_distance(supports[middle], end_support) > MAX_SPAN) continue;
                if (!none_at(supports[anchor], "portal") || !none_at(supports[anchor], "bracket") ||
                    !none_at(supports[middle], "bracket") || std::fabs(num_at(supports[anchor], "s") - s_node) > OVERLAP_MAX_REACH)
                    continue;
                plan = Plan{main_run, middle, anchor, offset_side};
                break;
            }
            if (!plan) plan = fallback;
            if (!plan) continue;
            if (plan->middle >= 0) used_middles.insert(plan->middle);
            std::vector<long long> added;
            std::vector<long long> sources;
            if (plan->middle >= 0) sources = {plan->middle, plan->anchor}; else sources = {plan->anchor};
            for (long long source : sources) {
                Value copy = supports[source].copy();
                copy["run"] = Value((long long)run);
                copy["overlap_of"] = Value(source);
                copy["overlap_side"] = Value(plan->offset_side);
                if (none_at(copy, "portal")) {
                    Value owner = supports[source].get("pole_owner");
                    copy["pole_owner"] = owner.is_none() ? Value(source) : owner;
                }
                copy.dct().erase("anchor");
                added.push_back((long long)supports.size());
                supports.push_back(copy);
            }
            long long end_index = at_start ? indices[0] : indices.back();
            double from_turnout = at_start ? num_at(end_support, "s") : cd.cum.back() - num_at(end_support, "s");
            const Value& neighbour = supports[at_start ? indices[1] : indices[indices.size() - 2]];
            double reach = plan_distance(neighbour, supports[added[0]]);
            if (plan->middle >= 0 && indices.size() > 2 && from_turnout <= JUNCTION_DROP && reach <= MAX_SPAN &&
                none_at(end_support, "portal") && !owner_of_any(end_index)) {
                end_support["dropped"] = Value::Bool(true);
                if (at_start) indices.erase(indices.begin()); else indices.pop_back();
            }
            std::vector<long long> nr;
            if (at_start) {
                nr.assign(added.rbegin(), added.rend());
                nr.insert(nr.end(), indices.begin(), indices.end());
            } else {
                nr = indices;
                nr.insert(nr.end(), added.begin(), added.end());
            }
            runs[run] = nr;
            extended++;
        }
    }
    return extended;
}

static bool leaves_mainland(const Network& net, const std::unordered_set<std::string>& net_tiles, NKey key) {
    auto it = net.links.find(key);
    if (it == net.links.end() || it->second.size() != 1) return false;
    const V3& p = net.pos.at(key);
    double ox, oz;
    mainland_origin(net.key_tile[key], ox, oz);
    if (std::max(std::fabs(p[0] - ox), std::fabs(p[2] - oz)) < TILE_HALF - 0.6) return false;
    std::string beyond = tile_of_point(p[0] + (p[0] - ox) * 0.01, p[2] + (p[2] - oz) * 0.01);
    return !net_tiles.count(beyond);
}

static long long trim_bridge_ends(Ground& ground, Runs& runs, Supports& supports, const std::vector<Value>& portals,
                                  const std::set<std::pair<long long, bool>>& edge_ends) {
    long long trimmed = 0;
    auto truss_portal = [&](const Value& sp) { return !none_at(sp, "portal") && get_eq_str(portals[int_at(sp, "portal")], "kind", "truss"); };
    auto off_land = [&](const Value& sp) {
        if (!none_at(sp, "portal")) return get_eq_str(portals[int_at(sp, "portal")], "kind", "truss");
        if (!none_at(sp, "bracket")) return true;
        D2 t = d2(sp.get("t"));
        return on_bridge(ground, v3(sp.get("track")), &t);
    };
    for (size_t k = 0; k < runs.size(); k++) {
        std::vector<long long> indices = runs[k];
        bool all = !indices.empty();
        for (long long i : indices) if (!off_land(supports[i])) { all = false; break; }
        if (all) {
            for (long long i : indices) supports[i]["dropped"] = Value::Bool(true);
            trimmed += (long long)indices.size();
            runs[k].clear();
            continue;
        }
        for (bool at_end : {true, false}) {
            bool to_land = edge_ends.count({(long long)k, at_end}) != 0;
            while (!indices.empty()) {
                long long i = at_end ? indices.back() : indices.front();
                const Value& sp = supports[i];
                bool off = to_land ? off_land(sp) : (!none_at(sp, "bracket") || truss_portal(sp));
                if (!off) break;
                supports[i]["dropped"] = Value::Bool(true);
                if (at_end) indices.pop_back(); else indices.erase(indices.begin());
                trimmed++;
            }
        }
        if (indices.size() < 2) {
            for (long long i : indices) supports[i]["dropped"] = Value::Bool(true);
            indices.clear();
        }
        runs[k] = indices;
    }
    return trimmed;
}

static void travel_directions(CatNet& cn, const Value& sp, bool& along, bool& against) {
    Value track = sp.get("track");
    D2 p{track[0].num(), track[2].num()};
    D2 r = right_of2(d2(sp.get("t")));
    bool found[2];
    const double sides[2] = {1.0, -1.0};
    for (int k = 0; k < 2; k++) {
        D2 d{r[0] * sides[k], r[1] * sides[k]};
        found[k] = false;
        for (int i : cn.net.all_tracks.near(p[0], p[1], AIR_GAP_NEIGHBOUR)) {
            const auto& it = cn.net.all_tracks.items[i];
            if (ray_hits_segment(p, d, AIR_GAP_NEIGHBOUR, it.a, it.b)) { found[k] = true; break; }
        }
    }
    if (found[1] && !found[0]) { along = true; against = false; return; }
    if (found[0] && !found[1]) { along = false; against = true; return; }
    along = against = true;
}

static void mark_air_gap(CatNet& cn, Supports& supports, long long low, long long high) {
    bool along, against;
    travel_directions(cn, supports[low], along, against);
    std::pair<long long, bool> list[2] = {{low, along}, {high, against}};
    for (auto& [i, first] : list) {
        Value& sp = supports[i];
        Value stripe;
        if (first) {
            D2 t = d2(sp.get("t"));
            D2 facing = i == low ? D2{-t[0], -t[1]} : D2{t[0], t[1]};
            Value track = sp.get("track"), pole = sp.get("pole");
            D2 to_track = unit2(track[0].num() - pole[0].num(), track[2].num() - pole[2].num());
            stripe = list2(unit2(facing[0] + 0.6 * to_track[0], facing[1] + 0.6 * to_track[1]));
        }
        Value z = Value::dict();
        z["stripe"] = stripe;
        sp["zebra"] = z;
    }
}

static std::pair<long long, long long> split_sections(Ground& ground, CatNet& cn, const std::vector<ChainData>& chain_data,
                                                      Runs& runs, Supports& supports) {
    long long plain_n = 0, insulating_n = 0;
    std::unordered_set<long long> sharers, sources;
    for (const Value& o : supports) {
        if (!none_at(o, "pole_owner") && !truthy_at(o, "dropped")) sharers.insert(int_at(o, "pole_owner"));
        if (!none_at(o, "overlap_of")) sources.insert(int_at(o, "overlap_of"));
    }
    auto eligible = [&](long long i) {
        const Value& sp = supports[i];
        if (!(none_at(sp, "portal") && !truthy_at(sp, "dropped") && none_at(sp, "bracket") && none_at(sp, "pole_owner") &&
              !sharers.count(i) && none_at(sp, "overlap_of") && !sources.count(i)))
            return false;
        D2 t = d2(sp.get("t"));
        return !on_bridge(ground, v3(sp.get("track")), &t);
    };
    using Fields = std::vector<std::pair<const char*, Value>>;
    auto copy_of = [&](long long src, const Fields& fields) {
        Value sp = supports[src].copy();
        sp.dct().erase("anchor");
        sp.dct().erase("dropped");
        double pole_side = side_sign(sp);
        sp["overlap_of"] = Value(src);
        sp["overlap_side"] = Value(-pole_side);
        sp["pole_owner"] = Value(src);
        for (auto& f : fields) sp[f.first] = f.second;
        supports.push_back(sp);
        return (long long)supports.size() - 1;
    };
    size_t nruns = runs.size();
    for (size_t run = 0; run < nruns; run++) {
        std::vector<long long> R = runs[run];
        if (R.size() < 10) continue;
        const ChainData& cd = chain_data[run];
        std::vector<long long> core;
        for (size_t q = 0; q < R.size(); q++) if (none_at(supports[R[q]], "overlap_of")) core.push_back((long long)q);
        if (core.size() < 10) continue;
        double s_lo = num_at(supports[R[core.front()]], "s"), s_hi = num_at(supports[R[core.back()]], "s");
        auto s_at = [&](long long q) { return num_at(supports[R[q]], "s"); };
        std::set<long long> taken;
        std::vector<std::pair<long long, long long>> cuts;
        auto place = [&](double target, long long n, double lo, double hi) {
            bool have = false;
            double bd = 0;
            long long bq = 0;
            for (long long q = 2; q < (long long)R.size() - n - 1; q++) {
                bool hit = false;
                for (long long p = q - 2; p < q + n + 2; p++) if (taken.count(p)) { hit = true; break; }
                if (hit) continue;
                bool all = true;
                for (long long p = q; p < q + n; p++) if (!eligible(R[p])) { all = false; break; }
                if (!all) continue;
                double mid = (s_at(q) + s_at(q + n - 1)) / 2;
                if (lo <= mid && mid <= hi && (!have || std::fabs(mid - target) < bd)) { have = true; bd = std::fabs(mid - target); bq = q; }
            }
            if (!have) return false;
            cuts.push_back({bq, n});
            for (long long p = bq; p < bq + n; p++) taken.insert(p);
            return true;
        };
        std::vector<double> turnouts;
        for (size_t i = 1; i + 1 < cd.chain.size(); i++) {
            auto it = cn.net.links.find(cd.chain[i]);
            if (it != cn.net.links.end() && it->second.size() >= 3) turnouts.push_back(cd.cum[i]);
        }
        struct St { double a, b; long long count; };
        std::vector<St> stations;
        for (double s : turnouts) {
            if (!stations.empty() && s - stations.back().b < STATION_TURNOUT_GAP) { stations.back().b = s; stations.back().count += 1; }
            else stations.push_back({s, s, 1});
        }
        for (const St& st : stations) {
            if (st.count < 2) continue;
            if (st.a - s_lo >= STATION_LINE_BEYOND)
                if (place(st.a - STATION_OVERLAP_TARGET, 5, st.a - STATION_OVERLAP_RANGE[1], st.a - STATION_OVERLAP_RANGE[0])) insulating_n++;
            if (s_hi - st.b >= STATION_LINE_BEYOND)
                if (place(st.b + STATION_OVERLAP_TARGET, 5, st.b + STATION_OVERLAP_RANGE[0], st.b + STATION_OVERLAP_RANGE[1])) insulating_n++;
        }
        std::vector<double> bounds{s_lo};
        for (auto& c : cuts) bounds.push_back((s_at(c.first) + s_at(c.first + c.second - 1)) / 2);
        bounds.push_back(s_hi);
        std::stable_sort(bounds.begin(), bounds.end());
        for (size_t k = 0; k + 1 < bounds.size(); k++) {
            double x0 = bounds[k], x1 = bounds[k + 1];
            long long n_inside = 0, n_curved = 0;
            for (long long i : R) {
                const Value& sp = supports[i];
                double s = num_at(sp, "s");
                if (x0 <= s && s <= x1 && none_at(sp, "overlap_of")) {
                    n_inside++;
                    if (num_at(sp, "radius", 1e9) < SECTION_CURVE_RADIUS) n_curved++;
                }
            }
            double curved = (double)n_curved / (double)std::max(1LL, n_inside);
            double limit = SECTION_MAX - SECTION_CURVED_CUT * curved;
            if (x1 - x0 <= limit) continue;
            long long pieces = (long long)std::ceil((x1 - x0) / limit);
            for (long long j = 1; j < pieces; j++) {
                double target = x0 + (x1 - x0) * j / pieces;
                if (place(target, 4, target - SECTION_SEARCH, target + SECTION_SEARCH)) plain_n++;
            }
        }
        if (cuts.empty()) continue;
        std::sort(cuts.begin(), cuts.end());
        std::vector<std::vector<long long>> sections;
        std::vector<long long> prefix;
        long long start = 0;
        for (auto& [q, n] : cuts) {
            std::vector<long long> ids;
            for (long long k = 0; k < n; k++) ids.push_back(R[q + k]);
            long long keep = n - 2;
            bool insulating = n == 5;
            if (insulating) mark_air_gap(cn, supports, ids[1], ids[3]);
            std::vector<long long> a_part = prefix;
            a_part.insert(a_part.end(), R.begin() + start, R.begin() + (q + keep));
            double raised = insulating ? OVERLAP_RAISE_INSULATING : OVERLAP_RAISE_PLAIN;
            a_part.push_back(copy_of(ids[n - 2], {{"insulate", Value::Bool(insulating)}, {"own_console", Value::Bool(true)},
                                                  {"overlap_raise", Value(raised)}}));
            a_part.push_back(copy_of(ids[n - 1], {{"section_anchor", Value::Bool(true)}}));
            sections.push_back(a_part);
            prefix.clear();
            prefix.push_back(copy_of(ids[0], {{"section_anchor", Value::Bool(true)}}));
            prefix.push_back(copy_of(ids[1], {{"insulate", Value::Bool(insulating)}, {"own_console", Value::Bool(true)},
                                              {"overlap_raise", Value(raised)}}));
            if (insulating)
                prefix.push_back(copy_of(ids[2], {{"insulating_mid", Value::Bool(true)}, {"overlap_gap", Value(INSULATING_GAP)},
                                                  {"overlap_raise", Value(0.0)}, {"own_console", Value::Bool(true)}}));
            start = q + keep;
        }
        std::vector<long long> last_part = prefix;
        last_part.insert(last_part.end(), R.begin() + start, R.end());
        sections.push_back(last_part);
        runs[run] = sections[0];
        for (size_t k = 1; k < sections.size(); k++) {
            long long new_run = (long long)runs.size();
            runs.push_back(sections[k]);
            for (long long i : sections[k]) supports[i]["run"] = Value(new_run);
        }
    }
    return {plain_n, insulating_n};
}

// ---------------------------------------------------------------- anchors
static std::vector<D2> pole_spots(const Supports& supports, const std::vector<Value>& portals) {
    std::vector<D2> spots;
    for (const Value& sp : supports)
        if (none_at(sp, "portal") && !truthy_at(sp, "dropped") && none_at(sp, "pole_owner")) {
            Value pole = sp.get("pole");
            spots.push_back({pole[0].num(), pole[2].num()});
        }
    for (const Value& portal : portals)
        for (const Value& p : portal.get("poles").lst()) spots.push_back({p[0].num(), p[2].num()});
    return spots;
}

struct Guy { bool good; double gx, gz; bool has_floor; double floor; };
static Guy find_guy(Ground& ground, CatNet& cn, const Value& sp, const V3& pole, const D2& towards, const std::vector<D2>& spots) {
    auto near_pole = [&](const D2& a, const D2& b) {
        for (const D2& s : spots) {
            double x = s[0], z = s[1];
            if (py::hypot(x - a[0], z - a[1]) < 0.3) continue;
            if (std::min(a[0], b[0]) - 2 < x && x < std::max(a[0], b[0]) + 2 && std::min(a[1], b[1]) - 2 < z &&
                z < std::max(a[1], b[1]) + 2 && point_segment_distance({x, z}, a, b) < GUY_POLE_CLEARANCE)
                return true;
        }
        return false;
    };
    Value track = sp.get("track");
    D2 out = unit2(pole[0] - track[0].num(), pole[2] - track[2].num());
    double rail_y = track[1].num();
    bool have = false;
    // score: (good, floor is not None, not crossing, not roofed, min(clearance, GUY_CLEARANCE), -distance)
    bool s0 = false, s1 = false, s2 = false, s3 = false;
    double s4 = 0, s5 = 0;
    Guy best{false, 0, 0, false, 0};
    for (double distance : GUY_DISTANCES) {
        for (double turn : GUY_TURNS) {
            double c = py::cos(turn), s = py::sin(turn);
            D2 back{-towards[0] * c + out[0] * s, -towards[1] * c + out[1] * s};
            double gx = pole[0] + back[0] * distance;
            double gz = pole[2] + back[1] * distance;
            std::vector<double> heights = ground.heights(gx, gz);
            bool has_floor = false;
            double floor = 0;
            for (double h : heights) if (rail_y - 8.0 <= h && h <= rail_y + 4.0) { floor = has_floor ? pymax(floor, h) : h; has_floor = true; }
            bool roofed = false;
            if (has_floor) for (double h : heights) if (floor + 1.0 < h && h < floor + 15.0) { roofed = true; break; }
            double clearance = track_distance(cn, gx, gz);
            bool crossing = crosses_track(cn.net.all_tracks, {pole[0], pole[2]}, {gx, gz}) || near_pole({pole[0], pole[2]}, {gx, gz});
            bool good = clearance >= GUY_CLEARANCE && !roofed && has_floor && !crossing &&
                        !near_signal_seg(cn, {pole[0], pole[2]}, {gx, gz}) && !on_road(cn, gx, gz, nullptr);
            bool k0 = good, k1 = has_floor, k2 = !crossing, k3 = !roofed;
            double k4 = pymin(clearance, GUY_CLEARANCE), k5 = -distance;
            bool greater;
            if (!have) greater = true;
            else if (k0 != s0) greater = k0 > s0;
            else if (k1 != s1) greater = k1 > s1;
            else if (k2 != s2) greater = k2 > s2;
            else if (k3 != s3) greater = k3 > s3;
            else if (k4 != s4) greater = k4 > s4;
            else greater = k5 > s5;
            if (greater) {
                have = true;
                s0 = k0; s1 = k1; s2 = k2; s3 = k3; s4 = k4; s5 = k5;
                best = Guy{good, gx, gz, has_floor, floor};
            }
            if (good) break;
        }
        if (s0) break;
    }
    best.good = s0;
    return best;
}

static bool branch_clear(const Value& start, const V3& pole, const std::vector<D2>& spots) {
    D2 a{start[0].num(), start[2].num()}, b{pole[0], pole[2]};
    for (const D2& s : spots) {
        double x = s[0], z = s[1];
        if (py::hypot(x - b[0], z - b[1]) < 0.3 || py::hypot(x - a[0], z - a[1]) < 4.0) continue;
        if (std::min(a[0], b[0]) - 2 < x && x < std::max(a[0], b[0]) + 2 && std::min(a[1], b[1]) - 2 < z &&
            z < std::max(a[1], b[1]) + 2 && point_segment_distance({x, z}, a, b) < BRANCH_POLE_CLEARANCE)
            return false;
    }
    return true;
}

static std::vector<long long> anchor_alternates(const Supports& supports, long long end, long long neighbour,
                                                const std::set<long long>& ends, const std::set<long long>& claimed) {
    V3 e = v3(supports[end].get("track")), n = v3(supports[neighbour].get("track"));
    D2 d = unit2(e[0] - n[0], e[2] - n[2]);
    double length = (e[0] - n[0]) * d[0] + (e[2] - n[2]) * d[1];
    V3 pole = v3(supports[end].get("pole"));
    double side = (pole[0] - e[0]) * -d[1] + (pole[2] - e[2]) * d[0];
    std::vector<std::pair<double, long long>> found;
    std::unordered_set<long long> carrying;
    for (const Value& x : supports)
        if (!none_at(x, "pole_owner") && !truthy_at(x, "dropped")) carrying.insert(int_at(x, "pole_owner"));
    for (long long i = 0; i < (long long)supports.size(); i++) {
        const Value& o = supports[i];
        if (i == end || i == neighbour || ends.count(i) || claimed.count(i) || truthy_at(o, "dropped") || !none_at(o, "portal") ||
            !none_at(o, "pole_owner") || !none_at(o, "anchor") || get_eq_str(o, "fixator", "overlap") || !none_at(o, "bracket") ||
            !truthy_at(o, "pole"))
            continue;
        if (carrying.count(i)) continue;
        V3 q = v3(o.get("pole"));
        double along = (q[0] - n[0]) * d[0] + (q[2] - n[2]) * d[1];
        double lateral = (q[0] - n[0]) * -d[1] + (q[2] - n[2]) * d[0];
        if (!(pymax(10.0, length - 15.0) <= along && along <= length + 0.5)) continue;
        if (lateral * side <= 0 || !(2.0 <= std::fabs(lateral) && std::fabs(lateral) <= 6.0)) continue;
        found.push_back({length - along, i});
    }
    std::sort(found.begin(), found.end());
    std::vector<long long> out;
    for (auto& f : found) out.push_back(f.second);
    return out;
}

static std::pair<long long, long long> anchor_poles(Ground& ground, CatNet& cn, const Runs& runs, Supports& supports,
                                                    const std::vector<Value>& portals) {
    long long moved = 0, kept = 0;
    std::set<long long> ends;
    for (const auto& indices : runs)
        if (indices.size() >= 2) { ends.insert(indices.front()); ends.insert(indices.back()); }
    auto users_of = [&](long long owner) {
        std::vector<long long> out;
        for (long long i = 0; i < (long long)supports.size(); i++)
            if (get_eq_int(supports[i], "pole_owner", owner) && !truthy_at(supports[i], "dropped")) out.push_back(i);
        return out;
    };
    std::set<long long> claimed;
    for (const auto& indices : runs) {
        if (indices.size() < 2) continue;
        std::pair<long long, long long> pairs[2] = {{indices[0], indices[1]}, {indices.back(), indices[indices.size() - 2]}};
        for (auto& [end, neighbour] : pairs) {
            Value sp = supports[end];
            if (!none_at(sp, "portal")) continue;
            std::vector<long long> sharers = users_of(end);
            if (none_at(sp, "pole_owner") && sharers.empty()) continue;
            long long owner, working;          // working -1: None
            std::vector<long long> others;
            if (!none_at(sp, "pole_owner")) {
                owner = working = int_at(sp, "pole_owner");
                for (long long i : users_of(owner)) if (i != end) others.push_back(i);
            } else {
                owner = end;
                working = sharers.size() == 1 ? sharers[0] : -1;
                others.assign(sharers.begin() + 1, sharers.end());
            }
            auto can_carry = [&](long long i, long long w) {
                if (w < 0) return false;
                const Value& h = supports[i];
                return !claimed.count(i) && none_at(h, "bracket") && !truthy_at(h, "dropped") && !ends.count(w) &&
                       !truthy_at(supports[w], "traverse") && none_at(supports[w], "overlap_of") && !truthy_at(supports[w], "own_console");
            };
            std::vector<std::pair<long long, long long>> options;
            if (others.empty() && can_carry(owner, working)) options.push_back({owner, working});
            if (!none_at(sp, "pole_owner") || sharers.empty())
                for (long long i : anchor_alternates(supports, end, neighbour, ends, claimed))
                    if (can_carry(i, i)) options.push_back({i, i});
            std::vector<D2> spots = pole_spots(supports, portals);
            bool done = false;
            for (auto& [carrier, carrier_working] : options) {
                V3 cpole = v3(supports[carrier].get("pole"));
                Value ntrack = supports[neighbour].get("track");
                D2 towards = unit2(ntrack[0].num() - cpole[0], ntrack[2].num() - cpole[2]);
                if (!branch_clear(ntrack, cpole, spots)) continue;
                Guy g = find_guy(ground, cn, sp, cpole, towards, spots);
                D2 back = unit2(g.gx - cpole[0], g.gz - cpole[2]);
                if (!g.good || -(back[0] * towards[0] + back[1] * towards[1]) < py::cos(GUY_KEPT_TURN)) continue;
                claimed.insert(carrier);
                sp["anchor_on_working"] = Value::Bool(true);
                if (carrier != owner) {
                    sp["pole_owner"] = Value(carrier);
                    sp["pole"] = supports[carrier].get("pole").copy();
                    sp["pole_base"] = supports[carrier].get("pole_base");
                } else if (carrier_working != end) {
                    supports[carrier_working]["rider"] = Value::Bool(false);
                }
                kept++;
                done = true;
                break;
            }
            if (done) continue;
            V3 track = v3(sp.get("track"));
            V3 other = v3(supports[neighbour].get("track"));
            D2 beyond = unit2(track[0] - other[0], track[2] - other[2]);
            V3 spole = v3(sp.get("pole"));
            D2 lateral{spole[0] - track[0], spole[2] - track[2]};
            spots = pole_spots(supports, portals);
            double reach = py::hypot(lateral[0], lateral[1]);
            double outset = reach > 1e-6 ? (reach + ANCHOR_POLE_OUTSET) / reach : 1.0;
            std::vector<std::pair<double, double>> opts;
            for (double shift : ANCHOR_POLE_SHIFTS) opts.push_back({shift, 1.0});
            for (double shift : ANCHOR_POLE_SHIFTS) opts.push_back({shift, -1.0});
            D2 st = d2(sp.get("t"));
            for (auto& [shift, mirror] : opts) {
                double widen = shift < 0 ? outset : 1.0;
                double x = track[0] + lateral[0] * mirror * widen + beyond[0] * shift;
                double z = track[2] + lateral[1] * mirror * widen + beyond[1] * shift;
                if (track_distance(cn, x, z) < POLE_CLEARANCE || near_signal(cn, {x, z}) || shades_signal(cn, {x, z}) ||
                    on_road(cn, x, z, &st))
                    continue;
                bool close = false;
                for (const D2& s : spots) if (py::hypot(x - s[0], z - s[1]) < POLE_SPACING) { close = true; break; }
                if (close) continue;
                double rail_y = track[1];
                bool have = false;
                double best = 0;
                for (double h : ground.heights(x, z))
                    if (rail_y - FOOTING_LOW <= h && h <= rail_y + FOOTING_HIGH) { best = have ? pymax(best, h) : h; have = true; }
                if (!have) continue;
                if (!sharers.empty()) {
                    long long new_owner = sharers[0];
                    supports[new_owner]["pole_owner"] = Value();
                    supports[new_owner]["rider"] = Value::Bool(false);
                    for (size_t k = 1; k < sharers.size(); k++) supports[sharers[k]]["pole_owner"] = Value(new_owner);
                }
                sp["pole"] = vec3(x, best, z);
                sp["pole_base"] = Value(rail_y - POLE_BASE_BELOW_RAIL);
                sp["pole_owner"] = Value();
                sp.dct().erase("bracket");
                moved++;
                break;
            }
        }
    }
    return {moved, kept};
}

static long long mark_anchors(Ground& ground, CatNet& cn, const Runs& runs, Supports& supports, const std::vector<Value>& portals) {
    long long count = 0;
    std::vector<D2> spots = pole_spots(supports, portals);
    for (const auto& indices : runs) {
        if (indices.size() < 2) continue;
        std::pair<long long, long long> pairs[2] = {{indices[0], indices[1]}, {indices.back(), indices[indices.size() - 2]}};
        for (auto& [end, neighbour] : pairs) {
            Value sp = supports[end];
            if (!none_at(sp, "portal")) continue;
            V3 pole = v3(sp.get("pole"));
            Value nt = supports[neighbour].get("track");
            D2 towards = unit2(nt[0].num() - pole[0], nt[2].num() - pole[2]);
            Guy g = find_guy(ground, cn, sp, pole, towards, spots);
            Value a = Value::dict();
            a["towards"] = list2(towards);
            a["guy_ground"] = vec3(g.gx, g.has_floor ? g.floor : sp.get("track")[1].num() - 0.8, g.gz);
            sp["anchor"] = a;
            count++;
        }
    }
    return count;
}

// ---------------------------------------------------------------- zigzag, fixators, fittings
static std::optional<double> chord_sag(const std::vector<ChainData>& chain_data, const Value& a, const Value& b) {
    Value ra = a.get("run"), rb = b.get("run");
    if (ra.is_none() || !(ra.type == rb.type && ra.integer() == rb.integer()) || ra.integer() >= (long long)chain_data.size() ||
        !a.has("s") || !b.has("s"))
        return std::nullopt;
    const ChainData& cd = chain_data[ra.integer()];
    V3 pa = v3(a.get("track")), pb = v3(b.get("track"));
    D2 d = unit2(pb[0] - pa[0], pb[2] - pa[2]);
    double worst = 0.0;
    double as = num_at(a, "s"), bs = num_at(b, "s");
    for (int k = 1; k < 8; k++) {
        V3 q = polyline_point(cd.points, cd.cum, as + (bs - as) * k / 8.0);
        worst = pymax(worst, std::fabs((q[0] - pa[0]) * -d[1] + (q[2] - pa[2]) * d[0]));
    }
    return worst;
}

static void assign_stagger(const Runs& runs, Supports& supports, const std::vector<ChainData>& chain_data) {
    for (const auto& indices : runs) {
        std::vector<long long> working;
        for (long long i : indices) if (none_at(supports[i], "anchor")) working.push_back(i);
        auto position_of = [&](long long index) {
            return (long long)(std::find(indices.begin(), indices.end(), index) - indices.begin());
        };
        for (size_t k = 0; k < working.size(); k++) {
            long long index = working[k];
            Value sp = supports[index];
            if (!none_at(sp, "overlap_of")) continue;
            D2 r = right_of2(d2(sp.get("t")));
            double pole_side = 0.0;
            if (none_at(sp, "portal")) pole_side = side_sign(sp);
            double radius = num_at(sp, "radius", 1e9);
            if (radius >= ZIGZAG_MIN_RADIUS) {
                const Value* seq = sp.dct().find("seq");
                long long sq = seq ? seq->integer() : (long long)k + 1;
                bool away = (((sq % 2) + 2) % 2) == 1;
                if (pole_side != 0.0) sp["stagger"] = Value((away ? -pole_side : pole_side) * STAGGER);
                else sp["stagger"] = Value(away ? STAGGER : -STAGGER);
                long long position = position_of(index);
                for (long long j : {position - 1, position + 1}) {
                    if (0 <= j && j < (long long)indices.size()) {
                        const Value& o = supports[indices[j]];
                        if (none_at(o, "anchor") && none_at(o, "overlap_of") && num_at(o, "radius", 1e9) < ZIGZAG_MIN_RADIUS) {
                            D2 ro = right_of2(d2(o.get("t")));
                            double outer_o = num_at(o, "turn", 0.0) > 0 ? 1.0 : -1.0;
                            double side = outer_o * (ro[0] * r[0] + ro[1] * r[1]);
                            sp["stagger"] = Value((side > 0 ? 1.0 : -1.0) * STAGGER);
                            break;
                        }
                    }
                }
            } else {
                std::vector<double> lengths, sags;
                long long position = position_of(index);
                Value st = sp.get("track");
                for (long long j : {position - 1, position + 1}) {
                    if (0 <= j && j < (long long)indices.size()) {
                        const Value& o = supports[indices[j]];
                        Value ot = o.get("track");
                        lengths.push_back(py::hypot(ot[0].num() - st[0].num(), ot[2].num() - st[2].num()));
                        auto sag = chord_sag(chain_data, sp, o);
                        if (sag) sags.push_back(*sag);
                    }
                }
                double span = lengths.empty() ? MAX_SPAN : py::sum(lengths) / (double)lengths.size();
                double outer = num_at(sp, "turn", 0.0) > 0 ? 1.0 : -1.0;
                double half;
                if (!sags.empty()) {
                    double m = sags[0];
                    for (double x : sags) m = pymax(m, x);
                    half = m / 2.0;
                } else {
                    half = span * span / (16.0 * radius);
                }
                sp["stagger"] = Value(outer * pymin(CURVE_OFFSET_MAX, half));
            }
            sp["fixator"] = Value(num_at(sp, "stagger") * pole_side > 0 ? "direct" : "reverse");
            if (truthy_at(sp, "rider")) {
                sp["fixator"] = Value("overlap");
                sp["raise"] = Value(SECOND_WIRE_RAISE);
            }
        }
        for (long long index : indices) {
            Value sp = supports[index];
            if (!none_at(sp, "overlap_of") && none_at(sp, "anchor")) {
                Value source = supports[int_at(sp, "overlap_of")];
                if (truthy_at(sp, "insulating_mid")) {
                    double pole_side = -num_at(sp, "overlap_side");
                    double centre = 0.0;
                    if (num_at(source, "radius", 1e9) < ZIGZAG_MIN_RADIUS)
                        centre = (num_at(source, "turn", 0.0) > 0 ? 1.0 : -1.0) * (0.40 - INSULATING_GAP / 2);
                    source["stagger"] = Value(centre + pole_side * INSULATING_GAP / 2);
                    source["fixator"] = Value("direct");
                }
                sp["stagger"] = Value(num_at(source, "stagger", 0.0) + num_at(sp, "overlap_gap", OVERLAP_OFFSET) * num_at(sp, "overlap_side"));
                sp["fixator"] = Value("overlap");
                sp["raise"] = Value(num_at(sp, "overlap_raise", SECOND_WIRE_RAISE));
                if (truthy_at(sp, "own_console") && none_at(sp, "portal")) {
                    double pole_side = side_sign(sp);
                    sp["fixator"] = Value(num_at(sp, "stagger") * pole_side > 0 ? "direct" : "reverse");
                    sp["console_shift"] = Value(TRAVERSE_HALF);
                    source["console_shift"] = Value(-TRAVERSE_HALF);
                    supports[int_at(sp, "pole_owner")]["traverse"] = Value::Bool(true);
                    if (truthy_at(sp, "insulate") || truthy_at(sp, "insulating_mid")) {
                        sp["garland_fix"] = Value::Bool(true);
                        source["garland_fix"] = Value::Bool(true);
                    }
                }
            } else if (none_at(sp, "anchor") && none_at(sp, "portal") &&
                       (get_eq_str(sp, "fixator", "direct") || get_eq_str(sp, "fixator", "reverse"))) {
                double pole_side = side_sign(sp);
                double outer = num_at(sp, "turn", 0.0) > 0 ? 1.0 : -1.0;
                if (num_at(sp, "radius", 1e9) <= GARLAND_FIX_RADIUS && pole_side == -outer) sp["garland_fix"] = Value::Bool(true);
            }
        }
    }
}

static long long middle_anchors(const Runs& runs, Supports& supports) {
    long long count = 0;
    for (const auto& indices : runs) {
        std::vector<long long> plain;
        for (long long i : indices) if (none_at(supports[i], "overlap_of") && none_at(supports[i], "anchor")) plain.push_back(i);
        if (plain.size() < 6) continue;
        double length = num_at(supports[plain.back()], "s") - num_at(supports[plain.front()], "s");
        if (std::fabs(length) < MIDDLE_ANCHOR_MIN) continue;
        double middle = (num_at(supports[plain.front()], "s") + num_at(supports[plain.back()], "s")) / 2;
        std::unordered_set<long long> plain_set(plain.begin(), plain.end());
        bool have = false;
        double bd = 0;
        long long bi = 0;
        for (size_t k = 1; k + 1 < indices.size(); k++) {
            long long i = indices[k];
            if (!(plain_set.count(i) && plain_set.count(indices[k - 1]) && plain_set.count(indices[k + 1]))) continue;
            if (truthy_at(supports[i], "rider") || truthy_at(supports[i], "traverse")) continue;
            double d = std::fabs(num_at(supports[i], "s") - middle);
            if (!have || d < bd) { have = true; bd = d; bi = i; }
        }
        if (have) {
            supports[bi]["middle_anchor"] = Value::Bool(true);
            count++;
        }
    }
    return count;
}

static long long assign_masts(CatNet& cn, Supports& supports, const std::vector<Value>& portals) {
    std::map<long long, std::vector<long long>> by_portal;
    for (long long i = 0; i < (long long)supports.size(); i++) {
        const Value& sp = supports[i];
        if (!none_at(sp, "portal") && !truthy_at(sp, "dropped") && none_at(sp, "overlap_of")) {
            if (!get_eq_str(portals[int_at(sp, "portal")], "kind", "truss")) by_portal[int_at(sp, "portal")].push_back(i);
        }
    }
    long long count = 0;
    for (auto& [pid, members_in] : by_portal) {
        Value poles = portals[pid].get("poles");
        V3 a = v3(poles[0]), b = v3(poles[1]);
        double span = py::hypot(b[0] - a[0], b[2] - a[2]);
        D2 across = unit2(b[0] - a[0], b[2] - a[2]);
        std::vector<D2> placed;
        std::vector<long long> members = members_in;
        std::stable_sort(members.begin(), members.end(), [&](long long x, long long y) { return num_at(supports[x], "s") < num_at(supports[y], "s"); });
        for (long long i : members) {
            Value sp = supports[i];
            V3 p = v3(sp.get("track"));
            double u = (p[0] - a[0]) * across[0] + (p[2] - a[2]) * across[1];
            double sides[2];
            if (u < span / 2) { sides[0] = -1.0; sides[1] = 1.0; } else { sides[0] = 1.0; sides[1] = -1.0; }
            bool done = false;
            for (double reach : MAST_REACHES) {
                for (double side : sides) {
                    double mx = p[0] + across[0] * side * reach, mz = p[2] + across[1] * side * reach;
                    double mu = (mx - a[0]) * across[0] + (mz - a[2]) * across[1];
                    if (!(0.6 <= mu && mu <= span - 0.6)) continue;
                    bool close = false;
                    for (const D2& q : placed) if (py::hypot(mx - q[0], mz - q[1]) < MAST_MIN_GAP) { close = true; break; }
                    if (close) continue;
                    if (track_distance(cn, mx, mz) < MAST_TRACK_CLEARANCE) continue;
                    sp["mast"] = vec2(mx, mz);
                    placed.push_back({mx, mz});
                    D2 r = right_of2(d2(sp.get("t")));
                    double mast_side = (mx - p[0]) * r[0] + (mz - p[2]) * r[1] > 0 ? 1.0 : -1.0;
                    if (!get_eq_str(sp, "fixator", "overlap"))
                        sp["fixator"] = Value(num_at(sp, "stagger") * mast_side > 0 ? "direct" : "reverse");
                    count++;
                    done = true;
                    break;
                }
                if (done) break;
            }
        }
    }
    return count;
}

static void traverse_shared_poles(Supports& supports) {
    std::vector<long long> order;
    std::unordered_map<long long, std::vector<long long>> consoles;
    for (long long i = 0; i < (long long)supports.size(); i++) {
        const Value& sp = supports[i];
        if (truthy_at(sp, "dropped") || !none_at(sp, "portal") || !none_at(sp, "anchor")) continue;
        if (get_eq_str(sp, "fixator", "overlap")) continue;
        long long owner = !none_at(sp, "pole_owner") ? int_at(sp, "pole_owner") : i;
        if (!consoles.count(owner)) order.push_back(owner);
        consoles[owner].push_back(i);
    }
    for (long long owner : order) {
        std::vector<long long> members = consoles[owner];
        if (members.size() != 2 || truthy_at(supports[owner], "traverse")) continue;
        std::stable_sort(members.begin(), members.end(), [&](long long x, long long y) { return num_at(supports[x], "s") < num_at(supports[y], "s"); });
        D2 t = d2(supports[owner].get("t"));
        std::pair<long long, double> list[2] = {{members[0], -1.0}, {members[1], 1.0}};
        for (auto& [i, sign] : list) {
            Value sp = supports[i];
            D2 st = d2(sp.get("t"));
            bool same = st[0] * t[0] + st[1] * t[1] >= 0;
            sp["console_shift"] = Value(sign * TRAVERSE_HALF * (same ? 1.0 : -1.0));
        }
        supports[owner]["traverse"] = Value::Bool(true);
    }
}

static long long assign_springs(const Runs& runs, Supports& supports) {
    long long count = 0;
    for (const auto& indices : runs) {
        for (size_t k = 1; k + 1 < indices.size(); k++) {
            Value sp = supports[indices[k]];
            if (!none_at(sp, "anchor") || !none_at(sp, "overlap_of") || truthy_at(sp, "rider") || get_eq_str(sp, "fixator", "overlap") ||
                truthy_at(sp, "middle_anchor") || num_at(sp, "radius", 1e9) <= SPRING_MIN_RADIUS)
                continue;
            Value st = sp.get("track");
            double lengths[2];
            long long js[2] = {indices[k - 1], indices[k + 1]};
            for (int q = 0; q < 2; q++) {
                Value ot = supports[js[q]].get("track");
                lengths[q] = py::hypot(ot[0].num() - st[0].num(), ot[2].num() - st[2].num());
            }
            if (pymin(lengths[0], lengths[1]) < SPRING_MIN_SPAN) continue;
            sp["spring"] = Value::Bool(true);
            count++;
        }
    }
    return count;
}

// ---------------------------------------------------------------- DPR feeders
static void plan_feeders(CatNet& cn, const std::vector<ChainData>& chain_data, const Supports& supports,
                         const std::vector<Value>& portals, Ground& ground, Value& feeder_poles, Value& feeder_spans) {
    SegmentIndex<int> electrified;
    for (const ChainData& cd : chain_data)
        for (size_t i = 0; i + 1 < cd.points.size(); i++)
            if (cd.cum[i + 1] >= cd.first - END_GAP && cd.cum[i] <= cd.last + END_GAP)
                electrified.add({cd.points[i][0], cd.points[i][2]}, {cd.points[i + 1][0], cd.points[i + 1][2]}, 0);

    std::vector<Value> cands;
    for (const Value& sp : supports) {
        if (!none_at(sp, "portal") || !none_at(sp, "pole_owner") || truthy_at(sp, "dropped")) continue;
        V3 pole = v3(sp.get("pole"));
        Value track = sp.get("track");
        D2 out = unit2(pole[0] - track[0].num(), pole[2] - track[2].num());
        Value anchor = sp.get("anchor");
        if (!anchor.is_none()) {
            Value g = anchor.get("guy_ground");
            if ((g[0].num() - pole[0]) * out[0] + (g[2].num() - pole[2]) * out[1] > 0.8) continue;
        }
        double base_y = pole_base_y(sp);
        Value c = Value::dict();
        c["pos"] = vec2(pole[0], pole[2]);
        c["base_y"] = Value(base_y);
        c["out"] = list2(out);
        c["t"] = sp.get("t").copy();
        c["tile"] = sp.get("tile");
        c["kind"] = Value("pole");
        c["bracket_y"] = Value(base_y + POLE_HEIGHT - FEEDER_BRACKET_DROP);
        c["root_out"] = Value(pole_radius_at(base_y, base_y + POLE_HEIGHT - FEEDER_BRACKET_DROP));
        c["rail_y"] = track[1];
        cands.push_back(c);
    }
    for (const Value& portal : portals) {
        if (truthy_at(portal, "unused")) continue;
        Value poles = portal.get("poles");
        V3 a = v3(poles[0]), b = v3(poles[1]);
        D2 across = unit2(b[0] - a[0], b[2] - a[2]);
        Value along = vec2(across[1], -across[0]);
        std::pair<V3, double> posts[2] = {{a, -1.0}, {b, 1.0}};
        for (auto& [post, sign] : posts) {
            Value out = vec2(across[0] * sign, across[1] * sign);
            Value pos, extra = Value::dict();
            double bracket_y;
            if (get_eq_str(portal, "kind", "truss")) {
                Value chord;
                Value centre = portal.get("centre");
                Value chords = portal.get("chords");
                if (chords.type == Value::LIST)
                    for (const Value& c : chords.lst())
                        if ((c[0].num() - centre[0].num()) * out[0].num() + (c[1].num() - centre[2].num()) * out[1].num() > 0) chord = c;
                if (chord.is_none()) continue;
                pos = vec2(chord[0].num(), chord[1].num());
                bracket_y = chord[3].num() - 0.04;
                extra["kind"] = Value("truss");
                extra["root_out"] = Value(0.0);
                extra["chord_low"] = Value(pymax(chord[2].num(), chord[3].num() - 0.7));
            } else {
                double top = portal_beam_y(portal) + portal_beam_size(portal).second / 2 + (portal_twin(portal) ? PORTAL_DECK : 0.0);
                pos = vec2(post[0], post[2]);
                bracket_y = top + FEEDER_STAND;
                extra["kind"] = Value("portal");
                extra["root_out"] = Value(0.0);
                extra["stand_from"] = Value(top);
                extra["girder_width"] = Value(portal_beam_size(portal).first);
            }
            Value fp = Value::dict();
            fp["pos"] = pos;
            fp["base_y"] = Value(num_at(portal, "rail_y") - POLE_BASE_BELOW_RAIL);
            fp["out"] = out;
            fp["t"] = along;
            Value pt = portal.get("tile");
            fp["tile"] = pt.truthy() ? pt : Value(tile_of_point(pos[0].num(), pos[1].num()));
            fp["bracket_y"] = Value(bracket_y);
            fp["rail_y"] = portal.get("rail_y");
            for (auto& kv : extra.dct().items) fp[kv.first] = kv.second;
            cands.push_back(fp);
        }
    }

    std::vector<Value> outer;
    for (const Value& fp : cands) {
        Value pos = fp.get("pos"), out = fp.get("out");
        double x = pos[0].num(), z = pos[1].num();
        bool hit = false;
        for (int i : electrified.near(x, z, FEEDER_OUTER_CHECK)) {
            const auto& it = electrified.items[i];
            if (ray_hits_segment({x, z}, {out[0].num(), out[1].num()}, FEEDER_OUTER_CHECK, it.a, it.b)) { hit = true; break; }
        }
        if (!hit) outer.push_back(fp);
    }
    std::map<std::pair<long long, long long>, std::vector<long long>> grid;
    for (long long i = 0; i < (long long)outer.size(); i++) {
        Value pos = outer[i].get("pos");
        grid[{(long long)py::floordiv(pos[0].num(), 50.0), (long long)py::floordiv(pos[1].num(), 50.0)}].push_back(i);
    }
    auto clear_of_ground = [&](const Value& fp, const Value& q) {
        Value pa_ = fp.get("pos"), pb_ = q.get("pos");
        double length = py::dist2(pa_[0].num(), pa_[1].num(), pb_[0].num(), pb_[1].num());
        double sag = FEEDER_SAG_70M * py::pow(length / 70.0, 2.0);
        std::vector<V3> pa = feeder_points(fp), pb = feeder_points(q);
        auto d3 = [](const V3& u, const V3& v) { return py::dist3(u[0], u[1], u[2], v[0], v[1], v[2]); };
        if (d3(pa[0], pb[0]) + d3(pa[1], pb[1]) > d3(pa[0], pb[1]) + d3(pa[1], pb[0])) std::reverse(pb.begin(), pb.end());
        for (int w = 0; w < 2; w++) {
            const V3& a = pa[w];
            const V3& b = pb[w];
            for (int k = 1; k < 20; k++) {
                double f = k / 20.0;
                V3 p = lerp(a, b, f);
                double y = p[1] - 4.0 * sag * f * (1.0 - f);
                std::vector<double> heights = ground.heights(p[0], p[2]);
                bool bad = false;
                for (double h : heights) if (y - FEEDER_GROUND_CLEARANCE < h && h < y + 1.0) { bad = true; break; }
                if (!bad && !heights.empty()) {
                    bool below = false;
                    for (double h : heights) if (h <= y - FEEDER_GROUND_CLEARANCE) { below = true; break; }
                    if (!below) bad = true;
                }
                if (bad) return false;
            }
        }
        return true;
    };
    auto best_link = [&](long long i, double direction) -> long long {
        const Value& fp = outer[i];
        Value pos = fp.get("pos"), t = fp.get("t"), out = fp.get("out");
        double x = pos[0].num(), z = pos[1].num();
        std::vector<std::pair<double, long long>> found;
        long long cx = (long long)py::floordiv(x, 50.0), cz = (long long)py::floordiv(z, 50.0);
        for (long long gx = cx - 2; gx < cx + 3; gx++)
            for (long long gz = cz - 2; gz < cz + 3; gz++) {
                auto it = grid.find({gx, gz});
                if (it == grid.end()) continue;
                for (long long j : it->second) {
                    if (j == i) continue;
                    const Value& q = outer[j];
                    Value qp = q.get("pos"), qo = q.get("out");
                    double dx = qp[0].num() - x, dz = qp[1].num() - z;
                    double along = (dx * t[0].num() + dz * t[1].num()) * direction;
                    double lateral = dx * out[0].num() + dz * out[1].num();
                    if (!(15.0 <= along && along <= FEEDER_MAX_SPAN)) continue;
                    if (std::fabs(lateral) > 0.2 * along + 1.5) continue;
                    if (out[0].num() * qo[0].num() + out[1].num() * qo[1].num() < 0.3) continue;
                    if (std::fabs(num_at(q, "bracket_y") - num_at(fp, "bracket_y")) > 5.0) continue;
                    found.push_back({along + FEEDER_SIDE_PENALTY * std::fabs(lateral), j});
                }
            }
        std::sort(found.begin(), found.end());
        for (size_t rank = 0; rank < found.size(); rank++) {
            long long j = found[rank].second;
            Value a = fp.get("pos"), b = outer[j].get("pos");
            D2 A{a[0].num(), a[1].num()}, B{b[0].num(), b[1].num()};
            if (crosses_track(cn.net.all_tracks, A, B)) return -1;
            for (double f : {0.25, 0.5, 0.75})
                if (track_distance(cn, A[0] + (B[0] - A[0]) * f, A[1] + (B[1] - A[1]) * f) < FEEDER_TRACK_CLEARANCE) return -1;
            if (clear_of_ground(fp, outer[j])) return j;
            if (rank >= 2) break;
        }
        return -1;
    };
    std::vector<std::pair<long long, long long>> picks;
    for (long long i = 0; i < (long long)outer.size(); i++) {
        long long f = best_link(i, 1.0);
        long long b = best_link(i, -1.0);
        picks.push_back({f, b});
    }
    py::PairSet edges;
    for (long long i = 0; i < (long long)picks.size(); i++)
        for (long long j : {picks[i].first, picks[i].second})
            if (j >= 0 && (picks[j].first == i || picks[j].second == i)) edges.add(std::min(i, j), std::max(i, j));
    std::map<long long, std::vector<long long>> neighbours;
    for (auto& [i, j] : edges.items()) {
        neighbours[i].push_back(j);
        neighbours[j].push_back(i);
    }
    std::set<long long> seen;
    std::unordered_map<long long, long long> index_of;
    for (auto& kv : neighbours) {
        long long start = kv.first;
        if (seen.count(start)) continue;
        std::vector<long long> stack{start}, piece;
        seen.insert(start);
        while (!stack.empty()) {
            long long i = stack.back();
            stack.pop_back();
            piece.push_back(i);
            for (long long j : neighbours[i])
                if (!seen.count(j)) { seen.insert(j); stack.push_back(j); }
        }
        if (piece.size() < 3) continue;
        for (long long i : piece) {
            const Value& o = outer[i];
            Value fp = Value::dict();
            for (const char* key : {"pos", "base_y", "out", "tile", "kind", "bracket_y", "root_out"}) fp[key] = o.get(key);
            if (o.has("chord_low")) {
                fp["chord_low"] = o.get("chord_low");
                fp["t"] = o.get("t").copy();
            }
            if (o.has("stand_from")) {
                fp["stand_from"] = o.get("stand_from");
                fp["girder_width"] = o.get("girder_width");
                fp["t"] = o.get("t").copy();
            }
            if (neighbours[i].size() == 1) {
                Value q = outer[neighbours[i][0]].get("pos");
                Value p = fp.get("pos");
                fp["end"] = list2(unit2(q[0].num() - p[0].num(), q[1].num() - p[1].num()));
            }
            index_of[i] = (long long)feeder_poles.size();
            feeder_poles.append(fp);
        }
        for (long long i : piece)
            for (long long j : neighbours[i])
                if (i < j) {
                    Value s = Value::dict();
                    s["tile"] = outer[i].get("tile");
                    s["from"] = Value(index_of[i]);
                    s["to"] = Value(index_of[j]);
                    feeder_spans.append(s);
                }
    }
}

// ---------------------------------------------------------------- plan_catenary
static std::string repr_list_spans(const std::vector<std::tuple<double, long long, long long>>& v, size_t n) {
    std::string s = "[";
    for (size_t i = 0; i < v.size() && i < n; i++) {
        if (i) s += ", ";
        s += "(" + py::repr(std::get<0>(v[i])) + ", " + std::to_string(std::get<1>(v[i])) + ", " + std::to_string(std::get<2>(v[i])) + ")";
    }
    return s + "]";
}

static Value plan_catenary(const std::string& rom, const std::vector<std::string>& tiles, const PrepareFn& prepare, const std::string& road_dir) {
    CatNet cn;
    cn.net = build_network(tiles, prepare, "mega_island");
    Network& net = cn.net;
    load_signals(rom, cn.signals, cn.facings);
    Ground ground(rom);
    Trusses trusses(rom);
    cn.roads.has_dir = !road_dir.empty();
    cn.roads.dir = road_dir;
    auto covered = [&](const V3& q) {
        for (double h : ground.heights(q[0], q[2])) if (q[1] + COVER_LOW < h && h < q[1] + COVER_HIGH) return true;
        return false;
    };
    // electrified = {(a, b) for a in net.links for b in net.links[a] if a < b}, sorted
    std::vector<NEdge> electrified;
    {
        std::set<NEdge> seen_e;
        for (auto& kv : net.links)
            for (NKey b : kv.second)
                if (net.key_less(kv.first, b) && seen_e.insert({kv.first, b}).second) electrified.push_back({kv.first, b});
        std::sort(electrified.begin(), electrified.end(), [&](const NEdge& x, const NEdge& y) {
            if (x.first != y.first) return net.key_less(x.first, y.first);
            return net.key_less(x.second, y.second);
        });
    }
    std::vector<NKey> sub_order;
    std::unordered_map<NKey, std::vector<NKey>> sub_links;
    for (auto& [a, b] : electrified) {
        if (!sub_links.count(a)) sub_order.push_back(a);
        sub_links[a].push_back(b);
        if (!sub_links.count(b)) sub_order.push_back(b);
        sub_links[b].push_back(a);
    }
    std::unordered_map<NKey, V3> sub_pos;
    for (NKey k : sub_order) sub_pos[k] = net.pos.at(k);
    auto chains = build_chains<NKey>(sub_order, sub_pos, sub_links);

    std::vector<ChainData> chain_data;
    for (auto& [chain, through] : chains) {
        (void)through;
        std::vector<V3> points;
        for (NKey k : chain) points.push_back(net.pos.at(k));
        std::vector<double> cum{0.0};
        for (size_t i = 0; i + 1 < points.size(); i++)
            cum.push_back(cum.back() + py::dist2(points[i][0], points[i][2], points[i + 1][0], points[i + 1][2]));
        double total = cum.back();
        long long pieces = std::max(1LL, (long long)py::floordiv(total, COVER_SAMPLE_STEP));
        bool open = true;
        double open_from = 0.0;
        std::vector<std::pair<double, double>> runs;
        for (long long i = 0; i <= pieces; i++) {
            double s = total * i / pieces;
            V3 q = polyline_point(points, cum, s);
            if (covered(q)) {
                if (open) runs.push_back({open_from, s - COVER_MARGIN});
                open = false;
            } else if (!open) {
                open = true;
                open_from = s + COVER_MARGIN;
            }
        }
        if (open) runs.push_back({open_from, total});
        for (auto& [a, b] : runs)
            if (b - a >= MIN_RUN_LENGTH) chain_data.push_back({chain, points, cum, a + END_GAP, b - END_GAP});
    }

    std::vector<std::vector<Zone>> truss_zones_all;
    for (const ChainData& cd : chain_data) truss_zones_all.push_back(truss_zones(trusses, cd.points, cd.cum, cd.first, cd.last));
    std::vector<Value> portals;
    std::vector<std::vector<Item>> planned;
    for (int round = 0; round < PORTAL_ROUNDS; round++) {
        size_t count = portals.size();
        planned.clear();
        for (size_t k = 0; k < chain_data.size(); k++) {
            const ChainData& cd = chain_data[k];
            planned.push_back(space_supports(ground, cn, cd.points, cd.cum, cd.first, cd.last, portals, &trusses, truss_zones_all[k]));
        }
        long long dead = duplicate_portals(portals);
        std::cerr << "portal round " << round << ": portals " << portals.size() << ", dropped " << dead << std::endl;
        if (portals.size() == count && !dead) break;
    }
    std::set<long long> used;
    for (auto& items : planned) for (auto& it : items) if (it.portal >= 0) used.insert(it.portal);
    std::map<long long, long long> renumber;
    for (long long old_id : used) { long long n = (long long)renumber.size(); renumber[old_id] = n; }
    {
        std::vector<Value> kept_portals;
        for (long long i : used) {
            Value p = portals[i].copy();
            p["id"] = Value(renumber[i]);
            kept_portals.push_back(p);
        }
        portals = kept_portals;
    }
    for (auto& items : planned) for (auto& it : items) if (it.portal >= 0) it.portal = renumber[it.portal];

    Supports supports;
    Runs runs;
    long long blocked = 0;
    for (size_t run_index = 0; run_index < chain_data.size(); run_index++) {
        const ChainData& cd = chain_data[run_index];
        std::vector<long long> indices;
        for (const Item& item : planned[run_index]) {
            if (item.portal < 0 && item.side == 0) { blocked++; continue; }
            Value support = place_support(ground, item);
            support["seq"] = Value((long long)indices.size());
            support["tile"] = Value(chain_tile(net, cd.chain, cd.cum, item.s));
            support["s"] = Value(item.s);
            support["run"] = Value((long long)run_index);
            indices.push_back((long long)supports.size());
            supports.push_back(support);
        }
        runs.push_back(indices);
    }

    std::unordered_set<std::string> net_tiles;
    for (NKey k : net.order) net_tiles.insert(net.key_tile[k]);
    std::set<std::pair<long long, bool>> edge_ends;
    for (size_t run = 0; run < chain_data.size(); run++) {
        const ChainData& cd = chain_data[run];
        if (leaves_mainland(net, net_tiles, cd.chain.front())) edge_ends.insert({(long long)run, false});
        if (leaves_mainland(net, net_tiles, cd.chain.back())) edge_ends.insert({(long long)run, true});
    }
    long long trimmed = trim_bridge_ends(ground, runs, supports, portals, edge_ends);
    long long shared = share_poles(cn, chain_data, runs, supports);
    long long overlaps = extend_over_turnouts(cn, chain_data, runs, supports);
    auto sections = split_sections(ground, cn, chain_data, runs, supports);
    auto [own_anchor_poles, kept_anchors] = anchor_poles(ground, cn, runs, supports, portals);
    Value spans = Value::list();
    for (size_t run = 0; run < runs.size(); run++) {
        const auto& indices = runs[run];
        for (size_t k = 0; k + 1 < indices.size(); k++) {
            long long a = indices[k], b = indices[k + 1];
            Value span = Value::dict();
            span["tile"] = supports[a].get("tile");
            span["from"] = Value(a);
            span["to"] = Value(b);
            span["run"] = Value((long long)run);
            if (truthy_at(supports[b], "insulate") && truthy_at(supports[a], "section_anchor")) span["insulators"] = Value("to");
            else if (truthy_at(supports[a], "insulate") && truthy_at(supports[b], "section_anchor")) span["insulators"] = Value("from");
            spans.append(span);
        }
    }
    long long anchors = mark_anchors(ground, cn, runs, supports, portals);
    assign_stagger(runs, supports, chain_data);
    long long middle = middle_anchors(runs, supports);
    long long masts = assign_masts(cn, supports, portals);
    traverse_shared_poles(supports);
    long long springs = assign_springs(runs, supports);
    std::set<long long> live;
    for (const Value& sp : supports) if (!none_at(sp, "portal") && !truthy_at(sp, "dropped")) live.insert(int_at(sp, "portal"));
    for (Value& portal : portals) {
        Value c = portal.get("centre");
        portal["tile"] = Value(tile_of_point(c[0].num(), c[2].num()));
        if (!live.count(int_at(portal, "id"))) portal["unused"] = Value::Bool(true);
    }
    std::cout << "contact wire off the track axis: (not computed by the C++ planner, a check only)" << std::endl;
    {
        std::vector<std::pair<double, V3>> ls;
        for (const Value& sp : spans.lst()) {
            const Value& a = supports[int_at(sp, "from")];
            const Value& b = supports[int_at(sp, "to")];
            ls.push_back({plan_distance(a, b), v3(a.get("track"))});
        }
        std::stable_sort(ls.begin(), ls.end(), [](const std::pair<double, V3>& x, const std::pair<double, V3>& y) {
            if (x.first != y.first) return x.first > y.first;
            return x.second > y.second;
        });
        std::vector<std::tuple<double, long long, long long>> long_spans;
        for (auto& [d, p] : ls)
            if (d > MAX_SPAN + 1.0) long_spans.push_back({py::round_nd(d, 1), py::round_int(p[0]), py::round_int(p[2])});
        std::cout << "spans longer than " << py::fmt_f(MAX_SPAN, 0) << " m: " << long_spans.size() << " "
                  << repr_list_spans(long_spans, 10) << std::endl;
    }
    Value feeder_poles = Value::list(), feeder_spans = Value::list();
    plan_feeders(cn, chain_data, supports, portals, ground, feeder_poles, feeder_spans);

    long long n_sections = 0;
    for (auto& r : runs) if (r.size() >= 2) n_sections++;
    long long on_portals = 0, on_truss = 0, on_brackets = 0, truss_portals = 0, traverses = 0, held = 0;
    for (const Value& sp : supports) {
        if (!none_at(sp, "portal")) {
            if (get_eq_str(portals[int_at(sp, "portal")], "kind", "truss")) on_truss++; else on_portals++;
        }
        if (!none_at(sp, "bracket") && !truthy_at(sp, "dropped")) on_brackets++;
        if (truthy_at(sp, "traverse") && !truthy_at(sp, "dropped")) traverses++;
        if (truthy_at(sp, "garland_fix") && !truthy_at(sp, "dropped")) held++;
    }
    for (const Value& p : portals) if (get_eq_str(p, "kind", "truss")) truss_portals++;
    std::cout << "catenary: route nodes 0, electrified edges " << electrified.size() << ", wire runs " << chain_data.size()
              << ", sections " << n_sections << ", supports " << supports.size() << " (on portals " << on_portals
              << ", on truss girders " << on_truss << ", on viaduct brackets " << on_brackets << ", on shared poles " << shared
              << ", anchors " << anchors << " (moved to own poles " << own_anchor_poles << "), left out " << blocked
              << ", trimmed off bridge ends " << trimmed << "), turnout overlaps " << overlaps << ", section overlaps "
              << sections.first << " plain + " << sections.second << " insulating, middle anchors " << middle << ", spans "
              << spans.size() << ", portals " << portals.size() << " (truss girders " << truss_portals << "), DPR spans "
              << feeder_spans.size() << "; anchors kept on working poles " << kept_anchors << ", traverses " << traverses
              << ", console posts " << masts << ", spring stays " << springs << ", held strings " << held << std::endl;

    Value plan = Value::dict();
    Value sl = Value::list();
    for (Value& sp : supports) sl.append(sp);
    Value pl = Value::list();
    for (Value& p : portals) pl.append(p);
    plan["supports"] = sl;
    plan["spans"] = spans;
    plan["portals"] = pl;
    plan["feeder_poles"] = feeder_poles;
    plan["feeder_spans"] = feeder_spans;
    return plan;
}

void step_catenary(const std::string& rom, const std::string& work) {
    Value scan = json::load(work + "/scan.json");
    std::vector<std::string> tiles;
    for (const Value& t : scan.get("tiles").lst()) tiles.push_back(t.str());
    std::string road_dir = work + "/roads";
    PrepareFn prepare = [&](const std::string& tile) { return prepare_graph(rom, tile, scan); };
    Value plan = plan_catenary(rom, tiles, prepare, dir_exists(road_dir) ? road_dir : std::string());
    json::dump(plan, work + "/catenary.json");
    std::cout << "done" << std::endl;
}
