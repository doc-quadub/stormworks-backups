// build_world.py: helpers and step "scan" (find tiles, ballast recolour analysis, border pairs)
#include "scan.h"
#include "py.h"
#include <algorithm>
#include <map>
#include <set>
#include <unordered_set>
#include <iostream>
#include <regex>
#include <cstring>

static const double BALLAST_R = 82, BALLAST_G = 80, BALLAST_B = 76;
static const double SANDY_TRIANGLE_REACH = 8.0;
static const double MIN_COMPONENT_LENGTH = 50.0;
static const double BORDER = 499.5;
static const double BORDER_NEAR = 497.0;
static const double BORDER_PAIR_GAP = 1.0;
static const double BORDER_PAIR_RISE = 0.6;
static const double BED_BELOW_TRACK = -1.5;
static const double BED_ABOVE_TRACK = 0.3;

std::string tile_xml_path(const std::string& rom, const std::string& tile) {
    return rom + "/data/tiles/" + tile + ".xml";
}

// r'<mesh id="[^"]*"(?: parent_id="[^"]*")? file_name="([^"]+)">\s*<transform([^/]*)/>'
std::vector<MeshEntry> mesh_entries(const std::string& text) {
    std::vector<MeshEntry> out;
    std::string_view t(text);
    static const std::string_view pre = "<mesh id=\"";
    size_t i = 0;
    while ((i = t.find(pre, i)) != std::string_view::npos) {
        size_t start = i;
        size_t s = i + pre.size();
        size_t e = t.find('"', s);                // [^"]*" : the first quote
        bool ok = false;
        if (e != std::string_view::npos) {
            // try with the optional parent_id group, then without
            for (int with_parent = 1; with_parent >= 0 && !ok; with_parent--) {
                size_t p = e + 1;
                if (with_parent) {
                    if (t.substr(p, 12) != " parent_id=\"") continue;
                    size_t q = t.find('"', p + 12);
                    if (q == std::string_view::npos) continue;
                    p = q + 1;
                }
                if (t.substr(p, 12) != " file_name=\"") continue;
                size_t f0 = p + 12;
                size_t f1 = t.find('"', f0);
                if (f1 == std::string_view::npos || f1 == f0) continue;
                if (f1 + 1 >= t.size() || t[f1 + 1] != '>') continue;
                size_t r = f1 + 2;
                while (r < t.size() && is_space(t[r])) r++;
                if (t.substr(r, 10) != "<transform") continue;
                size_t a = r + 10;
                size_t slash = t.find('/', a);
                if (slash == std::string_view::npos || slash + 1 >= t.size() || t[slash + 1] != '>') continue;
                out.push_back({std::string(t.substr(f0, f1 - f0)), parse_transform(t.substr(a, slash - a))});
                i = slash + 2;
                ok = true;
            }
        }
        if (!ok) i = start + 1;
    }
    return out;
}

V3 transform_point(const V3& p, const Mat4& m) {
    return {p[0] * m[0][0] + p[1] * m[1][0] + p[2] * m[2][0] + m[3][0],
            p[0] * m[0][1] + p[1] * m[1][1] + p[2] * m[2][1] + m[3][1],
            p[0] * m[0][2] + p[1] * m[1][2] + p[2] * m[2][2] + m[3][2]};
}

// ---------------------------------------------------------------- SegmentGrid
struct SegmentGrid {
    double cell;
    std::map<std::pair<long long, long long>, std::vector<std::pair<V3, V3>>> grid;
    explicit SegmentGrid(const Tracks& tr, double cell_ = 10.0) : cell(cell_) {
        std::set<std::pair<std::string, std::string>> seen;
        std::map<std::pair<long long, long long>, std::set<std::pair<V3, V3>>> cells;
        for (const std::string& k : tr.order) {
            const TrackNode& n = tr.at(k);
            for (const std::string& o : n.links) {
                if (!tr.has(o) || o == k) continue;
                auto key = k < o ? std::make_pair(k, o) : std::make_pair(o, k);
                if (seen.count(key)) continue;
                seen.insert(key);
                V3 a = n.pos, b = tr.at(o).pos;
                long long steps = (long long)py::floordiv(py::dist3(a[0], a[1], a[2], b[0], b[1], b[2]), cell / 2) + 1;
                for (long long i = 0; i <= steps; i++) {
                    double f = (double)i / (double)steps;
                    double x = a[0] + (b[0] - a[0]) * f;
                    double z = a[2] + (b[2] - a[2]) * f;
                    cells[{(long long)py::floordiv(x, cell), (long long)py::floordiv(z, cell)}].insert({a, b});
                }
            }
        }
        for (auto& kv : cells) grid[kv.first].assign(kv.second.begin(), kv.second.end());
    }
    double distance(double x, double z) const {
        double best = INFINITY;
        long long cx = (long long)py::floordiv(x, cell), cz = (long long)py::floordiv(z, cell);
        for (long long ix = cx - 1; ix <= cx + 1; ix++)
            for (long long iz = cz - 1; iz <= cz + 1; iz++) {
                auto it = grid.find({ix, iz});
                if (it == grid.end()) continue;
                for (auto& ab : it->second) {
                    const V3 &a = ab.first, &b = ab.second;
                    double dx = b[0] - a[0], dz = b[2] - a[2];
                    double length2 = dx * dx + dz * dz;
                    double t = length2 == 0 ? 0.0 : std::max(0.0, std::min(1.0, ((x - a[0]) * dx + (z - a[2]) * dz) / length2));
                    best = std::min(best, py::hypot(x - a[0] - t * dx, z - a[2] - t * dz));
                }
            }
        return best;
    }
    bool near_bed(double x, double y, double z, double radius) const {
        long long cx = (long long)py::floordiv(x, cell), cz = (long long)py::floordiv(z, cell);
        for (long long ix = cx - 1; ix <= cx + 1; ix++)
            for (long long iz = cz - 1; iz <= cz + 1; iz++) {
                auto it = grid.find({ix, iz});
                if (it == grid.end()) continue;
                for (auto& ab : it->second) {
                    const V3 &a = ab.first, &b = ab.second;
                    double dx = b[0] - a[0], dz = b[2] - a[2];
                    double length2 = dx * dx + dz * dz;
                    double t = length2 == 0 ? 0.0 : std::max(0.0, std::min(1.0, ((x - a[0]) * dx + (z - a[2]) * dz) / length2));
                    if (py::hypot(x - a[0] - t * dx, z - a[2] - t * dz) > radius) continue;
                    double track_y = a[1] + (b[1] - a[1]) * t;
                    double d = y - track_y;
                    if (BED_BELOW_TRACK <= d && d <= BED_ABOVE_TRACK) return true;
                }
            }
        return false;
    }
};

// ---------------------------------------------------------------- tile places
const std::vector<std::pair<std::string, std::pair<int, int>>>& tile_world() {
    static const std::vector<std::pair<std::string, std::pair<int, int>>> t = {
        {"island_33_tile_03", {-19000, -2000}}, {"island_33_tile_04", {-18000, -2000}}, {"island_33_tile_05", {-17000, -2000}},
        {"island_33_tile_06", {-16000, -2000}}, {"island_33_tile_07", {-15000, -2000}},
        {"island_33_tile_11", {-21000, -3000}}, {"island_33_tile_12", {-20000, -3000}}, {"island_33_tile_13", {-19000, -3000}},
        {"island_33_tile_21", {-21000, -4000}}, {"island_33_tile_22", {-20000, -4000}}, {"island_33_tile_23", {-19000, -4000}},
        {"island_33_tile_31", {-21000, -5000}}, {"island_33_tile_32", {-20000, -5000}}, {"island_33_tile_33", {-19000, -5000}},
    };
    return t;
}
const std::pair<int, int>* tile_world_get(const std::string& t) {
    for (auto& kv : tile_world()) if (kv.first == t) return &kv.second;
    return nullptr;
}

// re.fullmatch(r"(.+)_(\d+)_(\d+)", t): greedy (.+) - the last two _digits groups
bool grid_name(const std::string& t, std::string& family, long long& x, long long& z) {
    // the regex backtracks from the end: (\d+) at the end, then '_', (\d+), '_', rest
    int n = (int)t.size();
    int j = n - 1;
    while (j >= 0 && is_digit(t[j])) j--;
    if (j == n - 1 || j < 0 || t[j] != '_') return false;
    int k = j - 1;
    while (k >= 0 && is_digit(t[k])) k--;
    if (k == j - 1 || k < 1 || t[k] != '_') return false;
    // greedy (.+) takes the longest prefix, so the second group is the maximal digit run
    // before the last '_' (digits cannot split differently since '_' separates them)
    family = t.substr(0, k);
    x = std::stoll(t.substr(k + 1, j - k - 1));
    z = std::stoll(t.substr(j + 1));
    return true;
}

// ---------------------------------------------------------------- stray components / border partners
namespace {
struct NodeKey {
    int tile;
    std::string id;
    bool operator==(const NodeKey& o) const { return tile == o.tile && id == o.id; }
    bool operator<(const NodeKey& o) const { return tile != o.tile ? tile < o.tile : id < o.id; }
};
struct NodeKeyHash {
    size_t operator()(const NodeKey& k) const { return std::hash<std::string>()(k.id) * 31 + k.tile; }
};
struct Edge {
    std::string name;
    double along, across;
};
}

static bool own_edge(const V3& p, double near, Edge& e) {
    if (std::max(std::fabs(p[0]), std::fabs(p[2])) < near) return false;
    if (std::fabs(p[0]) >= std::fabs(p[2])) {
        e = {p[0] > 0 ? "x+" : "x-", p[2], p[0]};
    } else {
        e = {p[2] > 0 ? "z+" : "z-", p[0], p[2]};
    }
    return true;
}

static std::pair<int, int> step_of(const std::string& edge) {
    if (edge == "x+") return {1, 0};
    if (edge == "x-") return {-1, 0};
    if (edge == "z+") return {0, 1};
    return {0, -1};
}
static std::string opposite_of(const std::string& e) {
    if (e == "x+") return "x-";
    if (e == "x-") return "x+";
    if (e == "z+") return "z-";
    return "z+";
}

// returns 1 yes, 0 no, -1 unknown (None)
static int neighbours(const std::string& t, const std::string& edge, const std::string& tt) {
    const auto* a = tile_world_get(t);
    const auto* b = tile_world_get(tt);
    if (a && b) {
        long long dx = py::ifloordiv((long long)(b->first - a->first), 1000LL);
        long long dz = py::ifloordiv((long long)(b->second - a->second), 1000LL);
        auto st = step_of(edge);
        return (dx == st.first && dz == st.second) ? 1 : 0;
    }
    std::string fa, fb;
    long long ax, az, bx, bz;
    if (!grid_name(t, fa, ax, az) || !grid_name(tt, fb, bx, bz) || fa != fb) return -1;
    auto st = step_of(edge);
    return (bx - ax == st.first && bz - az == st.second) ? 1 : 0;
}

StrayResult find_stray_components(const std::string& rom, const std::vector<std::string>& tiles) {
    std::vector<Tracks> nodes_by_tile;
    nodes_by_tile.reserve(tiles.size());
    for (const std::string& t : tiles) nodes_by_tile.push_back(read_tracks(tile_xml_path(rom, t)));

    auto degree = [&](int ti, const std::string& k) {
        const Tracks& nodes = nodes_by_tile[ti];
        int c = 0;
        for (const std::string& o : nodes.at(k).links) if (nodes.has(o) && o != k) c++;
        return c;
    };

    struct Cand { int tile; std::string id; double along, y, across; };
    std::map<std::pair<std::string, long long>, std::vector<Cand>> by_edge;
    for (int ti = 0; ti < (int)tiles.size(); ti++) {
        const Tracks& nodes = nodes_by_tile[ti];
        for (const std::string& k : nodes.order) {
            const V3& p = nodes.at(k).pos;
            Edge e;
            if (own_edge(p, BORDER_NEAR, e))
                by_edge[{e.name, py::round_int(e.along)}].push_back({ti, k, e.along, p[1], e.across});
        }
    }

    std::unordered_map<NodeKey, NodeKey, NodeKeyHash> parent;
    auto find = [&](NodeKey a) {
        auto it = parent.find(a);
        if (it == parent.end()) { parent.emplace(a, a); return a; }
        while (!(parent.at(a) == a)) {
            NodeKey pa = parent.at(a);
            NodeKey ppa = parent.at(pa);
            parent[a] = ppa;
            a = ppa;
        }
        return a;
    };
    auto unite = [&](const NodeKey& a, const NodeKey& b) {
        NodeKey ra = find(a);
        NodeKey rb = find(b);
        parent[ra] = rb;
    };

    // candidates: (t, k) -> strict set, loose set; insertion order kept
    struct Found { std::set<NodeKey> strict, loose; };
    std::vector<NodeKey> cand_order;
    std::map<NodeKey, Found> candidates;
    for (int ti = 0; ti < (int)tiles.size(); ti++) {
        const Tracks& nodes = nodes_by_tile[ti];
        for (const std::string& k : nodes.order) {
            const TrackNode& node = nodes.at(k);
            const V3& p = node.pos;
            find({ti, k});
            for (const std::string& o : node.links)
                if (nodes.has(o) && o != k) unite({ti, k}, {ti, o});
            Edge e;
            if (!own_edge(p, BORDER_NEAR, e)) continue;
            long long r = py::round_int(e.along);
            for (long long c : {r - 1, r, r + 1}) {
                auto it = by_edge.find({opposite_of(e.name), c});
                if (it == by_edge.end()) continue;
                for (const Cand& cd : it->second) {
                    double y = cd.y;
                    if (std::fabs(y - p[1]) >= BORDER_PAIR_RISE) continue;
                    int adjacent = neighbours(tiles[ti], e.name, tiles[cd.tile]);
                    bool on_edge = std::fabs(e.across) >= BORDER && std::fabs(cd.across) >= BORDER;
                    bool strict = on_edge && std::fabs(cd.along - e.along) < 0.15;
                    if (!strict && std::fabs(y - p[1]) >= 0.3) continue;
                    bool loose = false;
                    if (!strict && adjacent == 1) {
                        double gap_across = e.across - std::copysign(1000.0, e.across) - cd.across;
                        loose = (py::hypot(cd.along - e.along, gap_across) < BORDER_PAIR_GAP
                                 && degree(ti, k) == 1 && degree(cd.tile, cd.id) == 1);
                    }
                    if (strict || loose) {
                        unite({ti, k}, {cd.tile, cd.id});
                        NodeKey key{ti, k};
                        if (!candidates.count(key)) cand_order.push_back(key);
                        Found& f = candidates[key];
                        (strict ? f.strict : f.loose).insert({cd.tile, cd.id});
                    }
                }
            }
        }
    }

    StrayResult res;
    // chosen: unique partner
    std::vector<NodeKey> chosen_order;
    std::map<NodeKey, std::pair<NodeKey, bool>> chosen;
    for (const NodeKey& key : cand_order) {
        const Found& f = candidates.at(key);
        const std::set<NodeKey>& best = !f.strict.empty() ? f.strict : f.loose;
        if (best.size() == 1) {
            chosen_order.push_back(key);
            chosen[key] = {*best.begin(), !f.strict.empty()};
        }
    }
    for (const NodeKey& key : chosen_order) {
        const NodeKey& pair = chosen.at(key).first;
        bool exact = chosen.at(key).second;
        if (!exact) {
            auto it = chosen.find(pair);
            if (it == chosen.end() || !(it->second.first == key)) continue;
        }
        const Tracks& tn = nodes_by_tile[pair.tile];
        const TrackNode& pn = tn.at(pair.id);
        std::vector<std::string> inner;
        for (const std::string& o : pn.links) if (tn.has(o) && o != pair.id) inner.push_back(o);
        if (inner.size() != 1) continue;
        const V3& q = tn.at(inner[0]).pos;
        const V3& pp = pn.pos;
        double length = py::hypot(q[0] - pp[0], q[2] - pp[2]);
        if (length < 1e-6) continue;
        Value entry = Value::list({Value(tiles[pair.tile]), Value(pair.id), Value(pp[1]),
                                   Value((q[0] - pp[0]) / length), Value((q[2] - pp[2]) / length),
                                   Value(pp[0]), Value(pp[2]), Value(q[1]), Value(length)});
        const std::string& t = tiles[key.tile];
        res.partners_order_tiles_push(t);
        res.partners[t].emplace_back(key.id, entry);
    }

    // members grouped by root, in first appearance order
    std::vector<NodeKey> root_order;
    std::map<NodeKey, std::vector<NodeKey>> members;
    for (int ti = 0; ti < (int)tiles.size(); ti++)
        for (const std::string& k : nodes_by_tile[ti].order) {
            NodeKey r = find({ti, k});
            auto it = members.find(r);
            if (it == members.end()) { root_order.push_back(r); members[r] = {}; }
            members[r].push_back({ti, k});
        }
    for (const NodeKey& r : root_order) {
        const std::vector<NodeKey>& group = members.at(r);
        std::set<NodeKey> group_set(group.begin(), group.end());
        double length = 0.0;
        for (const NodeKey& m : group) {
            const Tracks& tn = nodes_by_tile[m.tile];
            const TrackNode& node = tn.at(m.id);
            for (const std::string& o : node.links) {
                if (group_set.count({m.tile, o}) && o != m.id) {
                    const V3& a = node.pos;
                    const V3& b = tn.at(o).pos;
                    length += py::dist3(a[0], a[1], a[2], b[0], b[1], b[2]) / 2;
                }
            }
        }
        if (length < MIN_COMPONENT_LENGTH) {
            for (const NodeKey& m : group) {
                const std::string& t = tiles[m.tile];
                if (!res.stray.count(t)) res.stray_order.push_back(t);
                res.stray[t].push_back(m.id);
            }
        }
    }
    return res;
}

void StrayResult::partners_order_tiles_push(const std::string& t) {
    if (!partners.count(t)) partners_order.push_back(t);
}

// ---------------------------------------------------------------- step scan
struct ColorRule { std::array<int, 3> old_c; double radius; bool sandy; };
static const ColorRule RULES[] = {
    {{45, 34, 32}, 2.5, false},
    {{174, 150, 121}, 4.0, true},
    {{41, 31, 29}, 2.5, false},
    {{188, 157, 125}, 4.0, true},
};

void step_scan(const std::string& rom, const std::string& work) {
    std::string tiles_dir = rom + "/data/tiles";
    std::vector<std::string> names = list_dir(tiles_dir);
    std::sort(names.begin(), names.end());
    std::vector<std::string> tiles;
    std::map<std::string, std::string> texts;
    auto ends_with = [](const std::string& s, const std::string& suf) {
        return s.size() >= suf.size() && s.compare(s.size() - suf.size(), suf.size(), suf) == 0;
    };
    for (const std::string& f : names) {
        if (ends_with(f, ".xml") && !ends_with(f, "_instances.xml")) {
            std::string text = read_file(path_join(tiles_dir, f));
            if (text.find("<track ") != std::string::npos) {
                std::string t = f.substr(0, f.size() - 4);
                texts[t] = text;
                tiles.push_back(t);
            }
        }
    }
    std::sort(tiles.begin(), tiles.end());
    // recolor: file -> {vertex: colour} (insertion order of files)
    std::vector<std::string> recolor_order;
    std::map<std::string, std::map<long long, bool>> recolor;     // value: present (colour is fixed)
    std::vector<std::string> prism_order;
    std::map<std::string, std::vector<std::pair<double, double>>> prism;
    std::vector<std::string> usage_order;
    std::map<std::string, std::set<std::string>> usage;
    for (const std::string& tile : tiles) {
        const std::string& text = texts.at(tile);
        Tracks nodes = read_tracks(tile_xml_path(rom, tile));
        SegmentGrid grid(nodes);
        for (const MeshEntry& me : mesh_entries(text)) {
            std::string path = rom + "/" + me.file_name;
            if (!file_exists(path)) continue;
            std::string data = read_file(path);
            uint16_t vcount;
            std::memcpy(&vcount, data.data() + 8, 2);
            auto vert = [&](size_t i) {
                MeshVertex v;
                std::memcpy(&v, data.data() + 14 + 28 * i, 28);
                return v;
            };
            if (!recolor.count(me.file_name)) { recolor_order.push_back(me.file_name); recolor[me.file_name]; }
            auto& hits = recolor[me.file_name];
            std::vector<long long> sandy;
            for (const ColorRule& rule : RULES) {
                for (size_t i = 0; i < vcount; i++) {
                    MeshVertex v = vert(i);
                    if (v.r != rule.old_c[0] || v.g != rule.old_c[1] || v.b != rule.old_c[2]) continue;
                    V3 w = transform_point({(double)v.x, (double)v.y, (double)v.z}, me.matrix);
                    if (grid.near_bed(w[0], w[1], w[2], rule.radius)) {
                        hits[(long long)i] = true;
                        if (rule.sandy) sandy.push_back((long long)i);
                    }
                }
            }
            if (!sandy.empty()) {
                uint32_t count;
                size_t off = 14 + 28 * (size_t)vcount;
                std::memcpy(&count, data.data() + off, 4);
                std::vector<uint16_t> idx(count);
                std::memcpy(idx.data(), data.data() + off + 4, 2 * (size_t)count);
                std::unordered_set<long long> sandy_set(sandy.begin(), sandy.end());
                std::map<long long, std::array<double, 3>> reach_cache;
                auto reach = [&](long long j) -> const std::array<double, 3>& {
                    auto it = reach_cache.find(j);
                    if (it != reach_cache.end()) return it->second;
                    MeshVertex v = vert((size_t)j);
                    V3 w = transform_point({(double)v.x, (double)v.y, (double)v.z}, me.matrix);
                    return reach_cache[j] = {grid.distance(w[0], w[2]), w[0], w[2]};
                };
                for (size_t ti = 0; ti + 2 < (size_t)count + 0 && ti < count; ti += 3) {
                    long long tri[3] = {idx[ti], idx[ti + 1], idx[ti + 2]};
                    bool any = sandy_set.count(tri[0]) || sandy_set.count(tri[1]) || sandy_set.count(tri[2]);
                    if (!any) continue;
                    double far = reach(tri[0])[0];
                    for (int q = 1; q < 3; q++) far = std::max(far, reach(tri[q])[0]);
                    if (far > SANDY_TRIANGLE_REACH) {
                        for (long long j : tri) {
                            if (sandy_set.count(j) && hits.count(j)) {
                                hits.erase(j);
                                if (!prism.count(tile)) prism_order.push_back(tile);
                                prism[tile].push_back({py::round_nd(reach(j)[1], 1), py::round_nd(reach(j)[2], 1)});
                            }
                        }
                    }
                }
            }
            if (!usage.count(me.file_name)) usage_order.push_back(me.file_name);
            usage[me.file_name].insert(tile);
        }
    }
    StrayResult sr = find_stray_components(rom, tiles);

    Value out = Value::dict();
    Value vt = Value::list();
    for (auto& t : tiles) vt.append(Value(t));
    out["tiles"] = vt;
    Value vr = Value::dict();
    long long nvert = 0;
    for (auto& f : recolor_order) {
        auto& hits = recolor.at(f);
        if (hits.empty()) continue;
        Value l = Value::list();
        for (auto& kv : hits) {                       // sorted by vertex index
            l.append(Value::list({Value(kv.first), Value((long long)BALLAST_R), Value((long long)BALLAST_G), Value((long long)BALLAST_B)}));
            nvert++;
        }
        vr[f] = l;
    }
    out["recolor"] = vr;
    Value vs = Value::dict();
    long long nstray = 0;
    for (auto& t : sr.stray_order) {
        Value l = Value::list();
        for (auto& k : sr.stray.at(t)) { l.append(Value(k)); nstray++; }
        vs[t] = l;
    }
    out["stray"] = vs;
    Value vp = Value::dict();
    long long npart = 0;
    for (auto& t : sr.partners_order) {
        Value d = Value::dict();
        for (auto& kv : sr.partners.at(t)) { d[kv.first] = kv.second; }
        npart += (long long)d.size();
        vp[t] = d;
    }
    out["partners"] = vp;
    Value vpr = Value::dict();
    for (auto& t : prism_order) {
        Value l = Value::list();
        for (auto& xz : prism.at(t)) l.append(vec2(xz.first, xz.second));
        vpr[t] = l;
    }
    out["prism"] = vpr;
    Value vu = Value::dict();
    for (auto& f : usage_order) {
        if (!vr.has(f)) continue;
        Value l = Value::list();
        for (auto& t : usage.at(f)) l.append(Value(t));
        vu[f] = l;
    }
    out["usage"] = vu;
    json::dump(out, work + "/scan.json");
    std::cout << "tiles with tracks: " << tiles.size() << "  meshes to recolour: " << vr.size()
              << "  vertices: " << nvert << "  stray nodes skipped: " << nstray
              << "  border nodes with a partner: " << npart << "\n";
    std::cout << "done\n";
}
