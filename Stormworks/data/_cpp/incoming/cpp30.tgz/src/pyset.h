// Iteration order of a CPython 3.10 set of (int, int) tuples (insertions only), as
// Objects/setobject.c and Objects/tupleobject.c (xxHash tuple hash) produce it.
#pragma once
#include <cstdint>
#include <utility>
#include <vector>

namespace py {

inline int64_t int_hash(long long v) {          // hash(int) for small ints
    if (v == -1) return -2;
    // values used here are far below the modulus 2**61 - 1
    return (int64_t)v;
}

inline int64_t tuple2_hash(long long a, long long b) {
    const uint64_t P1 = 11400714785074694791ULL, P2 = 14029467366897019727ULL, P5 = 2870177450012600261ULL;
    uint64_t acc = P5;
    for (long long v : {a, b}) {
        uint64_t lane = (uint64_t)int_hash(v);
        acc += lane * P2;
        acc = (acc << 31) | (acc >> 33);
        acc *= P1;
    }
    acc += 2ULL ^ (P5 ^ 3527539ULL);
    if (acc == (uint64_t)-1) return 1546275796;
    return (int64_t)acc;
}

class PairSet {
public:
    PairSet() { table_.assign(8, Entry()); mask_ = 7; }
    bool contains(long long a, long long b) const { return find(a, b) >= 0; }
    void add(long long a, long long b) {
        int64_t hash = tuple2_hash(a, b);
        size_t mask = mask_;
        size_t i = (size_t)hash & mask;
        Entry* entry = &table_[i];
        if (entry->used) {
            size_t perturb = (size_t)hash;
            while (true) {
                if (entry->hash == hash && entry->a == a && entry->b == b) return;
                if (i + LINEAR_PROBES <= mask) {
                    bool found_unused = false;
                    for (size_t j = 0; j < LINEAR_PROBES; j++) {
                        entry++;
                        if (!entry->used) { found_unused = true; break; }
                        if (entry->hash == hash && entry->a == a && entry->b == b) return;
                    }
                    if (found_unused) break;
                }
                perturb >>= PERTURB_SHIFT;
                i = (i * 5 + 1 + perturb) & mask;
                entry = &table_[i];
                if (!entry->used) break;
            }
        }
        entry->used = true;
        entry->hash = hash;
        entry->a = a;
        entry->b = b;
        fill_++;
        used_++;
        if (fill_ * 5 < mask_ * 3) return;
        resize(used_ > 50000 ? used_ * 2 : used_ * 4);
    }
    std::vector<std::pair<long long, long long>> items() const {
        std::vector<std::pair<long long, long long>> out;
        for (const Entry& e : table_) if (e.used) out.push_back({e.a, e.b});
        return out;
    }
    size_t size() const { return used_; }

private:
    static constexpr size_t LINEAR_PROBES = 9;
    static constexpr size_t PERTURB_SHIFT = 5;
    struct Entry { bool used = false; int64_t hash = 0; long long a = 0, b = 0; };
    std::vector<Entry> table_;
    size_t mask_ = 7, fill_ = 0, used_ = 0;

    long long find(long long a, long long b) const {
        int64_t hash = tuple2_hash(a, b);
        size_t perturb = (size_t)hash;
        size_t i = (size_t)hash & mask_;
        while (true) {
            const Entry* entry = &table_[i];
            if (!entry->used) return -1;
            if (entry->hash == hash && entry->a == a && entry->b == b) return (long long)i;
            if (i + LINEAR_PROBES <= mask_) {
                for (size_t j = 0; j < LINEAR_PROBES; j++) {
                    entry++;
                    if (!entry->used) return -1;
                    if (entry->hash == hash && entry->a == a && entry->b == b) return (long long)(entry - &table_[0]);
                }
            }
            perturb >>= PERTURB_SHIFT;
            i = (i * 5 + 1 + perturb) & mask_;
        }
    }
    void insert_clean(std::vector<Entry>& table, size_t mask, const Entry& e) {
        size_t perturb = (size_t)e.hash;
        size_t i = (size_t)e.hash & mask;
        while (true) {
            Entry* entry = &table[i];
            if (!entry->used) { *entry = e; return; }
            if (i + LINEAR_PROBES <= mask) {
                for (size_t j = 0; j < LINEAR_PROBES; j++) {
                    entry++;
                    if (!entry->used) { *entry = e; return; }
                }
            }
            perturb >>= PERTURB_SHIFT;
            i = (i * 5 + 1 + perturb) & mask;
        }
    }
    void resize(size_t minused) {
        size_t newsize = 8;
        while (newsize <= minused) newsize <<= 1;
        std::vector<Entry> old = std::move(table_);
        table_.assign(newsize, Entry());
        mask_ = newsize - 1;
        for (const Entry& e : old) if (e.used) insert_clean(table_, mask_, e);
        fill_ = used_;
    }
};

}  // namespace py
