// signs.py: Ground, SegmentIndex, build_network (shared by the posts and the overhead line)
#pragma once
#include <map>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>
#include <functional>
#include "graph.h"

// ---------------------------------------------------------------- ground (tile physics)
class Ground {
public:
    explicit Ground(const std::string& rom, const std::string& family = "mega_island") : rom_(rom), family_(family) {}
    std::vector<double> heights(double world_x, double world_z);
private:
    struct Tri { V3 a, b, c; };
    struct TileGrid { std::unordered_map<long long, std::vector<int>> cells; std::vector<Tri> tris; };
    TileGrid& load(const std::string& tile);
    std::string rom_, family_;
    std::unordered_map<std::string, TileGrid> tiles_;
};

bool tile_origin(const std::string& tile, double& ox, double& oz, const std::string& family = "");
bool mainland_origin(const std::string& tile, double& ox, double& oz);
inline std::array<double, 2> right_of(const std::array<double, 2>& t) { return {t[1], -t[0]}; }

// ---------------------------------------------------------------- segment index
template <class Info>
class SegmentIndex {
public:
    static constexpr double CELL = 20.0;
    struct Item { std::array<double, 2> a, b; Info info; };
    std::vector<Item> items;
    void add(const std::array<double, 2>& a, const std::array<double, 2>& b, const Info& info) {
        long long steps = (long long)py::floordiv(py::hypot(b[0] - a[0], b[1] - a[1]), CELL / 2) + 1;
        std::set<std::pair<long long, long long>> cells;
        for (long long i = 0; i <= steps; i++) {
            double f = (double)i / (double)steps;
            cells.insert({(long long)std::floor((a[0] + (b[0] - a[0]) * f) / CELL),
                          (long long)std::floor((a[1] + (b[1] - a[1]) * f) / CELL)});
        }
        int idx = (int)items.size();
        items.push_back({a, b, info});
        for (auto& c : cells) grid_[c].push_back(idx);
    }
    // items near (x, z) in the order Python's generator yields them
    std::vector<int> near(double x, double z, double radius) const {
        long long r = (long long)std::ceil(radius / CELL);
        long long cx = (long long)std::floor(x / CELL), cz = (long long)std::floor(z / CELL);
        std::vector<int> out;
        std::set<int> seen;
        for (long long ix = cx - r; ix <= cx + r; ix++)
            for (long long iz = cz - r; iz <= cz + r; iz++) {
                auto it = grid_.find({ix, iz});
                if (it == grid_.end()) continue;
                for (int i : it->second)
                    if (seen.insert(i).second) out.push_back(i);
            }
        return out;
    }
private:
    std::map<std::pair<long long, long long>, std::vector<int>> grid_;
};

double point_segment_distance(const std::array<double, 2>& p, const std::array<double, 2>& a, const std::array<double, 2>& b);
// distance along the ray p + s*d (0.05 < s < max_s) to segment a-b; false if none
bool ray_hits_segment(const std::array<double, 2>& p, const std::array<double, 2>& d, double max_s,
                      const std::array<double, 2>& a, const std::array<double, 2>& b, double* s_out = nullptr);

// ---------------------------------------------------------------- network
using NKey = int;                         // interned (tile, node id)
using NEdge = std::pair<NKey, NKey>;

struct Network {
    std::string family;
    std::vector<std::string> mainland;
    std::vector<std::string> key_tile, key_id;          // NKey -> names
    std::vector<NKey> order;                             // nodes_world insertion order
    std::unordered_map<NKey, V3> pos;                    // nodes_world
    std::unordered_map<NKey, std::vector<NKey>> links;   // merged links
    std::map<NEdge, std::string> edge_tile;
    std::vector<NKey> dist_order;                        // Dijkstra settle order
    std::unordered_map<NKey, double> dist;
    std::set<NEdge> line_set;
    std::vector<NEdge> lines;
    SegmentIndex<NEdge> all_tracks, line_index;
    long long joins = 0;
    bool on_edge(NKey k) const;
    bool has_dist(NKey k) const { return dist.count(k) != 0; }
    bool key_less(NKey a, NKey b) const {
        if (key_tile[a] != key_tile[b]) return key_tile[a] < key_tile[b];
        return key_id[a] < key_id[b];
    }
};

using PrepareFn = std::function<Prepared(const std::string&)>;
Network build_network(const std::vector<std::string>& tiles, const PrepareFn& prepare, const std::string& family = "mega_island");
bool in_dock_line(double x, double z);
