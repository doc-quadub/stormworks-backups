#pragma once
#include <map>
#include <string>
#include <vector>
#include "swmesh.h"
#include "value.h"

struct MeshEntry {
    std::string file_name;
    Mat4 matrix;
};
std::string tile_xml_path(const std::string& rom, const std::string& tile);
std::vector<MeshEntry> mesh_entries(const std::string& text);
V3 transform_point(const V3& p, const Mat4& m);
bool grid_name(const std::string& t, std::string& family, long long& x, long long& z);
const std::pair<int, int>* tile_world_get(const std::string& t);

struct StrayResult {
    std::vector<std::string> stray_order;
    std::map<std::string, std::vector<std::string>> stray;
    std::vector<std::string> partners_order;
    std::map<std::string, std::vector<std::pair<std::string, Value>>> partners;
    void partners_order_tiles_push(const std::string& t);
};
StrayResult find_stray_components(const std::string& rom, const std::vector<std::string>& tiles);
void step_scan(const std::string& rom, const std::string& work);
