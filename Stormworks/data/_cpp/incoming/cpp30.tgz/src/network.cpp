#include "network.h"
#include "scan.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

// ---------------------------------------------------------------- tile origins
static const std::vector<std::pair<std::string, std::pair<int, int>>> FAMILIES = {
    {"mega_island", {-8000, -12000}}, {"arid_island", {-24000, -40000}}};

// re.fullmatch(r"(mega_island|arid_island)_(\d+)_(\d+)", tile)
bool tile_origin(const std::string& tile, double& ox, double& oz, const std::string& family) {
    for (auto& f : FAMILIES) {
        const std::string& pre = f.first;
        if (tile.compare(0, pre.size() + 1, pre + "_") != 0) continue;
        std::string rest = tile.substr(pre.size() + 1);
        size_t u = rest.find('_');
        if (u == std::string::npos || u == 0 || u + 1 >= rest.size()) return false;
        std::string a = rest.substr(0, u), b = rest.substr(u + 1);
        for (char c : a) if (!is_digit(c)) return false;
        for (char c : b) if (!is_digit(c)) return false;
        if (!family.empty() && family != pre) return false;
        ox = (double)(std::stoll(a) * 1000 + f.second.first);
        oz = (double)(std::stoll(b) * 1000 + f.second.second);
        return true;
    }
    return false;
}

bool mainland_origin(const std::string& tile, double& ox, double& oz) { return tile_origin(tile, ox, oz, "mega_island"); }

// ---------------------------------------------------------------- ground
static const double GROUND_CELL = 8.0;
static long long cell_key(long long ix, long long iz) { return ix * 4000003LL + iz; }

Ground::TileGrid& Ground::load(const std::string& tile) {
    auto it = tiles_.find(tile);
    if (it != tiles_.end()) return it->second;
    TileGrid& g = tiles_[tile];
    std::string path = rom_ + "/data/tiles/" + tile + ".xml";
    if (!file_exists(path)) return g;
    std::string text = read_text_universal(path);
    std::string_view t(text);
    // re.finditer(r"<physics_mesh ([^>]*)>\s*<transform([^/]*)/>", text)
    static const std::string_view pre = "<physics_mesh ";
    size_t i = 0;
    while ((i = t.find(pre, i)) != std::string_view::npos) {
        size_t start = i;
        size_t a0 = i + pre.size();
        size_t gt = t.find('>', a0);
        bool ok = false;
        if (gt != std::string_view::npos) {
            size_t p = gt + 1;
            while (p < t.size() && is_space(t[p])) p++;
            if (t.substr(p, 10) == "<transform") {
                size_t q = p + 10;
                size_t slash = t.find('/', q);
                if (slash != std::string_view::npos && slash + 1 < t.size() && t[slash + 1] == '>') {
                    ok = true;
                    auto attrs = attrs_dict(t.substr(a0, gt - a0));
                    i = slash + 2;
                    if (attr_get(attrs, "parent_id") || !attr_get(attrs, "file_name")) continue;
                    std::string phys_path = rom_ + "/" + *attr_get(attrs, "file_name");
                    if (!file_exists(phys_path)) continue;
                    Mat4 m = parse_transform(t.substr(q, slash - q));
                    for (const auto& part : read_phys(phys_path)) {
                        for (size_t k = 0; k + 2 < part.size(); k += 3) {
                            Tri tri{transform_point(part[k], m), transform_point(part[k + 1], m), transform_point(part[k + 2], m)};
                            double x0 = std::min(std::min(tri.a[0], tri.b[0]), tri.c[0]);
                            double x1 = std::max(std::max(tri.a[0], tri.b[0]), tri.c[0]);
                            double z0 = std::min(std::min(tri.a[2], tri.b[2]), tri.c[2]);
                            double z1 = std::max(std::max(tri.a[2], tri.b[2]), tri.c[2]);
                            int idx = (int)g.tris.size();
                            g.tris.push_back(tri);
                            for (long long ix = (long long)std::floor(x0 / GROUND_CELL); ix <= (long long)std::floor(x1 / GROUND_CELL); ix++)
                                for (long long iz = (long long)std::floor(z0 / GROUND_CELL); iz <= (long long)std::floor(z1 / GROUND_CELL); iz++)
                                    g.cells[cell_key(ix, iz)].push_back(idx);
                        }
                    }
                }
            }
        }
        if (!ok) i = start + 1;
    }
    return g;
}

std::vector<double> Ground::heights(double world_x, double world_z) {
    double fx = 0, fz = 0;
    for (auto& f : FAMILIES) if (f.first == family_) { fx = f.second.first; fz = f.second.second; }
    long long tx = (long long)std::floor((world_x - fx + 500) / 1000);
    long long tz = (long long)std::floor((world_z - fz + 500) / 1000);
    std::string tile = family_ + "_" + std::to_string(tx) + "_" + std::to_string(tz);
    double ox = (double)(tx * 1000 + (long long)fx), oz = (double)(tz * 1000 + (long long)fz);
    double x = world_x - ox, z = world_z - oz;
    TileGrid& g = load(tile);
    std::vector<double> hits;
    auto it = g.cells.find(cell_key((long long)std::floor(x / GROUND_CELL), (long long)std::floor(z / GROUND_CELL)));
    if (it == g.cells.end()) return hits;
    for (int idx : it->second) {
        const Tri& T = g.tris[idx];
        const V3 &a = T.a, &b = T.b, &c = T.c;
        double d = (b[0] - a[0]) * (c[2] - a[2]) - (c[0] - a[0]) * (b[2] - a[2]);
        if (std::fabs(d) < 1e-12) continue;
        double l1 = ((x - a[0]) * (c[2] - a[2]) - (c[0] - a[0]) * (z - a[2])) / d;
        double l2 = ((b[0] - a[0]) * (z - a[2]) - (x - a[0]) * (b[2] - a[2])) / d;
        if (l1 < -1e-6 || l2 < -1e-6 || l1 + l2 > 1 + 1e-6) continue;
        hits.push_back(a[1] + l1 * (b[1] - a[1]) + l2 * (c[1] - a[1]));
    }
    return hits;
}

// ---------------------------------------------------------------- geometry helpers
double point_segment_distance(const std::array<double, 2>& p, const std::array<double, 2>& a, const std::array<double, 2>& b) {
    double dx = b[0] - a[0], dz = b[1] - a[1];
    double length2 = dx * dx + dz * dz;
    double t = length2 == 0 ? 0.0 : std::max(0.0, std::min(1.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dz) / length2));
    return py::hypot(p[0] - a[0] - t * dx, p[1] - a[1] - t * dz);
}

bool ray_hits_segment(const std::array<double, 2>& p, const std::array<double, 2>& d, double max_s,
                      const std::array<double, 2>& a, const std::array<double, 2>& b, double* s_out) {
    double ex = b[0] - a[0], ez = b[1] - a[1];
    double den = d[0] * ez - d[1] * ex;
    if (std::fabs(den) < 1e-9) return false;
    double wx = a[0] - p[0], wz = a[1] - p[1];
    double s = (wx * ez - wz * ex) / den;
    double u = (wx * d[1] - wz * d[0]) / den;
    if (0.05 < s && s < max_s && -1e-6 <= u && u <= 1 + 1e-6) {
        if (s_out) *s_out = s;
        return true;
    }
    return false;
}

// ---------------------------------------------------------------- dock line (Meier)
struct DockLine { std::vector<std::array<double, 2>> pts; double half_width; };
static const std::vector<DockLine>& dock_lines() {
    static const std::vector<DockLine> d = {
        {{{2430.5, -26500.0}, {2165.2, -25510.0}}, 7.0},
        {{{2323.4, -26413.0}, {2338, -26407}, {2346, -26402}, {2353, -26396}, {2359, -26390},
          {2365, -26383}, {2369, -26375}, {2373, -26368}, {2376, -26359}, {2378, -26350},
          {2378, -26333}, {2377, -26321}, {2372.45, -26291.7}, {2366, -26270}}, 5.0},
    };
    return d;
}

bool in_dock_line(double x, double z) {
    for (const DockLine& L : dock_lines()) {
        for (size_t i = 0; i + 1 < L.pts.size(); i++) {
            const auto& a = L.pts[i];
            const auto& b = L.pts[i + 1];
            double dx = b[0] - a[0], dz = b[1] - a[1];
            double length2 = dx * dx + dz * dz;
            double t = ((x - a[0]) * dx + (z - a[1]) * dz) / length2;
            if (i == 0 && t * std::sqrt(length2) < 3.0) continue;
            t = std::min(1.0, std::max(0.0, t));
            if (py::hypot(a[0] + dx * t - x, a[1] + dz * t - z) <= L.half_width) return true;
        }
    }
    return false;
}

// ---------------------------------------------------------------- Python heapq (verbatim algorithm)
template <class T, class Less>
static void heap_siftdown(std::vector<T>& heap, size_t startpos, size_t pos, Less lt) {
    T newitem = heap[pos];
    while (pos > startpos) {
        size_t parentpos = (pos - 1) >> 1;
        T parent = heap[parentpos];
        if (lt(newitem, parent)) {
            heap[pos] = parent;
            pos = parentpos;
            continue;
        }
        break;
    }
    heap[pos] = newitem;
}
template <class T, class Less>
static void heap_siftup(std::vector<T>& heap, size_t pos, Less lt) {
    size_t endpos = heap.size();
    size_t startpos = pos;
    T newitem = heap[pos];
    size_t childpos = 2 * pos + 1;
    while (childpos < endpos) {
        size_t rightpos = childpos + 1;
        if (rightpos < endpos && !lt(heap[childpos], heap[rightpos])) childpos = rightpos;
        heap[pos] = heap[childpos];
        pos = childpos;
        childpos = 2 * pos + 1;
    }
    heap[pos] = newitem;
    heap_siftdown(heap, startpos, pos, lt);
}
template <class T, class Less>
static void heappush(std::vector<T>& heap, T item, Less lt) {
    heap.push_back(item);
    heap_siftdown(heap, 0, heap.size() - 1, lt);
}
template <class T, class Less>
static T heappop(std::vector<T>& heap, Less lt) {
    T lastelt = heap.back();
    heap.pop_back();
    if (!heap.empty()) {
        T returnitem = heap[0];
        heap[0] = lastelt;
        heap_siftup(heap, 0, lt);
        return returnitem;
    }
    return lastelt;
}

// ---------------------------------------------------------------- build_network
static const double TILE_HALF = 500.0;
static const double JOIN_TOLERANCE = 1.0;
static const double JOIN_EDGE_MARGIN = 3.0;
static const double MEIER_ZERO[2] = {2430.0, -26500.0};
static const double MEIER_ZERO_RADIUS = 9.0;
static const double MIN_LINE_REACH = 1000.0;

bool Network::on_edge(NKey k) const {
    double ox, oz;
    tile_origin(key_tile[k], ox, oz);
    const V3& p = pos.at(k);
    return std::max(std::fabs(p[0] - ox), std::fabs(p[2] - oz)) >= TILE_HALF - 0.6;
}

Network build_network(const std::vector<std::string>& tiles, const PrepareFn& prepare, const std::string& family) {
    Network net;
    net.family = family;
    double ox, oz;
    for (const std::string& t : tiles) if (tile_origin(t, ox, oz, family)) net.mainland.push_back(t);
    std::map<std::pair<std::string, std::string>, NKey> intern;
    auto key_of = [&](const std::string& tile, const std::string& id) {
        auto it = intern.find({tile, id});
        if (it != intern.end()) return it->second;
        NKey k = (NKey)net.key_tile.size();
        net.key_tile.push_back(tile);
        net.key_id.push_back(id);
        intern[{tile, id}] = k;
        return k;
    };
    std::vector<NKey> nw_order;
    std::unordered_map<NKey, V3> nw;
    std::vector<NKey> links_order;
    std::unordered_map<NKey, std::vector<NKey>> links;
    for (const std::string& tile : net.mainland) {
        tile_origin(tile, ox, oz);
        Prepared P = prepare(tile);
        std::unordered_set<std::string> stray = P.stray;
        if (family == "arid_island")
            for (const std::string& k : P.nodes.order) {
                const V3& p = P.nodes.at(k).pos;
                if (in_dock_line(p[0] + ox, p[2] + oz)) stray.insert(k);
            }
        for (const std::string& k : P.nodes.order) {
            if (stray.count(k)) continue;
            const TrackNode& n = P.nodes.at(k);
            NKey key = key_of(tile, k);
            if (!nw.count(key)) nw_order.push_back(key);
            nw[key] = {n.pos[0] + ox, P.node_y.at(k) + rails_c::RAIL_TOP_OFFSET, n.pos[2] + oz};
            std::vector<NKey> ls;
            for (const std::string& o : n.links)
                if (P.nodes.has(o) && o != k && !stray.count(o)) ls.push_back(key_of(tile, o));
            if (!links.count(key)) links_order.push_back(key);
            links[key] = ls;
        }
    }
    net.key_tile.shrink_to_fit();

    auto near_edge = [&](NKey key) {
        const V3& p = nw.at(key);
        double tox, toz;
        tile_origin(net.key_tile[key], tox, toz);
        double margin = family == "arid_island" ? JOIN_EDGE_MARGIN : 0.6;
        return std::max(std::fabs(p[0] - tox), std::fabs(p[2] - toz)) >= TILE_HALF - margin;
    };
    std::map<std::pair<long long, long long>, std::vector<NKey>> by_cell;
    for (NKey key : nw_order)
        if (near_edge(key)) {
            const V3& p = nw.at(key);
            by_cell[{py::round_int(p[0]), py::round_int(p[2])}].push_back(key);
        }
    std::vector<NKey> alias_order;
    std::unordered_map<NKey, NKey> alias;
    for (NKey key : nw_order) {
        if (alias.count(key) || !near_edge(key)) continue;
        const V3& p = nw.at(key);
        long long rx = py::round_int(p[0]), rz = py::round_int(p[2]);
        for (long long cx = rx - 1; cx <= rx + 1; cx++)
            for (long long cz = rz - 1; cz <= rz + 1; cz++) {
                auto it = by_cell.find({cx, cz});
                if (it == by_cell.end()) continue;
                for (NKey other : it->second) {
                    if (net.key_tile[other] == net.key_tile[key] || alias.count(other) || other == key) continue;
                    const V3& q = nw.at(other);
                    if (py::hypot(q[0] - p[0], q[2] - p[2]) < JOIN_TOLERANCE && std::fabs(q[1] - p[1]) < 0.6) {
                        if (!alias.count(other)) alias_order.push_back(other);
                        alias[other] = key;
                    }
                }
            }
    }
    for (NKey k : alias_order) {
        NKey target = alias.at(k);
        while (alias.count(target) && alias.at(target) != target) target = alias.at(target);
        alias[k] = target;
    }
    net.joins = (long long)alias.size();
    auto al = [&](NKey k) { auto it = alias.find(k); return it == alias.end() ? k : it->second; };
    std::vector<NKey> merged_order;
    std::unordered_map<NKey, std::vector<NKey>> merged;
    auto merged_get = [&](NKey a) -> std::vector<NKey>& {
        auto it = merged.find(a);
        if (it == merged.end()) { merged_order.push_back(a); return merged[a]; }
        return it->second;
    };
    for (NKey key : links_order) {
        NKey a = al(key);
        std::vector<NKey>& ma = merged_get(a);
        for (NKey o : links.at(key)) {
            NKey b = al(o);
            std::vector<NKey>& mref = merged_get(a);
            if (b != a && std::find(mref.begin(), mref.end(), b) == mref.end()) mref.push_back(b);
            net.edge_tile[{a, b}] = net.key_tile[key];
            net.edge_tile[{b, a}] = net.key_tile[key];
        }
        (void)ma;
    }
    std::vector<NKey> keys_snapshot = merged_order;
    for (NKey a : keys_snapshot) {
        std::vector<NKey> lst = merged.at(a);           // (not modified while iterated: b != a)
        for (NKey b : lst) {
            std::vector<NKey>& mb = merged_get(b);
            if (std::find(mb.begin(), mb.end(), a) == mb.end()) mb.push_back(a);
        }
    }
    net.links = merged;
    for (NKey k : nw_order)
        if (merged.count(k)) { net.order.push_back(k); net.pos[k] = nw.at(k); }

    auto length = [&](NKey a, NKey b) {
        const V3& p = net.pos.at(a);
        const V3& q = net.pos.at(b);
        return py::dist3(p[0], p[1], p[2], q[0], q[1], q[2]);
    };
    // Dijkstra with Python's heapq and tuple ordering (d, (tile, id))
    using HE = std::pair<double, NKey>;
    auto lt = [&](const HE& x, const HE& y) {
        if (x.first != y.first) return x.first < y.first;
        return net.key_less(x.second, y.second);
    };
    std::vector<HE> heap;
    if (family == "arid_island") {
        for (NKey k : net.order) {
            const V3& p = net.pos.at(k);
            if (py::hypot(p[0] - MEIER_ZERO[0], p[2] - MEIER_ZERO[1]) < MEIER_ZERO_RADIUS) heap.push_back({0.0, k});
        }
    } else {
        for (const char* z : {"train_18", "train_20"}) {
            auto it = intern.find({"mega_island_9_8", z});
            if (it != intern.end() && net.pos.count(it->second)) heap.push_back({0.0, it->second});
        }
    }
    if (heap.empty()) throw std::runtime_error("zero point nodes not found");
    while (!heap.empty()) {
        HE e = heappop(heap, lt);
        if (net.dist.count(e.second)) continue;
        net.dist[e.second] = e.first;
        net.dist_order.push_back(e.second);
        for (NKey o : net.links.at(e.second))
            if (!net.dist.count(o)) heappush(heap, HE{e.first + length(e.second, o), o}, lt);
    }

    std::unordered_map<NKey, std::vector<NKey>> downstream;
    std::vector<NEdge> edges;
    for (NKey a : net.dist_order)
        for (NKey b : net.links.at(a))
            if (net.dist.count(b) && net.dist.at(b) > net.dist.at(a))
                if (net.dist.at(b) - net.dist.at(a) >= length(a, b) - 0.5) {
                    downstream[a].push_back(b);
                    edges.push_back({a, b});
                }
    std::unordered_map<NKey, double> reach;
    std::unordered_map<NKey, bool> is_open;
    std::vector<NKey> by_dist = net.dist_order;
    std::stable_sort(by_dist.begin(), by_dist.end(), [&](NKey x, NKey y) { return -net.dist.at(x) < -net.dist.at(y); });
    for (NKey key : by_dist) {
        auto it = downstream.find(key);
        double r = net.dist.at(key);
        if (it != downstream.end()) for (NKey o : it->second) r = std::max(r, reach.at(o));
        reach[key] = r;
        if (it != downstream.end() && !it->second.empty()) {
            bool any = false;
            for (NKey o : it->second) if (is_open.at(o)) { any = true; break; }
            is_open[key] = any;
        } else {
            is_open[key] = net.links.at(key).size() >= 2 || net.on_edge(key);
        }
    }
    std::unordered_map<NKey, std::vector<NKey>> upstream;
    for (auto& e : edges) upstream[e.second].push_back(e.first);
    std::vector<NEdge> sorted_edges = edges;
    std::stable_sort(sorted_edges.begin(), sorted_edges.end(), [&](const NEdge& x, const NEdge& y) {
        return net.dist.at(x.first) < net.dist.at(y.first);
    });
    for (auto& e : sorted_edges) {
        NKey a = e.first, b = e.second;
        if (is_open.at(b) || reach.at(b) - net.dist.at(a) >= MIN_LINE_REACH) {
            net.line_set.insert(e);
        } else if (net.links.at(a).size() == 2) {
            auto it = upstream.find(a);
            bool any = false;
            if (it != upstream.end()) for (NKey u : it->second) if (net.line_set.count({u, a})) { any = true; break; }
            if (any) net.line_set.insert(e);
        }
    }
    for (auto& e : edges) if (net.line_set.count(e)) net.lines.push_back(e);

    std::set<std::pair<NKey, NKey>> seen;
    for (NKey a : net.order)
        for (NKey b : net.links.at(a)) {
            auto key = a < b ? std::make_pair(a, b) : std::make_pair(b, a);
            if (seen.count(key)) continue;
            seen.insert(key);
            const V3& pa = net.pos.at(a);
            const V3& pb = net.pos.at(b);
            net.all_tracks.add({pa[0], pa[2]}, {pb[0], pb[2]}, {a, b});
            if (net.line_set.count({a, b}) || net.line_set.count({b, a}))
                net.line_index.add({pa[0], pa[2]}, {pb[0], pb[2]}, {a, b});
        }
    return net;
}
