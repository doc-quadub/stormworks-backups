// catenary.py planning: plan_catenary, extract_roads (port)
#pragma once
#include <string>
#include <vector>
#include "network.h"
#include "value.h"

namespace cat {
// dimensions shared with the geometry
constexpr double CONTACT_WIRE_HEIGHT = 6.50;
constexpr double SYSTEM_HEIGHT = 1.80;
constexpr double STAGGER = 0.30;
constexpr double ZIGZAG_MIN_RADIUS = 3000.0;
constexpr double CURVE_OFFSET_MAX = 0.35;
constexpr double MAX_SPAN = 70.0;
constexpr double MIN_SPAN = 30.0;
constexpr double CURVE_SAG_ALLOWANCE = 0.60;
constexpr double CURVE_MIN_SPAN = 12.0;
constexpr double POLE_OFFSET = 3.30;
constexpr double POLE_HEIGHT = 10.00;
constexpr double POLE_BASE_BELOW_RAIL = 0.80;
constexpr double POLE_RADIUS_GROUND = 0.225;
constexpr double POLE_RADIUS_TOP = 0.150;
constexpr double POLE_TAPER_FROM = 0.5;
constexpr double DISC_PITCH = 0.146;
constexpr int GARLAND_DISCS = 3;
constexpr int ANCHOR_DISCS = 4;
constexpr double GARLAND_FITTINGS = 0.13;
constexpr double GARLAND_LENGTH = GARLAND_DISCS * DISC_PITCH + GARLAND_FITTINGS;
constexpr double FEEDER_ARM[2] = {1.65, 3.30};
constexpr double FEEDER_BRACKET_DROP = 0.10;
constexpr double FEEDER_STAND = 0.80;
constexpr double PORTAL_BEAM_HEIGHT = 9.30;
constexpr double PORTAL_BEAM_BOTTOM = 9.60;
constexpr double PORTAL_TRUSS_HEIGHT = 0.70;
constexpr double PORTAL_TWIN_TRUSS_HEIGHT = 1.20;
constexpr double PORTAL_TWIN_SPAN = 15.0;
constexpr double PORTAL_TWIN_OFFSET = (2 * POLE_RADIUS_GROUND + POLE_RADIUS_GROUND) / 2;
constexpr double PORTAL_HEAD_HALF = 0.195;
constexpr double PORTAL_PLATE_MARGIN = 0.03;
constexpr double PORTAL_DECK = 0.04;
constexpr double TRUSS_BEAM_SIZE[2] = {0.25, 0.30};
constexpr double TRUSS_CLAMP[3] = {0.50, 0.14, 0.08};

double pole_radius_at(double sp_base_y, double y, double height = POLE_HEIGHT);
double pole_base_y(const Value& sp);
bool portal_twin(const Value& portal);
std::pair<double, double> portal_head_half(const Value& portal);
std::pair<double, double> portal_beam_size(const Value& portal);
double portal_beam_y(const Value& portal);
std::vector<V3> feeder_points(const Value& fp);
}  // namespace cat

Value extract_roads(const std::string& mesh_path);
void step_roads(const std::string& rom, const std::string& work);
void step_catenary(const std::string& rom, const std::string& work);
