// smooth.py and build_world.prepare_graph
#pragma once
#include <map>
#include <set>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <optional>
#include "swmesh.h"
#include "value.h"

using Graph = Tracks;                       // id -> (position, links), in insertion order
using Dir2 = std::array<double, 2>;

struct OrderedY {                           // node_y: id -> lifted height
    std::unordered_map<std::string, double> y;
    double at(const std::string& k) const { return y.at(k); }
};

struct Prepared {
    Graph nodes;
    std::unordered_map<std::string, double> node_y;
    std::vector<std::string> inserted;
    std::vector<std::string> tangent_order;                 // border_tangents in insertion order
    std::unordered_map<std::string, Dir2> border_tangents;
    std::unordered_set<std::string> stray;
    std::unordered_set<std::string> kept;                   // prepare_graph.kept[tile]
};

namespace smooth {
extern const double MIN_NODE_GAP;
bool is_junction(const Graph& nodes, const std::string& k);
void smooth_graph(Graph& nodes, std::unordered_map<std::string, double>& node_y,
                  const std::unordered_map<std::string, Dir2>& border_tangents,
                  const std::unordered_set<std::string>& skip, std::vector<std::string>& inserted);
std::string train_tracks_xml(const std::string& original_text, const Graph& new_nodes,
                             const std::unordered_map<std::string, double>& new_y,
                             const std::string& newline, double raise_kept);
}

void graph_add(Graph& g, const std::string& id, const V3& p, std::vector<std::string> links);
Prepared prepare_graph(const std::string& rom, const std::string& tile, const Value& scan);
// modular_joint: nominal position and outward direction of a modular-line track end
bool modular_joint(const V3& p, V3& pos, Dir2& dir);
bool border_normal(const V3& p, V3& n);

namespace rails_c {
constexpr double GRAPH_RAISE = 0.28;
constexpr double RAIL_TOP_OFFSET = -0.03;
constexpr double TILE_HALF_SIZE = 500.0;
}
