// Stormworks .mesh / .phys files and tile XML parsing (port of swmesh.py)
#pragma once
#include <array>
#include <string>
#include <string_view>
#include <vector>
#include <unordered_map>
#include <cstdint>

using Mat4 = std::array<std::array<double, 4>, 4>;
using V3 = std::array<double, 3>;

struct MeshVertex {
    float x, y, z;
    uint8_t r, g, b, a;
    float nx, ny, nz;
};
struct Submesh {
    uint32_t index_start = 0, index_count = 0;
    uint16_t shader = 0;
    std::array<float, 3> bounds_min{}, bounds_max{};
    std::string name;
    uint16_t unknown_u16 = 0;
    std::array<float, 3> scale{1.0f, 1.0f, 1.0f};
};
struct Mesh {
    std::vector<MeshVertex> vertices;
    std::vector<uint16_t> indices;
    std::vector<Submesh> submeshes;
    std::string trailer = std::string("\0\0", 2);
};

std::string read_file(const std::string& path);              // bytes as they are
std::string read_text_universal(const std::string& path);    // Python text mode: \r\n, \r -> \n
void write_file(const std::string& path, const std::string& data);
bool file_exists(const std::string& path);
bool dir_exists(const std::string& path);
std::vector<std::string> list_dir(const std::string& path);  // names, unsorted
void make_dirs(const std::string& path);
std::string path_join(const std::string& a, const std::string& b);

Mesh read_mesh_full(const std::string& path);
void write_mesh(const std::string& path, const Mesh& mesh);
std::string mesh_bytes(const Mesh& mesh);
// parts of (x, y, z) float vertices widened to double, 3 per triangle
std::vector<std::vector<V3>> read_phys(const std::string& path);
void write_phys(const std::string& path, const std::vector<std::array<V3, 3>>& triangles);

Mat4 identity4();
Mat4 parse_transform(std::string_view attr_text);

struct TrackNode {
    V3 pos;
    std::vector<std::string> links;
};
struct Tracks {
    std::vector<std::string> order;                      // first appearance order of ids
    std::unordered_map<std::string, TrackNode> nodes;
    bool has(const std::string& k) const { return nodes.count(k) != 0; }
    const TrackNode& at(const std::string& k) const { return nodes.at(k); }
};
Tracks parse_tracks(const std::string& text);
Tracks read_tracks(const std::string& path);

// regex helpers (Python re semantics for the patterns used)
inline bool is_space(char c) { return c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\f' || c == '\v'; }
inline bool is_word(char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_'; }
inline bool is_digit(char c) { return c >= '0' && c <= '9'; }
// re.findall(r'(\w+)="([^"]*)"', text) as an ordered list of pairs
std::vector<std::pair<std::string, std::string>> find_attrs(std::string_view text);
// dict(...) of the above: later duplicates overwrite, first position kept
std::vector<std::pair<std::string, std::string>> attrs_dict(std::string_view text);
const std::string* attr_get(const std::vector<std::pair<std::string, std::string>>& attrs, const std::string& key);
// re.findall(r'<link id="([^"]+)"', text)
std::vector<std::string> find_links(std::string_view text);
