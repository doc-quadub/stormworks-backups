"""python3 dump_graph.py <ref_dir> <rom> <scan.json> <out>: prepare_graph of every tile as text."""
import sys, json
sys.path.insert(0, sys.argv[1])
import build_world
rom, scan = sys.argv[2], json.load(open(sys.argv[3]))
out = open(sys.argv[4], "w")
for tile in scan["tiles"]:
    nodes, node_y, inserted, bt, stray = build_world.prepare_graph(rom, tile, scan)
    out.write("T %s\n" % tile)
    for k, (p, links) in nodes.items():
        out.write("N %s %r %r %r %r | %s\n" % (k, p[0], p[1], p[2], node_y[k], " ".join(links)))
    out.write("I %s\n" % " ".join(inserted))
    out.write("B %s\n" % " ".join("%s:%r,%r" % (k, t[0], t[1]) for k, t in bt.items()))
    out.write("S %s\n" % " ".join(sorted(stray)))
    out.write("K %s\n" % " ".join(sorted(build_world.prepare_graph.kept.get(tile, ()))))
