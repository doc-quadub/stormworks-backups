// reads "n a1 b1 a2 b2 ..." from stdin, prints the CPython set iteration order
#include <iostream>
#include "../src/pyset.h"
int main() {
    long long n;
    while (std::cin >> n) {
        py::PairSet s;
        for (long long k = 0; k < n; k++) { long long a, b; std::cin >> a >> b; s.add(a, b); }
        for (auto& p : s.items()) std::cout << p.first << " " << p.second << " ";
        std::cout << "\n";
    }
}
