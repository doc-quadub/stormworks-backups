import random, subprocess, sys
random.seed(7)
cases = []
for c in range(400):
    n = random.choice([1, 3, 10, 50, 200, 1000, 5000])
    m = random.choice([20, 200, 3000, 100000])
    pairs = []
    for _ in range(n):
        a, b = random.randrange(m), random.randrange(m)
        pairs.append((min(a, b), max(a, b)))
    cases.append(pairs)
inp = "\n".join(str(len(p)) + " " + " ".join("%d %d" % q for q in p) for p in cases) + "\n"
out = subprocess.run([sys.argv[1]], input=inp, capture_output=True, text=True).stdout.splitlines()
bad = 0
for pairs, line in zip(cases, out):
    s = set()
    for q in pairs:
        s.add(q)
    want = " ".join("%d %d" % q for q in s)
    if want != line.strip():
        bad += 1
print("cases", len(cases), "mismatches", bad)
