#include "../src/graph.h"
#include <fstream>
#include <algorithm>
int main(int argc, char** argv) {
    std::string rom = argv[1];
    Value scan = json::load(argv[2]);
    std::ofstream out(argv[3]);
    for (const Value& tv : scan["tiles"].lst()) {
        const std::string& tile = tv.str();
        Prepared P = prepare_graph(rom, tile, scan);
        out << "T " << tile << "\n";
        for (const std::string& k : P.nodes.order) {
            const TrackNode& n = P.nodes.at(k);
            out << "N " << k << " " << py::repr(n.pos[0]) << " " << py::repr(n.pos[1]) << " " << py::repr(n.pos[2]) << " "
                << py::repr(P.node_y.at(k)) << " |";
            for (auto& l : n.links) out << " " << l;
            if (n.links.empty()) out << " ";
            out << "\n";
        }
        out << "I";
        for (auto& k : P.inserted) out << " " << k;
        if (P.inserted.empty()) out << " ";
        out << "\nB";
        for (auto& k : P.tangent_order) out << " " << k << ":" << py::repr(P.border_tangents.at(k)[0]) << "," << py::repr(P.border_tangents.at(k)[1]);
        if (P.tangent_order.empty()) out << " ";
        std::vector<std::string> s(P.stray.begin(), P.stray.end()), kk(P.kept.begin(), P.kept.end());
        std::sort(s.begin(), s.end());
        std::sort(kk.begin(), kk.end());
        out << "\nS";
        for (auto& k : s) out << " " << k;
        if (s.empty()) out << " ";
        out << "\nK";
        for (auto& k : kk) out << " " << k;
        if (kk.empty()) out << " ";
        out << "\n";
    }
}
