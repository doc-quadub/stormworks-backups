// sro: C++ port of the Stormworks Railway Overhaul generator (build_world.py and its tools)
#include <iostream>
#include <string>
#include "scan.h"
#include "signs_plan.h"

int main(int argc, char** argv) {
    if (argc < 4) {
        std::cerr << "usage: sro <rom_dir> <work_dir> scan|signs|roads|catenary|tiles|assemble\n";
        return 2;
    }
    std::string rom = argv[1], work = argv[2], step = argv[3];
    try {
        if (step == "scan") step_scan(rom, work);
        else if (step == "signs") step_signs(rom, work);
        else { std::cerr << "unknown step " << step << "\n"; return 2; }
    } catch (const std::exception& e) {
        std::cerr << "error: " << e.what() << "\n";
        return 1;
    }
    return 0;
}
